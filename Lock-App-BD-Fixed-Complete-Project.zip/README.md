# Lock App BD — Premium Android App Locker

বিজ্ঞাপনমুক্ত, অফলাইন এবং শক্তিশালী Android অ্যাপ লকার। React/TypeScript UI + Android Native (Kotlin) ইঞ্জিন।

- **Application ID:** `com.aistudio.appbuilder.vkmptz` (Namespace: `com.example`)
- **Developer:** Mohammad Rakib
- **Telegram:** https://t.me/appdevbyrakib
- **WhatsApp:** https://chat.whatsapp.com

---

## 🚀 সম্পূর্ণ বাস্তবায়িত ফিচারসমূহ (All Features Implemented)

1. **রিয়েল ইনস্টল করা অ্যাপ শনাক্তকরণ (Installed Apps Detection):**
   - Android `PackageManager` এবং `<queries>` intent দিয়ে ডিভাইসে ইনস্টল করা সব লঞ্চার অ্যাপ স্বয়ংক্রিয়ভাবে শনাক্ত করে।
   - অ্যাপের নাম, প্যাকেজ নাম, বিভাগ (Category), এবং আসল আইকন (Base64 PNG Data URI) সুন্দরভাবে UI-তে প্রদর্শিত হয়।
   - সংবেদনশীল সিস্টেম অ্যাপ (Settings, Dialer, Emergency, Launcher, SystemUI, Lock App BD) স্বয়ংক্রিয়ভাবে এক্সক্লুড থাকে যাতে ব্যবহারকারী কখনও আটকে না যান।

2. **নেটিভ অ্যাপ লকিং ইঞ্জিন (Native App Lock Engine):**
   - **ফোরগ্রাউন্ড সার্ভিস (`AppLockService`):** ব্যাকগ্রাউন্ডে নিয়মিত `UsageStatsManager` মনিটর করে কোন অ্যাপ সামনে এসেছে।
   - **অ্যাক্সেসিবিলিটি সার্ভিস (`AppLockAccessibilityService`):** ঐচ্ছিক অতি-দ্রুত ইভেন্ট-ভিত্তিক উইন্ডো চেঞ্জ ট্র্যাকিং।
   - ব্যবহারকারীর নির্বাচিত অ্যাপ সামনে আসা মাত্রই সুরক্ষিত নেটিভ `LockActivity` স্ক্রিনের উপর চলে আসে।

3. **নিরাপদ লক স্ক্রিন ও প্রমাণীকরণ (Lock Screen & Authentication):**
   - **PIN প্রমাণীকরণ:** ৪ বা ৬ সংখ্যার PIN, PBKDF2-SHA256 হ্যাশিং (২১০,০০০ বার ইটারেশন ও র‍্যান্ডম সল্ট)।
   - **প্যাটার্ন লক (Pattern Lock):** ৩x৩ গ্রিডে ড্র্যাগ-জেসচার প্যাটার্ন প্রমাণীকরণ।
   - **ফিঙ্গারপ্রিন্ট / বায়োমেট্রিক (BiometricPrompt):** Android `androidx.biometric:biometric` সমন্বিত হার্ডওয়্যার প্রমাণীকরণ।
   - **রিকভারি কোড (Recovery Code):** ৮০-বিট ক্রিপ্টোগ্রাফিক রিকভারি কোড দিয়ে ভুলে যাওয়া PIN রিসেট করার ব্যবস্থা।
   - **ভুল চেষ্টা ট্র্যাকিং ও লকআউট (Lockout Protection):** ৫ বার ভুল হলে ৩০ সেকেন্ড, ৬ বারে ১ মিনিট, ৭ বারে ৫ মিনিট, ৮+ বারে ১৫ মিনিট লকআউট।
   - **টাইমার ও হ্যাপটিক ভাইব্রেশন:** ভুল ইনপুটে লাল অ্যালার্ট ও ডিভাইস ভাইব্রেশন।

4. **সেশন আনলক মেমোরি (`SessionUnlockManager`):**
   - একবার সঠিক PIN/প্যাটার্ন দিয়ে অ্যাপে ঢুকলে বারবার বিরক্তিকর পপআপ হয় না।
   - স্ক্রিন অফ (`ACTION_SCREEN_OFF`) হওয়া মাত্রই সব সেশন তাৎক্ষণিকভাবে বাতিল হয়ে পুনরায় লক সক্রিয় হয়ে যায়।

5. **রিবুট রিসিভার (`BootReceiver`):**
   - ফোন রিস্টার্ট বা রিবুট হলে স্বয়ংক্রিয়ভাবে লক সুরক্ষা পুনরায় চালু হয়ে যায়।

6. **React UI ↔ Native Kotlin দ্বিমুখী সংযোগ (`AndroidBridge`):**
   - `@JavascriptInterface` দিয়ে লাইভ পারমিশন স্ট্যাটাস, পারমিশন রিকোয়েস্ট, লক তালিকা সিঙ্ক এবং বায়োমেট্রিক সম্পূর্ণভাবে সংযুক্ত।
   - ওয়েব ব্রাউজারে চালালে প্রিভিউ মোড এবং Android APK-তে ইনস্টল করলে নেটিভ ইঞ্জিন কাজ করে।

---

## 📦 ফাইল ও ডাউনলোড অবস্থান (Artifacts & Deliverables)

- **Debug APK output (after building in Android Studio):** `app/build/outputs/apk/debug/app-debug.apk`
- A prebuilt APK was intentionally omitted from this patched source archive because it could not be rebuilt and verified against the patched code.

---

## 🛠 ইনস্টলেশন ও পারমিশন সেটআপ নির্দেশিকা (Setup Instructions)

1. **APK ইনস্টল করুন:**
   - `app-debug.apk` ফাইলটি আপনার Android ফোনে পাঠান ও ইনস্টল করুন ("Install from unknown sources" অনুমোদন দিন)।
2. **প্রয়োজনীয় অনুমতি দিন:**
   - **Usage Access (ইউসেজ অ্যাক্সেস):** সামনে কোন অ্যাপ খোলা হয়েছে তা শনাক্ত করার জন্য। অ্যাপের ভেতরে "অনুমতি" পেজ থেকে সরাসরি চালু করা যায়।
   - **Display over other apps (ওভারলে পারমিশন):** লক করা অ্যাপের উপরে নেটিভ লক স্ক্রিন দেখানোর জন্য।
   - **Notification (নোটিফিকেশন):** Android 13+ এ স্থায়ী সুরক্ষা সার্ভিস সচল রাখার জন্য।
   - **Accessibility (ঐচ্ছিক):** দ্রুততম প্রতিক্রিয়ার জন্য।
3. **PIN ও অ্যাপ সিলেক্ট করুন:**
   - সেটআপ উইজার্ডে আপনার PIN দিন এবং রিকভারি কোডটি লিখে রাখুন।
   - "অ্যাপস" ট্যাব থেকে আপনার পছন্দের অ্যাপগুলো লক টগল করুন।
