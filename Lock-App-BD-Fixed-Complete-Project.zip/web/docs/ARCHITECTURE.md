# Lock App BD — আর্কিটেকচার (Phase 1)

**Package:** `com.mohammadrakib.lockappbd` · **Developer:** Mohammad Rakib

> ⚠️ বর্তমান অবস্থা: Phase 1 + Phase 2 সম্পন্ন (প্রজেক্ট কাঠামো + দ্বিভাষিক UI)।
> নেটিভ Android কোড এখনও লেখা হয়নি। তাই **কোনো অ্যাপ এখন আসলে লক হয় না**।

## ১. স্তরগুলো (Layers)

```
┌───────────────────────────────────────────┐
│ React + TypeScript + Tailwind (WebView UI) │  ← এখন তৈরি (Phase 2)
├───────────────────────────────────────────┤
│ src/services/nativeBridge.ts (একটি মাত্র সেতু) │  ← এখন: শুধু web-preview
├───────────────────────────────────────────┤
│ Capacitor Plugin (Java/Kotlin)             │  ← Phase 4–7
├───────────────────────────────────────────┤
│ Android: PackageManager, UsageStatsManager,│
│ Foreground Service, Lock Activity,         │  ← Phase 5–8
│ BiometricPrompt, Keystore                  │
└───────────────────────────────────────────┘
```

**মূল নিয়ম:** অন্য অ্যাপ রক্ষার কাজ কখনও React স্ক্রিনের উপর নির্ভর করবে না।
লক স্ক্রিন হবে নেটিভ `LockActivity`; React শুধু সেটিংস/ব্যবস্থাপনার UI।

## ২. বর্তমান ফাইল কাঠামো

```
index.html                     শিরোনাম, viewport, theme-color
src/
  main.tsx                     এন্ট্রি
  App.tsx                      Provider + ErrorBoundary + ফোন-ফ্রেম
  index.css                    থিম টোকেন (ডার্ক/লাইট), অফলাইন বাংলা ফন্ট, অ্যানিমেশন
  config.ts                    নাম, প্যাকেজ, ভার্সন, সোশ্যাল লিংক (গোপন কিছু নেই)
  types.ts                     সব টাইপ
  i18n/translations.ts         বাংলা + English (প্রতিটি টেক্সট; কী না মিললে বিল্ড ফেল)
  state/AppContext.tsx         সেটিংস, ভাষা, থিম, লক তালিকা, PIN যাচাই, লকআউট
  services/
    storage.ts                 লোকাল সংরক্ষণ + অবৈধ ডেটা পরিষ্কার (sanitize)
    pinSecurity.ts             PBKDF2-SHA256 (২১০,০০০ বার, র‍্যান্ডম salt), রিকভারি কোড, লকআউট নীতি
    nativeBridge.ts            UI ↔ Android সেতু (এখন ওয়েব-প্রিভিউ)
  data/
    exclusions.ts              যে প্যাকেজ কখনও লক করা যাবে না
    mockApps.ts                শুধু ডেমো অ্যাপ তালিকা
  components/                  Button, Card, Toggle, Sheet, PinPad, PatternLock, Logo, AppIcon, ...
  screens/                     Onboarding, Dashboard, Apps, Security, Settings,
                               Permissions, Privacy, About, LockDemo, SetPattern, Main
docs/ARCHITECTURE.md           এই ফাইল
```

## ৩. পরিকল্পিত Android কাঠামো (Phase 4 থেকে তৈরি হবে)

```
android/app/src/main/
  AndroidManifest.xml
  java/com/mohammadrakib/lockappbd/
    MainActivity.java                 (Capacitor)
    plugin/LockAppPlugin.java         (JS ↔ নেটিভ)
    apps/InstalledAppsProvider.java   (PackageManager + exclusion তালিকা)
    engine/ForegroundWatcherService.java  (সামনের অ্যাপ শনাক্ত)
    engine/LockActivity.java          (নেটিভ লক স্ক্রিন)
    engine/BootReceiver.java          (রিবুটের পর পুনরায় চালু)
    security/SecretStore.java         (PBKDF2 + Keystore)
    security/BiometricHelper.java     (BiometricPrompt)
  res/ (আইকন, splash, strings bn/en)
.github/workflows/android.yml        (Phase 10)
```

## ৪. গুরুত্বপূর্ণ নকশা-সিদ্ধান্ত

### ৪.১ ইনস্টল করা অ্যাপ দেখা (Package visibility)
- Android 11+ এ অন্য অ্যাপ দেখতে সীমাবদ্ধতা আছে।
- `QUERY_ALL_PACKAGES` **ব্যবহার করা হবে না** (Google Play-তে কঠোর অনুমোদন লাগে)।
- বদলে `AndroidManifest.xml`-এ `<queries>` দিয়ে `MAIN` + `LAUNCHER` intent ঘোষণা হবে।
  এতে শুধু লঞ্চার-যোগ্য (ব্যবহারকারীর দেখা) অ্যাপ পাওয়া যায়, যা আমাদের দরকার।

### ৪.২ সামনের অ্যাপ শনাক্তের দুই পদ্ধতি
| | স্ট্যান্ডার্ড (ডিফল্ট) | অ্যাক্সেসিবিলিটি (ঐচ্ছিক) |
|---|---|---|
| API | `UsageStatsManager` + ফোরগ্রাউন্ড সার্ভিস | `AccessibilityService` |
| অনুমতি | Usage access + Display over other apps | Accessibility সার্ভিস চালু |
| গতি | কয়েক শ’ ms পোলিং (ব্যাটারি খরচ বেশি) | তাৎক্ষণিক, ইভেন্ট-ভিত্তিক |
| Play নীতি | তুলনামূলক সহজ | কঠোর: Permissions Declaration + ভিডিও + ডিসক্লোজার |

- ডিফল্ট হবে স্ট্যান্ডার্ড। অ্যাক্সেসিবিলিটি শুধু স্পষ্ট ডিসক্লোজার ও সম্মতির পর।
- অ্যাক্সেসিবিলিটি সার্ভিস শুধু প্যাকেজ নাম ও `TYPE_WINDOW_STATE_CHANGED` ইভেন্ট পড়বে।
  স্ক্রিনের লেখা/পাসওয়ার্ড পড়বে না, কিছু আপলোড করবে না, নিজে ক্লিক/টাইপ করবে না।
- সত্যিকারের ব্যাটারি/Android-সংস্করণ আচরণ **Phase 6-এ বাস্তব ডিভাইসে পরীক্ষা** করে চূড়ান্ত হবে।
  (Android 10+ এ ব্যাকগ্রাউন্ড থেকে Activity চালানোর বিধিনিষেধ আছে; তাই overlay অনুমতি লাগবে।)

### ৪.৩ কখনও লক হবে না
`data/exclusions.ts`: নিজের অ্যাপ, Settings, Phone/Dialer/Emergency, System UI, লঞ্চার, কিবোর্ড,
প্যাকেজ ইনস্টলার, Permission Controller। এই নিয়ম Phase 5-এ নেটিভ কোডেও থাকবে।

### ৪.৪ পুনরুদ্ধার ও নিয়ন্ত্রণ
- সেটআপের সময় একবার রিকভারি কোড (৮০-বিট, PBKDF2 হ্যাশে সংরক্ষিত) দেখানো হয়।
- ভুল চেষ্টা: ৫ বারে ৩০ সে, ৬ বারে ১ মি, ৭ বারে ৫ মি, ৮+ এ ১৫ মি।
- ব্যবহারকারী যেকোনো সময় Android Settings থেকে অনুমতি বন্ধ বা অ্যাপ আনইনস্টল করতে পারবেন —
  Settings অ্যাপ লক তালিকায় আসেই না।
- Phase 7-এ লকআউট সময় `SystemClock.elapsedRealtime()` দিয়ে হবে (ঘড়ি বদলে ফাঁকি রোধ)।

### ৪.৫ গোপনীয়তা
- বিজ্ঞাপন/অ্যানালিটিক্স SDK নেই; `INTERNET` অনুমতি চাওয়া হবে না।
- সোশ্যাল লিংক শুধু Android intent দিয়ে বাইরের অ্যাপ/ব্রাউজারে খোলে (হোস্ট allow-list: `t.me`, `chat.whatsapp.com`)।
- ফন্ট অ্যাপের ভেতরেই বান্ডেল করা (Google Fonts-এ ইন্টারনেট রিকোয়েস্ট নেই)।

## ৫. ধাপ পরিকল্পনা

| Phase | কাজ | অবস্থা |
|---|---|---|
| 1 | আর্কিটেকচার ও ফাইল কাঠামো | ✅ |
| 2 | দ্বিভাষিক প্রিমিয়াম UI | ✅ (ওয়েব প্রিভিউ) |
| 3 | লোকাল সেটিংস/ভাষা সংরক্ষণ | 🟡 ওয়েব-লেভেলে আগেই হয়েছে; নেটিভে পুনর্যাচাই |
| 4 | Capacitor Android প্রজেক্ট | ⏳ |
| 5 | আসল অ্যাপ তালিকা (নেটিভ) | ⏳ |
| 6 | নেটিভ লক ইঞ্জিন | ⏳ |
| 7 | PIN/প্যাটার্ন/বায়োমেট্রিক (নেটিভ + Keystore) | ⏳ |
| 8 | পারমিশন ও প্রাইভেসি (নেটিভ) | ⏳ |
| 9 | টেস্ট ও বাগ ফিক্স | ⏳ |
| 10 | GitHub Actions APK বিল্ড | ⏳ |
