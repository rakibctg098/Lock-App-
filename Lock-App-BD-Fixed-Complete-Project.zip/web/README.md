# Lock App BD

বিজ্ঞাপনমুক্ত Android অ্যাপ লকার — React + TypeScript + Tailwind + Capacitor + নেটিভ Android।

- **Package:** `com.mohammadrakib.lockappbd`
- **Developer:** Mohammad Rakib
- Telegram: https://t.me/appdevbyrakib

## ⚠️ সৎ অবস্থা (Phase 1–2 শেষে)

| বিষয় | অবস্থা |
|---|---|
| দ্বিভাষিক UI (বাংলা/English), ডার্ক/লাইট থিম | ✅ কাজ করে (ওয়েব প্রিভিউ) |
| PIN/প্যাটার্ন হ্যাশ (PBKDF2), রিকভারি কোড, ভুল-চেষ্টা লকআউট | ✅ ওয়েব প্রিভিউতে কাজ করে ও পরীক্ষিত |
| আসল ইনস্টল করা অ্যাপের তালিকা | ❌ এখনও নেই (ডেমো ডেটা) — Phase 5 |
| অন্য অ্যাপ আসলে লক করা | ❌ এখনও নেই — Phase 6 |
| ফিঙ্গারপ্রিন্ট (BiometricPrompt) | ❌ এখনও নেই — Phase 7 |
| APK বিল্ড | ❌ এখনও নেই — Phase 10 |

## চালানো (কম্পিউটারে)

```bash
npm install
npm run dev      # ডেভেলপমেন্ট
npm run build    # dist/index.html তৈরি
```

আরও জানতে: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)


## 🔎 অতিরিক্ত কোড অডিট (2026-11-08)

এই আপডেটে কয়েকটি নিরাপত্তা/ব্যবহারযোগ্যতা-সংক্রান্ত সংশোধন করা হয়েছে:
- Reset confirmation সফল হলে এখন reset screen বন্ধ হয়ে onboarding-এ ফিরে যায়।
- External link validation-এ credential ও অপ্রয়োজনীয় port প্রত্যাখ্যান করা হয়; শুধু অনুমোদিত HTTPS host খোলা যায়।
- Local storage থেকে secret record পড়ার সময় iteration integer ও salt/hash length যাচাই করা হয়।

### এখনো যেসব কাজ বাকি
এই ZIP এখনো **Web Preview**। `src/services/nativeBridge.ts`-এ কেবল mock app list আছে; Android native implementation নেই। ফলে installed-app discovery, real app blocking/foreground monitoring, Android biometric prompt, Android Keystore, permission settings launch এবং APK build এখনো বাস্তবায়ন/পরীক্ষা করা হয়নি। UI-তে app lock toggle করা মানে অন্য অ্যাপ সত্যি লক হয়ে যাওয়া নয়।

### Build যাচাইয়ের সীমাবদ্ধতা
এই পরিবেশে `node_modules` অসম্পূর্ণ/খালি থাকায় `npm run build` চালানো যায়নি (`vite: Permission denied` / Vite executable অনুপস্থিত)। তাই source-level পরিবর্তন করা হলেও production build সফল হয়েছে—এমন দাবি করা হচ্ছে না। পূর্ণ build যাচাইয়ের জন্য dependency install করে `npm ci && npm run build` চালাতে হবে।
