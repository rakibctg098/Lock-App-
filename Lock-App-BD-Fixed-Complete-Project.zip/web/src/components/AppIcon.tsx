import type { AppInfo } from "@/types";

/** Shows the real native icon when available, otherwise a colored letter tile. */
export function AppIcon({ app, size = 48 }: { app: AppInfo; size?: number }) {
  const letter = Array.from(app.label.trim())[0] ?? "?";
  if (app.iconDataUri) {
    return (
      <img
        src={app.iconDataUri}
        alt=""
        width={size}
        height={size}
        className="shrink-0 rounded-[24%] object-cover"
        style={{ width: size, height: size }}
      />
    );
  }
  return (
    <div
      aria-hidden="true"
      className="flex shrink-0 items-center justify-center rounded-[24%] font-bold text-white shadow-sm"
      style={{
        width: size,
        height: size,
        fontSize: size * 0.44,
        background: `linear-gradient(135deg, hsl(${app.hue} 80% 58%), hsl(${(app.hue + 40) % 360} 75% 40%))`,
      }}
    >
      {letter.toUpperCase()}
    </div>
  );
}
