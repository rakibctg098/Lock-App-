import {
  useEffect,
  type ButtonHTMLAttributes,
  type HTMLAttributes,
  type ReactNode,
} from "react";
import { ArrowLeft, ChevronRight, FlaskConical, X } from "lucide-react";
import { cn } from "@/utils/cn";
import { useApp } from "@/state/AppContext";

// ---------- Card ----------
export function Card({
  className,
  children,
  ...rest
}: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "rounded-3xl border border-line bg-surface shadow-card",
        className,
      )}
      {...rest}
    >
      {children}
    </div>
  );
}

// ---------- Button ----------
type Variant = "primary" | "secondary" | "ghost" | "danger";
type Size = "sm" | "md" | "lg";

const VARIANTS: Record<Variant, string> = {
  primary:
    "bg-gradient-to-br from-brand to-brand2 text-white shadow-glow hover:brightness-110",
  secondary: "bg-surface2 text-ink border border-line hover:brightness-110",
  ghost: "bg-transparent text-brand hover:bg-surface2",
  danger: "bg-bad text-white hover:brightness-110",
};
const SIZES: Record<Size, string> = {
  sm: "h-10 px-4 text-sm",
  md: "h-12 px-5 text-base",
  lg: "h-14 px-6 text-lg",
};

export function Button({
  variant = "primary",
  size = "md",
  full,
  className,
  children,
  type = "button",
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant;
  size?: Size;
  full?: boolean;
}) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-2xl font-semibold transition active:scale-[0.98] disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand",
        VARIANTS[variant],
        SIZES[size],
        full && "w-full",
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
}

// ---------- Toggle ----------
export function Toggle({
  checked,
  onChange,
  label,
  disabled,
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  label: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={(e) => {
        e.stopPropagation();
        onChange(!checked);
      }}
      className={cn(
        "relative h-7 w-12 shrink-0 rounded-full transition-colors disabled:opacity-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand",
        checked ? "bg-gradient-to-r from-brand to-brand2" : "bg-muted/40",
      )}
    >
      <span
        className={cn(
          "absolute left-0.5 top-0.5 h-6 w-6 rounded-full bg-white shadow transition-transform",
          checked && "translate-x-5",
        )}
      />
    </button>
  );
}

// ---------- Segmented control ----------
export function Segmented<T extends string | number>({
  value,
  options,
  onChange,
  ariaLabel,
}: {
  value: T;
  options: { value: T; label: string; disabled?: boolean }[];
  onChange: (v: T) => void;
  ariaLabel: string;
}) {
  return (
    <div
      role="radiogroup"
      aria-label={ariaLabel}
      className="flex rounded-2xl border border-line bg-surface2 p-1"
    >
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={String(o.value)}
            type="button"
            role="radio"
            aria-checked={active}
            disabled={o.disabled}
            onClick={() => onChange(o.value)}
            className={cn(
              "h-10 flex-1 rounded-xl px-3 text-sm font-semibold transition disabled:opacity-40",
              active
                ? "bg-gradient-to-br from-brand to-brand2 text-white shadow-glow"
                : "text-muted hover:text-ink",
            )}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

// ---------- List row ----------
export function Row({
  icon,
  title,
  subtitle,
  right,
  onClick,
  tone = "brand",
}: {
  icon?: ReactNode;
  title: string;
  subtitle?: string;
  right?: ReactNode;
  onClick?: () => void;
  tone?: "brand" | "bad" | "ok";
}) {
  const content = (
    <>
      {icon && (
        <span
          className={cn(
            "flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl",
            tone === "bad"
              ? "bg-bad/15 text-bad"
              : tone === "ok"
                ? "bg-ok/15 text-ok"
                : "bg-brand/15 text-brand",
          )}
        >
          {icon}
        </span>
      )}
      <span className="min-w-0 flex-1 text-left">
        <span
          className={cn(
            "block truncate font-semibold",
            tone === "bad" && "text-bad",
          )}
        >
          {title}
        </span>
        {subtitle && (
          <span className="block text-sm leading-snug text-muted">{subtitle}</span>
        )}
      </span>
      {right ?? (onClick ? <ChevronRight className="h-5 w-5 shrink-0 text-muted" /> : null)}
    </>
  );
  const cls = "flex w-full items-center gap-3 px-4 py-3.5";
  if (onClick) {
    return (
      <button
        type="button"
        onClick={onClick}
        className={cn(cls, "transition hover:bg-surface2 active:bg-surface2")}
      >
        {content}
      </button>
    );
  }
  return <div className={cls}>{content}</div>;
}

export function RowGroup({ children }: { children: ReactNode }) {
  return (
    <Card className="divide-y divide-line overflow-hidden">{children}</Card>
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <h2 className="mb-2 mt-6 px-1 text-xs font-semibold uppercase tracking-wide text-muted first:mt-0">
      {children}
    </h2>
  );
}

// ---------- Bottom sheet ----------
export function Sheet({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}) {
  const { t } = useApp();
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="absolute inset-0 z-40 flex items-end">
      <div
        className="absolute inset-0 animate-fade bg-black/60 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="relative max-h-[92%] w-full animate-sheet overflow-y-auto rounded-t-[2rem] border-t border-line bg-surface p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] shadow-card"
      >
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="text-lg font-bold">{title}</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={t("common.close")}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-surface2 text-muted hover:text-ink"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ---------- Sub page with back button ----------
export function SubPage({
  title,
  onBack,
  children,
}: {
  title: string;
  onBack: () => void;
  children: ReactNode;
}) {
  const { t } = useApp();
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <header className="flex items-center gap-3 px-4 pb-3 pt-[max(1rem,env(safe-area-inset-top))]">
        <button
          type="button"
          onClick={onBack}
          aria-label={t("common.back")}
          className="flex h-11 w-11 items-center justify-center rounded-2xl border border-line bg-surface text-ink transition active:scale-95"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="min-w-0 flex-1 truncate text-xl font-bold">{title}</h1>
      </header>
      <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto px-5 pb-[max(2rem,env(safe-area-inset-bottom))]">
        {children}
      </div>
    </div>
  );
}

// ---------- Honest preview notice ----------
export function PreviewNotice({ compact }: { compact?: boolean }) {
  const { t } = useApp();
  return (
    <div
      role="note"
      className="flex gap-3 rounded-2xl border border-warn/40 bg-warn/10 p-3.5"
    >
      <FlaskConical className="mt-0.5 h-5 w-5 shrink-0 text-warn" />
      <div className="min-w-0">
        <p className="text-sm font-semibold text-warn">{t("preview.title")}</p>
        {!compact && (
          <p className="mt-0.5 text-sm leading-snug text-muted">{t("preview.body")}</p>
        )}
      </div>
    </div>
  );
}

export function Toast() {
  const { toast } = useApp();
  return (
    <div
      aria-live="polite"
      className="pointer-events-none absolute inset-x-0 bottom-24 z-50 flex justify-center px-6"
    >
      {toast && (
        <div className="animate-rise rounded-2xl border border-line bg-surface2 px-4 py-3 text-center text-sm font-semibold shadow-card">
          {toast}
        </div>
      )}
    </div>
  );
}
