import { useEffect, useRef, useState, type PointerEvent } from "react";
import { cn } from "@/utils/cn";

interface Props {
  /** Called with the dot indexes (0-8) when the finger is lifted. */
  onComplete: (sequence: number[]) => void;
  disabled?: boolean;
  error?: boolean;
  shakeKey?: number;
}

const SIZE = 300;
const center = (i: number) => ({ x: 50 + (i % 3) * 100, y: 50 + Math.floor(i / 3) * 100 });

export function PatternLock({ onComplete, disabled, error, shakeKey = 0 }: Props) {
  const svgRef = useRef<SVGSVGElement>(null);
  const pathRef = useRef<number[]>([]);
  const drawingRef = useRef(false);
  const lockedRef = useRef(false);
  const timerRef = useRef<number | undefined>(undefined);
  const [path, setPath] = useState<number[]>([]);
  const [pointer, setPointer] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => () => window.clearTimeout(timerRef.current), []);

  const toLocal = (e: PointerEvent) => {
    const rect = svgRef.current!.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * SIZE,
      y: ((e.clientY - rect.top) / rect.height) * SIZE,
    };
  };

  const addDot = (i: number) => {
    const p = pathRef.current;
    if (p.includes(i)) return;
    const next = [...p];
    const last = p[p.length - 1];
    if (last !== undefined) {
      // Skipping over an untouched middle dot includes it (like Android).
      const dr = Math.abs(Math.floor(last / 3) - Math.floor(i / 3));
      const dc = Math.abs((last % 3) - (i % 3));
      if (dr % 2 === 0 && dc % 2 === 0 && dr + dc > 0) {
        const mid = (last + i) / 2;
        if (!p.includes(mid)) next.push(mid);
      }
    }
    next.push(i);
    pathRef.current = next;
    setPath(next);
  };

  const hitTest = (x: number, y: number) => {
    for (let i = 0; i < 9; i++) {
      const c = center(i);
      if (Math.hypot(c.x - x, c.y - y) < 38) addDot(i);
    }
  };

  const onDown = (e: PointerEvent<SVGSVGElement>) => {
    if (disabled || lockedRef.current) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    drawingRef.current = true;
    pathRef.current = [];
    setPath([]);
    const pt = toLocal(e);
    setPointer(pt);
    hitTest(pt.x, pt.y);
  };

  const onMove = (e: PointerEvent<SVGSVGElement>) => {
    if (!drawingRef.current) return;
    const pt = toLocal(e);
    setPointer(pt);
    hitTest(pt.x, pt.y);
  };

  const finish = () => {
    if (!drawingRef.current) return;
    drawingRef.current = false;
    setPointer(null);
    const seq = pathRef.current;
    if (seq.length === 0) return;
    lockedRef.current = true;
    onComplete([...seq]);
    timerRef.current = window.setTimeout(() => {
      pathRef.current = [];
      setPath([]);
      lockedRef.current = false;
    }, 650);
  };

  const points = path.map((i) => `${center(i).x},${center(i).y}`).join(" ");
  const last = path.length ? center(path[path.length - 1]) : null;

  return (
    <div key={shakeKey} className={cn("mx-auto w-full max-w-[17rem]", error && "animate-shake")}>
      <svg
        ref={svgRef}
        viewBox={`0 0 ${SIZE} ${SIZE}`}
        className={cn("aspect-square w-full touch-none select-none", disabled && "opacity-40")}
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={finish}
        onPointerCancel={finish}
        role="application"
        aria-label="Pattern lock"
      >
        {path.length > 1 && (
          <polyline
            points={points}
            fill="none"
            strokeWidth={8}
            strokeLinecap="round"
            strokeLinejoin="round"
            className={error ? "stroke-bad" : "stroke-brand"}
            opacity={0.85}
          />
        )}
        {last && pointer && (
          <line
            x1={last.x}
            y1={last.y}
            x2={pointer.x}
            y2={pointer.y}
            strokeWidth={8}
            strokeLinecap="round"
            className={error ? "stroke-bad" : "stroke-brand"}
            opacity={0.5}
          />
        )}
        {Array.from({ length: 9 }).map((_, i) => {
          const c = center(i);
          const active = path.includes(i);
          return (
            <g key={i}>
              <circle
                cx={c.x}
                cy={c.y}
                r={active ? 30 : 24}
                strokeWidth={3}
                className={cn(
                  "fill-transparent transition-all",
                  active ? (error ? "stroke-bad" : "stroke-brand") : "stroke-muted/50",
                )}
              />
              <circle
                cx={c.x}
                cy={c.y}
                r={active ? 11 : 8}
                className={cn(
                  "transition-all",
                  active ? (error ? "fill-bad" : "fill-brand") : "fill-muted/70",
                )}
              />
            </g>
          );
        })}
      </svg>
    </div>
  );
}
