import { useState } from "react";
import { KeyRound } from "lucide-react";
import { PinPad } from "@/components/PinPad";
import { Segmented } from "@/components/ui";
import { LockoutNotice } from "@/components/LockoutNotice";
import { RecoveryCodeView } from "@/components/RecoveryCodeView";
import { useApp, useLockoutRemaining } from "@/state/AppContext";
import { isWeakPin } from "@/services/pinSecurity";
import type { PinLength } from "@/types";

type Step = "current" | "enter" | "confirm" | "recovery";

/**
 * PIN creation / change flow:
 * [current PIN] -> enter new PIN -> confirm -> show recovery code once.
 * Used by onboarding (no current PIN) and by "Change PIN" / "Forgot PIN" (recovery).
 */
export function PinSetupFlow({
  requireCurrent,
  onDone,
  doneLabel,
}: {
  requireCurrent: boolean;
  onDone: () => void;
  doneLabel: string;
}) {
  const { t, state, attempt, savePin, showToast } = useApp();
  const remaining = useLockoutRemaining();
  const [step, setStep] = useState<Step>(requireCurrent ? "current" : "enter");
  const [length, setLength] = useState<PinLength>(state.pinLength);
  const [first, setFirst] = useState("");
  const [error, setError] = useState("");
  const [shake, setShake] = useState(0);
  const [busy, setBusy] = useState(false);
  const [code, setCode] = useState("");

  const fail = (message: string) => {
    setError(message);
    setShake((n) => n + 1);
  };

  const onCurrent = async (pin: string) => {
    if (busy) return;
    setBusy(true);
    const r = await attempt("pin", pin);
    setBusy(false);
    if (r.ok) {
      setError("");
      setStep("enter");
    } else {
      fail(r.error === "crypto" ? t("pin.cryptoError") : r.locked ? "" : t("pin.wrong"));
    }
  };

  const onEnter = (pin: string) => {
    if (isWeakPin(pin)) {
      fail(t("pin.weak"));
      return;
    }
    setError("");
    setFirst(pin);
    setStep("confirm");
  };

  const onConfirm = async (pin: string) => {
    if (busy) return;
    if (pin !== first) {
      setFirst("");
      setStep("enter");
      fail(t("pin.mismatch"));
      return;
    }
    setBusy(true);
    try {
      const newCode = await savePin(pin, length);
      setCode(newCode);
      setError("");
      setStep("recovery");
      showToast(t("pin.saved"));
    } catch {
      setFirst("");
      setStep("enter");
      fail(t("pin.cryptoError"));
    } finally {
      setBusy(false);
    }
  };

  if (step === "recovery") {
    return <RecoveryCodeView code={code} onDone={onDone} doneLabel={doneLabel} />;
  }

  const titleKey =
    step === "current"
      ? "pin.current.title"
      : step === "enter"
        ? "pin.new.title"
        : "pin.confirm.title";
  const subtitleKey =
    step === "current"
      ? "pin.current.subtitle"
      : step === "enter"
        ? "pin.new.subtitle"
        : "pin.confirm.subtitle";

  const padLength = step === "current" ? state.pinLength : length;
  const handler = step === "current" ? onCurrent : step === "enter" ? onEnter : onConfirm;

  return (
    <div className="flex flex-col items-center text-center">
      <span className="flex h-16 w-16 items-center justify-center rounded-3xl bg-brand/15 text-brand">
        <KeyRound className="h-8 w-8" />
      </span>
      <h2 className="mt-4 text-2xl font-bold">{t(titleKey)}</h2>
      <p className="mt-1 text-sm text-muted">{t(subtitleKey)}</p>

      {step === "enter" && (
        <div className="mt-4 w-full max-w-xs">
          <Segmented<PinLength>
            ariaLabel={t("pin.new.title")}
            value={length}
            onChange={(v) => {
              setLength(v);
              setError("");
            }}
            options={[
              { value: 4, label: t("pin.length4") },
              { value: 6, label: t("pin.length6") },
            ]}
          />
        </div>
      )}

      <div className="mb-6 mt-4 min-h-6">
        <LockoutNotice remaining={step === "current" ? remaining : 0} error={error} />
      </div>

      <PinPad
        length={padLength}
        onComplete={handler}
        disabled={busy || (step === "current" && remaining > 0)}
        error={!!error || (step === "current" && remaining > 0)}
        shakeKey={shake}
      />

      <p className="mt-8 max-w-xs text-xs leading-relaxed text-muted">{t("pin.storageNote")}</p>
    </div>
  );
}
