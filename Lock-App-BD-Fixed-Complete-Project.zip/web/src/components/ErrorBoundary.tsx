import { Component, type ErrorInfo, type ReactNode } from "react";

/** Last-resort safety net so an unexpected error never leaves a blank screen. */
export class ErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // Local console only. Nothing is ever sent anywhere.
    console.error("Lock App BD error:", error, info.componentStack);
  }

  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <div
        style={{
          minHeight: "100dvh",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 12,
          padding: 24,
          textAlign: "center",
          background: "#060b1c",
          color: "#eef3ff",
          fontFamily: "'Hind Siliguri', system-ui, sans-serif",
        }}
      >
        <h1 style={{ fontSize: 22, fontWeight: 700 }}>কিছু একটা ভুল হয়েছে / Something went wrong</h1>
        <p style={{ color: "#9db0da" }}>অ্যাপটি আবার চালু করুন। / Please reload the app.</p>
        <button
          type="button"
          onClick={() => window.location.reload()}
          style={{
            height: 48,
            padding: "0 24px",
            borderRadius: 16,
            border: 0,
            fontWeight: 700,
            color: "#fff",
            background: "linear-gradient(135deg,#3b82f6,#6366f1)",
          }}
        >
          Reload / আবার চালু
        </button>
      </div>
    );
  }
}
