import { Lock } from "lucide-react";
import { cn } from "@/utils/cn";

export function Logo({ size = 44, className }: { size?: number; className?: string }) {
  return (
    <div
      className={cn(
        "relative flex shrink-0 items-center justify-center rounded-[28%] bg-gradient-to-br from-sky-400 via-brand to-brand2 shadow-glow",
        className,
      )}
      style={{ width: size, height: size }}
      aria-hidden="true"
    >
      <div className="absolute inset-[7%] rounded-[26%] border border-white/25" />
      <Lock className="text-white" style={{ width: size * 0.5, height: size * 0.5 }} strokeWidth={2.4} />
    </div>
  );
}
