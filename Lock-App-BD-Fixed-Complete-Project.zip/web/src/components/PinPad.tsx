import { useCallback, useEffect, useRef, useState } from "react";
import { Delete } from "lucide-react";
import { cn } from "@/utils/cn";
import { useApp } from "@/state/AppContext";

interface Props {
  length: number;
  onComplete: (pin: string) => void;
  disabled?: boolean;
  error?: boolean;
  /** Change this number to replay the shake animation. */
  shakeKey?: number;
}

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9"];

export function PinPad({ length, onComplete, disabled, error, shakeKey = 0 }: Props) {
  const { t } = useApp();
  const [value, setValue] = useState("");
  const busyRef = useRef(false);
  const completeRef = useRef(onComplete);
  const disabledRef = useRef(disabled);

  useEffect(() => {
    completeRef.current = onComplete;
    disabledRef.current = disabled;
  });

  // A different PIN length means a fresh start.
  useEffect(() => {
    setValue("");
    busyRef.current = false;
  }, [length]);

  const push = useCallback(
    (digit: string) => {
      if (disabledRef.current || busyRef.current) return;
      setValue((v) => (v.length >= length ? v : v + digit));
    },
    [length],
  );
  const backspace = useCallback(() => {
    if (disabledRef.current || busyRef.current) return;
    setValue((v) => v.slice(0, -1));
  }, []);

  // Auto-submit when all digits are entered; small delay so the last dot is seen.
  useEffect(() => {
    if (value.length !== length) return;
    busyRef.current = true;
    const id = window.setTimeout(() => {
      const entered = value;
      setValue("");
      busyRef.current = false;
      completeRef.current(entered);
    }, 140);
    return () => {
      window.clearTimeout(id);
      busyRef.current = false;
    };
  }, [value, length]);

  // Hardware keyboard support (also helpful for testing on a computer).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      if (/^[0-9]$/.test(e.key)) push(e.key);
      else if (e.key === "Backspace") backspace();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [push, backspace]);

  return (
    <div className="flex w-full flex-col items-center">
      <div
        key={shakeKey}
        role="img"
        aria-label={`${value.length}/${length}`}
        className={cn("flex h-6 items-center justify-center gap-4", error && "animate-shake")}
      >
        {Array.from({ length }).map((_, i) => (
          <span
            key={i}
            className={cn(
              "h-4 w-4 rounded-full border-2 transition-all",
              i < value.length
                ? error
                  ? "scale-110 border-bad bg-bad"
                  : "scale-110 border-brand bg-brand"
                : "border-muted/60 bg-transparent",
            )}
          />
        ))}
      </div>

      <div className="mt-8 grid w-full max-w-[18rem] grid-cols-3 gap-x-5 gap-y-4">
        {KEYS.map((k) => (
          <PadKey key={k} onPress={() => push(k)} disabled={disabled}>
            {k}
          </PadKey>
        ))}
        <span />
        <PadKey onPress={() => push("0")} disabled={disabled}>
          0
        </PadKey>
        <PadKey onPress={backspace} disabled={disabled} label={t("common.back")} subtle>
          <Delete className="h-6 w-6" />
        </PadKey>
      </div>
    </div>
  );
}

function PadKey({
  children,
  onPress,
  disabled,
  label,
  subtle,
}: {
  children: React.ReactNode;
  onPress: () => void;
  disabled?: boolean;
  label?: string;
  subtle?: boolean;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      disabled={disabled}
      onClick={onPress}
      className={cn(
        "mx-auto flex h-[4.25rem] w-[4.25rem] items-center justify-center rounded-full text-2xl font-semibold transition active:scale-90 disabled:opacity-40",
        subtle
          ? "text-muted hover:text-ink"
          : "border border-line bg-surface2 text-ink hover:brightness-110",
      )}
    >
      {children}
    </button>
  );
}
