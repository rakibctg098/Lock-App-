import { useState } from "react";
import { LifeBuoy } from "lucide-react";
import { Button } from "@/components/ui";
import { useApp } from "@/state/AppContext";

/** Shows a freshly created recovery code once, and requires the user to confirm they saved it. */
export function RecoveryCodeView({
  code,
  onDone,
  doneLabel,
}: {
  code: string;
  onDone: () => void;
  doneLabel: string;
}) {
  const { t } = useApp();
  const [saved, setSaved] = useState(false);
  const groups = code.split("-");

  return (
    <div className="animate-rise">
      <div className="flex flex-col items-center text-center">
        <span className="flex h-16 w-16 items-center justify-center rounded-3xl bg-warn/15 text-warn">
          <LifeBuoy className="h-8 w-8" />
        </span>
        <h2 className="mt-4 text-2xl font-bold">{t("rec.title")}</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted">{t("rec.subtitle")}</p>
      </div>

      <div
        className="mt-6 grid grid-cols-2 gap-3 rounded-3xl border border-warn/40 bg-surface2 p-4"
        aria-label={t("rec.title")}
      >
        {groups.map((g, i) => (
          <span
            key={i}
            className="rounded-2xl bg-surface py-3 text-center font-mono text-xl font-bold tracking-widest"
          >
            {g}
          </span>
        ))}
      </div>
      <p className="mt-3 text-center text-xs text-muted">{t("rec.hint")}</p>

      <label className="mt-6 flex cursor-pointer items-start gap-3 rounded-2xl border border-line bg-surface p-4">
        <input
          type="checkbox"
          checked={saved}
          onChange={(e) => setSaved(e.target.checked)}
          className="mt-1 h-5 w-5 shrink-0 accent-[var(--brand)]"
        />
        <span className="text-sm font-semibold">{t("rec.saved")}</span>
      </label>

      <Button full size="lg" className="mt-5" disabled={!saved} onClick={onDone}>
        {doneLabel}
      </Button>
    </div>
  );
}
