import { useState } from "react";
import { Lock } from "lucide-react";
import { PinPad } from "@/components/PinPad";
import { LockoutNotice } from "@/components/LockoutNotice";
import { useApp, useLockoutRemaining } from "@/state/AppContext";

/** Asks for the current PIN (with lockout handling) before a sensitive action. */
export function PinGate({
  title,
  subtitle,
  onSuccess,
}: {
  title?: string;
  subtitle?: string;
  onSuccess: () => void;
}) {
  const { t, state, attempt } = useApp();
  const remaining = useLockoutRemaining();
  const [error, setError] = useState("");
  const [shake, setShake] = useState(0);
  const [busy, setBusy] = useState(false);

  const handle = async (pin: string) => {
    if (busy) return;
    setBusy(true);
    const r = await attempt("pin", pin);
    setBusy(false);
    if (r.ok) {
      setError("");
      onSuccess();
      return;
    }
    setError(r.error === "crypto" ? t("pin.cryptoError") : r.locked ? "" : t("pin.wrong"));
    setShake((n) => n + 1);
  };

  return (
    <div className="flex flex-col items-center pt-4 text-center">
      <span className="flex h-16 w-16 items-center justify-center rounded-3xl bg-brand/15 text-brand">
        <Lock className="h-8 w-8" />
      </span>
      <h2 className="mt-4 text-2xl font-bold">{title ?? t("gate.title")}</h2>
      <p className="mt-1 text-sm text-muted">{subtitle ?? t("gate.subtitle")}</p>
      <div className="mb-8 mt-3 min-h-6">
        <LockoutNotice remaining={remaining} error={error} />
      </div>
      <PinPad
        length={state.pinLength}
        onComplete={handle}
        disabled={remaining > 0 || busy}
        error={!!error || remaining > 0}
        shakeKey={shake}
      />
    </div>
  );
}
