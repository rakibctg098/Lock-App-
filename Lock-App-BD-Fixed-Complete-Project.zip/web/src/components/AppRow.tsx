import { AppIcon } from "@/components/AppIcon";
import { Toggle } from "@/components/ui";
import { useApp } from "@/state/AppContext";
import type { AppInfo } from "@/types";

/** One installed app with its protection toggle. The whole row is tappable. */
export function AppRow({ app }: { app: AppInfo }) {
  const { t, state, toggleLocked, showToast } = useApp();
  const locked = state.lockedApps.includes(app.packageName);

  const toggle = () => {
    toggleLocked(app);
    showToast(t(locked ? "apps.removed" : "apps.added", { name: app.label }));
  };

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={toggle}
      onKeyDown={(e) => {
        // Ignore keys coming from the inner switch; it handles its own click.
        if (e.target !== e.currentTarget) return;
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          toggle();
        }
      }}
      className="flex w-full cursor-pointer items-center gap-3 px-4 py-3 transition hover:bg-surface2 active:bg-surface2 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-brand"
    >
      <AppIcon app={app} size={46} />
      <div className="min-w-0 flex-1">
        <p className="truncate font-semibold">{app.label}</p>
        <p className="truncate font-mono text-xs text-muted">{app.packageName}</p>
      </div>
      <Toggle
        checked={locked}
        onChange={toggle}
        label={t("apps.toggle", { name: app.label })}
      />
    </div>
  );
}
