import { formatDuration, useApp } from "@/state/AppContext";

/** Shows either the lockout countdown or the latest error message. */
export function LockoutNotice({ remaining, error }: { remaining: number; error?: string }) {
  const { t, fmt } = useApp();
  if (remaining > 0) {
    return (
      <p role="alert" className="text-sm font-semibold text-bad">
        {t("pin.locked", { time: formatDuration(remaining, t, fmt) })}
      </p>
    );
  }
  if (error) {
    return (
      <p role="alert" className="text-sm font-semibold text-bad">
        {error}
      </p>
    );
  }
  return null;
}
