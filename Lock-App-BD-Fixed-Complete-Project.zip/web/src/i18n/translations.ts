import type { Lang } from "@/types";

const bn = {
  // ---- common ----
  "app.tagline": "আপনার অ্যাপ, আপনার নিয়ন্ত্রণ",
  "common.continue": "চালিয়ে যান",
  "common.back": "পেছনে",
  "common.cancel": "বাতিল",
  "common.confirm": "নিশ্চিত করুন",
  "common.done": "সম্পন্ন",
  "common.close": "বন্ধ করুন",
  "common.retry": "আবার চেষ্টা করুন",
  "common.required": "আবশ্যক",
  "common.optional": "ঐচ্ছিক",
  "common.all": "সব",
  "common.loading": "লোড হচ্ছে…",
  "common.error": "কিছু একটা ভুল হয়েছে। আবার চেষ্টা করুন।",
  "common.apps": "অ্যাপ",
  "time.sec": "{n} সেকেন্ড",
  "time.min": "{n} মিনিট",

  // ---- preview honesty ----
  "preview.badge": "প্রিভিউ মোড",
  "preview.title": "ডেমো প্রিভিউ — আসল লক এখনও সক্রিয় নয়",
  "preview.body":
    "এই তালিকা নমুনা ডেটা। নেটিভ Android কোড যোগ ও পরীক্ষা হওয়ার পর (Phase 5-6) আসল অ্যাপ দেখা ও লক করা যাবে।",
  "preview.unavailable":
    "প্রিভিউ মোডে এটি কাজ করে না। নেটিভ কোড যোগ হলে শুধু Android APK-তে কাজ করবে।",

  // ---- navigation ----
  "nav.home": "হোম",
  "nav.apps": "অ্যাপস",
  "nav.security": "নিরাপত্তা",
  "nav.settings": "সেটিংস",

  // ---- onboarding ----
  "ob.step": "ধাপ {n}/{total}",
  "ob.lang.title": "আপনার ভাষা বেছে নিন",
  "ob.lang.subtitle": "পরে সেটিংস থেকে যেকোনো সময় বদলাতে পারবেন।",
  "ob.welcome.title": "Lock App BD-তে স্বাগতম",
  "ob.welcome.subtitle":
    "বিজ্ঞাপনমুক্ত, অ্যাকাউন্ট ছাড়া, আপনার তথ্য শুধু আপনার ফোনে।",
  "ob.f1.title": "সম্পূর্ণ বিজ্ঞাপনমুক্ত",
  "ob.f1.desc": "কোনো বিজ্ঞাপন বা ট্র্যাকার নেই।",
  "ob.f2.title": "অফলাইন ও ব্যক্তিগত",
  "ob.f2.desc": "অ্যাকাউন্ট লাগে না। কোনো তথ্য আপলোড হয় না।",
  "ob.f3.title": "শক্তিশালী নিরাপত্তা",
  "ob.f3.desc": "PIN, প্যাটার্ন ও ফিঙ্গারপ্রিন্ট।",
  "ob.f4.title": "সবসময় আপনার নিয়ন্ত্রণে",
  "ob.f4.desc": "যেকোনো সময় অনুমতি বন্ধ বা অ্যাপ আনইনস্টল করতে পারবেন।",
  "ob.perm.title": "কেন কিছু অনুমতি লাগবে?",
  "ob.perm.subtitle":
    "অন্য অ্যাপ লক করতে Android-এর বিশেষ অনুমতি দরকার। প্রতিটি অনুমতি আপনার সম্মতি নিয়েই চালু হবে।",
  "ob.perm.note":
    "এখন কোনো অনুমতি চাওয়া হচ্ছে না। পরে “অনুমতি” পাতা থেকে নিজে চালু করবেন।",
  "ob.pin.title": "আপনার PIN সেট করুন",
  "ob.finish": "শুরু করুন",

  // ---- PIN ----
  "pin.current.title": "বর্তমান PIN দিন",
  "pin.current.subtitle": "চালিয়ে যেতে আগের PIN নিশ্চিত করুন।",
  "pin.new.title": "নতুন PIN দিন",
  "pin.new.subtitle": "PIN-এর দৈর্ঘ্য বেছে নিয়ে সংখ্যা দিন।",
  "pin.length4": "৪ সংখ্যা",
  "pin.length6": "৬ সংখ্যা",
  "pin.confirm.title": "PIN আবার দিন",
  "pin.confirm.subtitle": "নিশ্চিত করতে একই PIN আবার দিন।",
  "pin.mismatch": "PIN দুটি মেলেনি। নতুন করে শুরু করুন।",
  "pin.weak":
    "এই PIN খুব সহজ (যেমন 0000 বা 1234)। অন্য একটি PIN বেছে নিন।",
  "pin.wrong": "ভুল PIN। আবার চেষ্টা করুন।",
  "pin.locked": "অনেকবার ভুল হয়েছে। {time} পরে চেষ্টা করুন।",
  "pin.saved": "PIN সংরক্ষিত হয়েছে",
  "pin.cryptoError":
    "এই ব্রাউজারে নিরাপদ এনক্রিপশন সমর্থিত নয়, তাই PIN সংরক্ষণ করা যায়নি।",
  "pin.forgot": "PIN ভুলে গেছেন?",
  "pin.storageNote":
    "আপনার PIN কখনও সরাসরি সংরক্ষণ হয় না। লবণযুক্ত PBKDF2 হ্যাশ হিসেবে শুধু এই ডিভাইসে থাকে।",

  // ---- recovery ----
  "rec.title": "আপনার রিকভারি কোড",
  "rec.subtitle":
    "PIN ভুলে গেলে এই কোড দিয়ে নতুন PIN সেট করতে পারবেন। কোডটি কাগজে লিখে নিরাপদ জায়গায় রাখুন। এটি আর দেখানো হবে না।",
  "rec.saved": "আমি কোডটি নিরাপদে লিখে রেখেছি",
  "rec.enter.title": "রিকভারি কোড দিন",
  "rec.enter.subtitle": "PIN রিসেট করতে সেটআপের সময় পাওয়া কোডটি লিখুন।",
  "rec.wrong": "ভুল রিকভারি কোড।",
  "rec.verify": "যাচাই করুন",
  "rec.regen": "নতুন রিকভারি কোড তৈরি",
  "rec.regen.desc": "পুরনো কোড বাতিল হয়ে যাবে। আগে PIN দিতে হবে।",
  "rec.hint": "কোডে শুধু বড় হাতের ইংরেজি অক্ষর ও সংখ্যা থাকে।",
  "rec.later": "কোড হারালে পরে নিরাপত্তা পাতা থেকে নতুন কোড বানাতে পারবেন।",

  // ---- pattern ----
  "pat.draw": "প্যাটার্ন আঁকুন",
  "pat.confirm": "প্যাটার্ন আবার আঁকুন",
  "pat.hint": "কমপক্ষে ৪টি বিন্দু যোগ করুন।",
  "pat.tooShort": "কমপক্ষে ৪টি বিন্দু যোগ করতে হবে।",
  "pat.mismatch": "প্যাটার্ন মেলেনি। আবার চেষ্টা করুন।",
  "pat.saved": "প্যাটার্ন সংরক্ষিত হয়েছে",
  "pat.wrong": "ভুল প্যাটার্ন।",
  "pat.setTitle": "প্যাটার্ন লক সেট করুন",

  // ---- identity gate ----
  "gate.title": "পরিচয় নিশ্চিত করুন",
  "gate.subtitle": "চালিয়ে যেতে আপনার PIN দিন।",

  // ---- dashboard ----
  "dash.welcome": "স্বাগতম",
  "dash.protection": "সুরক্ষার অবস্থা",
  "dash.status.preview": "প্রিভিউ — লক নিষ্ক্রিয়",
  "dash.status.preview.desc":
    "নেটিভ লক ইঞ্জিন এখনও যোগ হয়নি, তাই কোনো অ্যাপ আসলে সুরক্ষিত নয়।",
  "dash.total": "মোট অ্যাপ",
  "dash.locked": "লক তালিকায়",
  "dash.method": "লক পদ্ধতি",
  "dash.search.placeholder": "অ্যাপ খুঁজুন…",
  "dash.search.empty": "কোনো অ্যাপ পাওয়া যায়নি",
  "dash.search.all": "সব অ্যাপ দেখুন",
  "dash.recent": "সম্প্রতি বেছে নেওয়া",
  "dash.recent.empty":
    "এখনও কোনো অ্যাপ বেছে নেননি। “অ্যাপস” ট্যাব থেকে শুরু করুন।",
  "dash.quick": "দ্রুত অ্যাক্সেস",
  "dash.quick.pin": "PIN",
  "dash.quick.fingerprint": "ফিঙ্গারপ্রিন্ট",
  "dash.quick.settings": "সেটিংস",
  "dash.perm.title": "অনুমতি সেটআপ বাকি",
  "dash.perm.desc": "অ্যাপ লক চালু করতে বিশেষ অনুমতি লাগবে। কেন লাগে তা দেখুন।",
  "dash.demo": "লক স্ক্রিন ডেমো দেখুন",

  // ---- apps ----
  "apps.title": "অ্যাপ লক ম্যানেজার",
  "apps.count": "{n}টি অ্যাপ",
  "apps.search": "নাম বা প্যাকেজ দিয়ে খুঁজুন…",
  "apps.filter.all": "সব",
  "apps.filter.locked": "লক তালিকায়",
  "apps.filter.unlocked": "বাইরে",
  "apps.empty": "কোনো অ্যাপ মেলেনি",
  "apps.emptyLocked": "এখনও কোনো অ্যাপ লক তালিকায় নেই",
  "apps.hidden": "{n}টি গুরুত্বপূর্ণ অ্যাপ নিরাপত্তার জন্য লুকানো আছে",
  "apps.hidden.why":
    "Lock App BD নিজে, Settings, ফোন/জরুরি কল, সিস্টেম UI, লঞ্চার ও কিবোর্ড লক করা যায় না, যাতে আপনি কখনও ফোনে আটকে না যান।",
  "apps.error": "অ্যাপের তালিকা লোড করা যায়নি।",
  "apps.added": "{name} তালিকায় যোগ হয়েছে",
  "apps.removed": "{name} তালিকা থেকে সরানো হয়েছে",
  "apps.toggle": "{name} সুরক্ষা চালু/বন্ধ",
  "apps.noPin": "অ্যাপ লক করার আগে PIN সেট করুন।",
  "cat.social": "সোশ্যাল",
  "cat.messaging": "মেসেজিং",
  "cat.finance": "আর্থিক",
  "cat.media": "মিডিয়া",
  "cat.tools": "টুলস",
  "cat.shopping": "শপিং",
  "cat.productivity": "প্রোডাক্টিভিটি",
  "cat.games": "গেমস",

  // ---- security ----
  "sec.title": "নিরাপত্তা",
  "sec.subtitle": "লক পদ্ধতি ও আনলক নিয়ন্ত্রণ",
  "sec.method.title": "সক্রিয় লক পদ্ধতি",
  "sec.method.pin": "PIN",
  "sec.method.pattern": "প্যাটার্ন",
  "sec.pin.change": "PIN পরিবর্তন করুন",
  "sec.pin.desc": "{n} সংখ্যার PIN সক্রিয়",
  "sec.pattern.set": "প্যাটার্ন সেট করুন",
  "sec.pattern.change": "প্যাটার্ন বদলান",
  "sec.pattern.notSet": "এখনও সেট করা হয়নি",
  "sec.pattern.active": "প্যাটার্ন সেট করা আছে",
  "sec.bio.title": "ফিঙ্গারপ্রিন্ট",
  "sec.bio.desc": "Android BiometricPrompt দিয়ে আনলক",
  "sec.bio.note":
    "প্রিভিউতে ফিঙ্গারপ্রিন্ট পরীক্ষা করা যায় না। আপনার পছন্দ সংরক্ষিত থাকবে; Android APK-তে ডিভাইস সমর্থন যাচাই হবে (Phase 7)।",
  "sec.bio.on": "ফিঙ্গারপ্রিন্ট পছন্দ চালু হয়েছে",
  "sec.bio.off": "ফিঙ্গারপ্রিন্ট পছন্দ বন্ধ হয়েছে",
  "sec.lockout.title": "ভুল চেষ্টার সুরক্ষা",
  "sec.lockout.desc":
    "৫ বার ভুল হলে ৩০ সেকেন্ড লক থাকবে, এরপর প্রতি ভুলে সময় বাড়বে (সর্বোচ্চ ১৫ মিনিট)।",
  "sec.demo": "লক স্ক্রিন ডেমো",
  "sec.demo.desc": "আপনার আসল PIN/প্যাটার্ন দিয়ে পরীক্ষা করুন",
  "sec.storage":
    "প্রিভিউতে গোপন তথ্য হ্যাশ হিসেবে ব্রাউজার স্টোরেজে থাকে। Android APK-তে (Phase 7) এটি Android Keystore-সমর্থিত নিরাপদ স্টোরেজে যাবে।",

  // ---- lock screen demo ----
  "lock.demo": "ডেমো লক স্ক্রিন",
  "lock.demo.note":
    "এটি শুধু চেহারার নমুনা। আসল লক স্ক্রিন Phase 6-এ নেটিভ Android Activity হবে।",
  "lock.title": "{name} লক করা আছে",
  "lock.enter.pin": "আনলক করতে PIN দিন",
  "lock.enter.pattern": "আনলক করতে প্যাটার্ন আঁকুন",
  "lock.unlocked": "আনলক সফল (ডেমো)",
  "lock.biometric": "ফিঙ্গারপ্রিন্ট ব্যবহার করুন",
  "lock.usePin": "PIN ব্যবহার করুন",
  "lock.usePattern": "প্যাটার্ন ব্যবহার করুন",
  "lock.emergency": "জরুরি কল ও ফোন অ্যাপ কখনও লক হয় না।",

  // ---- permissions ----
  "perm.title": "অ্যাপ সুরক্ষার অনুমতি",
  "perm.subtitle":
    "প্রতিটি অনুমতি কেন লাগে, কী তথ্য ব্যবহার হয় ও কী হয় না — এখানে স্বচ্ছভাবে দেওয়া আছে।",
  "perm.status.unknown": "প্রিভিউতে যাচাই করা যায় না",
  "perm.grant": "চালু করুন",
  "perm.usage.title": "ইউসেজ অ্যাক্সেস",
  "perm.usage.why":
    "এখন কোন অ্যাপ সামনে খোলা আছে তা শনাক্ত করতে। তথ্য ডিভাইসেই থাকে, আলাদা করে জমা বা আপলোড হয় না।",
  "perm.overlay.title": "অন্য অ্যাপের উপরে দেখানো",
  "perm.overlay.why":
    "সুরক্ষিত অ্যাপ খোলার সাথে সাথে লক স্ক্রিনটি তার উপরে দেখাতে।",
  "perm.acc.title": "অ্যাক্সেসিবিলিটি সার্ভিস",
  "perm.acc.why":
    "ইউসেজ অ্যাক্সেসের চেয়ে দ্রুত ও নির্ভরযোগ্যভাবে সুরক্ষিত অ্যাপ খোলা শনাক্ত করতে। শুধু আপনার সম্মতির পর, সম্পূর্ণ ঐচ্ছিক।",
  "perm.notif.title": "নোটিফিকেশন (Android 13+)",
  "perm.notif.why":
    "সুরক্ষা সার্ভিস চালু আছে — এই স্থায়ী নোটিফিকেশন দেখাতে।",
  "perm.bio.title": "বায়োমেট্রিক / ফিঙ্গারপ্রিন্ট",
  "perm.bio.why":
    "সিস্টেমের BiometricPrompt দিয়ে আনলক করতে। আপনার আঙুলের ছাপ অ্যাপ কখনও দেখতে পায় না।",
  "perm.mode.title": "লক শনাক্তকরণের দুটি পদ্ধতি",
  "perm.mode.standard":
    "স্ট্যান্ডার্ড (সুপারিশকৃত): ইউসেজ অ্যাক্সেস + ওভারলে অনুমতি। কম সংবেদনশীল।",
  "perm.mode.acc":
    "অ্যাক্সেসিবিলিটি মোড (ঐচ্ছিক): দ্রুত, কিন্তু কঠোর ডিসক্লোজার ও সম্মতি লাগে।",
  "perm.revoke":
    "আপনি যেকোনো সময় Android Settings থেকে এই অনুমতিগুলো বন্ধ করতে বা অ্যাপ আনইনস্টল করতে পারবেন। Lock App BD তাতে কখনও বাধা দেয় না।",
  "perm.play.title": "Google Play নীতি (প্রকাশের সময়)",
  "perm.play.1":
    "অ্যাক্সেসিবিলিটি API ব্যবহারে Play Console-এ Permissions Declaration ফর্ম ও ডেমো ভিডিও লাগে। অ্যাপকে অ্যাক্সেসিবিলিটি টুল দাবি করা যাবে না।",
  "perm.play.2":
    "QUERY_ALL_PACKAGES ব্যবহার করা হচ্ছে না। বদলে লঞ্চার-যোগ্য অ্যাপ দেখতে <queries> (MAIN/LAUNCHER) ব্যবহার হবে।",
  "perm.play.3":
    "PACKAGE_USAGE_STATS ও SYSTEM_ALERT_WINDOW বিশেষ অনুমতি। ব্যবহারকারীকে নিজে Settings-এ গিয়ে চালু করতে হয়, তাই কেন লাগে তা পরিষ্কার বলতে হবে।",
  "perm.play.note":
    "নীতি বদলাতে পারে। প্রকাশের আগে সর্বশেষ Play নীতি দেখে নিন (Phase 8-এ চূড়ান্ত হবে)।",

  // ---- accessibility disclosure ----
  "acc.title": "অ্যাক্সেসিবিলিটি ডিসক্লোজার",
  "acc.intro":
    "Lock App BD কোনো অ্যাক্সেসিবিলিটি টুল নয়। এই সার্ভিস শুধু আপনার চাওয়া অ্যাপ-লক ফিচারের জন্য।",
  "acc.accessed.title": "কী তথ্য ব্যবহার হবে",
  "acc.accessed.body":
    "অন্য অ্যাপ সামনে এলে শুধু তার প্যাকেজ নাম (যেমন com.example.app) ও উইন্ডো বদলের ঘটনা।",
  "acc.why.title": "কেন ব্যবহার হবে",
  "acc.why.body":
    "আপনার লক তালিকার কোনো অ্যাপ খোলা হলে লক স্ক্রিন দেখানোর জন্য।",
  "acc.never.title": "যা কখনও করা হয় না",
  "acc.never.body":
    "স্ক্রিনের লেখা, পাসওয়ার্ড, মেসেজ বা টাইপ করা কিছু পড়া হয় না। কিছুই আপলোড বা শেয়ার হয় না। আপনার হয়ে কোনো ক্লিক বা টাইপ করা হয় না।",
  "acc.control.title": "আপনার নিয়ন্ত্রণ",
  "acc.control.body":
    "Android Settings > Accessibility থেকে যেকোনো সময় এটি বন্ধ করতে পারবেন।",
  "acc.consent":
    "আমি উপরের বিষয়গুলো পড়েছি ও বুঝেছি এবং স্বেচ্ছায় সম্মতি দিচ্ছি।",
  "acc.agree": "সম্মতি দিয়ে সেটিংস খুলুন",
  "acc.decline": "এখন না",
  "acc.consented": "আপনি সম্মতি দিয়েছেন",
  "acc.withdraw": "সম্মতি প্রত্যাহার করুন",
  "acc.withdrawn": "সম্মতি প্রত্যাহার করা হয়েছে",
  "acc.open": "অ্যাক্সেসিবিলিটি ডিসক্লোজার পড়ুন",

  // ---- settings ----
  "set.title": "সেটিংস",
  "set.appearance": "চেহারা ও ভাষা",
  "set.language": "ভাষা",
  "set.theme": "থিম",
  "theme.dark": "ডার্ক",
  "theme.light": "লাইট",
  "theme.system": "সিস্টেম",
  "set.security": "নিরাপত্তা",
  "set.changePin": "PIN পরিবর্তন",
  "set.fingerprint": "ফিঙ্গারপ্রিন্ট",
  "set.protection": "সুরক্ষা",
  "set.permissions": "অ্যাপ সুরক্ষার অনুমতি",
  "set.permissions.desc": "কেন কোন অনুমতি লাগে",
  "set.info": "তথ্য",
  "set.privacy": "গোপনীয়তা নীতি",
  "set.about": "Lock App BD সম্পর্কে",
  "set.version": "অ্যাপ সংস্করণ",
  "set.developer": "ডেভেলপার",
  "set.made": "তৈরি করেছেন Mohammad Rakib",
  "set.telegram": "টেলিগ্রাম চ্যানেল",
  "set.whatsapp": "হোয়াটসঅ্যাপ গ্রুপ",
  "set.link.error": "লিংক খোলা যায়নি।",
  "set.link.note": "লিংক আপনার ডিভাইসের ব্রাউজার বা অ্যাপে খুলবে।",
  "set.reset": "অ্যাপের সব ডেটা মুছুন",
  "set.reset.desc": "PIN, প্যাটার্ন ও লক তালিকা মুছে যাবে। আগে PIN দিতে হবে।",
  "set.reset.title": "সব ডেটা মুছবেন?",
  "set.reset.body":
    "PIN, প্যাটার্ন, রিকভারি কোড ও লক তালিকা এই ডিভাইস থেকে স্থায়ীভাবে মুছে যাবে। এটি ফেরানো যাবে না।",
  "set.reset.confirm": "হ্যাঁ, সব মুছুন",
  "set.reset.done": "সব ডেটা মুছে ফেলা হয়েছে",

  // ---- privacy ----
  "privacy.title": "গোপনীয়তা নীতি",
  "privacy.draft":
    "এটি প্রাথমিক খসড়া। Play Store-এ প্রকাশের আগে আইনি পর্যালোচনা ও একটি অনলাইন URL লাগবে।",
  "privacy.s1.title": "কোনো বিজ্ঞাপন নেই",
  "privacy.s1.body": "Lock App BD-তে কোনো বিজ্ঞাপন SDK নেই এবং কখনও থাকবে না।",
  "privacy.s2.title": "কোনো ট্র্যাকার বা অ্যানালিটিক্স নেই",
  "privacy.s2.body":
    "আপনার ব্যবহার, ইনস্টল করা অ্যাপের তালিকা, PIN বা অ্যাক্সেসিবিলিটি ইভেন্ট সংগ্রহ বা আপলোড করা হয় না।",
  "privacy.s3.title": "সব ডেটা শুধু আপনার ফোনে",
  "privacy.s3.body":
    "ভাষা, থিম, লক তালিকা ও সেটিংস শুধু এই ডিভাইসে সংরক্ষিত থাকে। কোনো অ্যাকাউন্ট বা রেজিস্ট্রেশন লাগে না।",
  "privacy.s4.title": "ইন্টারনেট ব্যবহার",
  "privacy.s4.body":
    "অ্যাপের নিজের কাজের জন্য ইন্টারনেট অনুমতি নেওয়া হবে না। আপনি টেলিগ্রাম বা হোয়াটসঅ্যাপ লিংকে চাপলে শুধু তখনই ফোনের ব্রাউজার/অ্যাপ খুলবে।",
  "privacy.s5.title": "অনুমতিগুলো",
  "privacy.s5.body":
    "প্রতিটি অনুমতি কেন লাগে তা “অনুমতি” পাতায় বিস্তারিত দেওয়া আছে। কোনো অনুমতি আপনার সম্মতি ছাড়া চালু হয় না।",
  "privacy.s6.title": "আপনার অধিকার",
  "privacy.s6.body":
    "সেটিংস থেকে সব ডেটা মুছতে পারবেন, অনুমতি বন্ধ করতে পারবেন বা অ্যাপ আনইনস্টল করতে পারবেন।",
  "privacy.s7.title": "যোগাযোগ",
  "privacy.s7.body": "ডেভেলপার: Mohammad Rakib — টেলিগ্রাম চ্যানেল: @appdevbyrakib",

  // ---- about ----
  "about.title": "Lock App BD সম্পর্কে",
  "about.desc":
    "একটি প্রিমিয়াম, সম্পূর্ণ বিজ্ঞাপনমুক্ত Android অ্যাপ লকার। ওয়েব-ফার্স্ট (React) UI এবং নেটিভ Android প্লাগইনে তৈরি হচ্ছে।",
  "about.package": "প্যাকেজ নাম",
  "about.tech": "প্রযুক্তি",
  "about.status.title": "ডেভেলপমেন্ট অবস্থা",
  "about.status.note":
    "কোনো ফিচার নেটিভ কোড ও পরীক্ষা ছাড়া “কাজ করে” বলা হবে না। নিচে সৎভাবে দেখানো হলো কোনটি কোন অবস্থায় আছে।",
  "status.preview": "ওয়েব প্রিভিউতে কাজ করে",
  "status.planned": "এখনও হয়নি · Phase {n}",
  "st.ui": "প্রিমিয়াম দ্বিভাষিক UI",
  "st.i18n": "ভাষা ও থিম সংরক্ষণ",
  "st.pin": "PIN/প্যাটার্ন হ্যাশ ও লকআউট (ওয়েব)",
  "st.capacitor": "Capacitor Android প্রজেক্ট",
  "st.apps": "আসল ইনস্টল করা অ্যাপের তালিকা",
  "st.engine": "নেটিভ অ্যাপ লক ইঞ্জিন",
  "st.bio": "BiometricPrompt ও Keystore",
  "st.perm": "রানটাইম পারমিশন ফ্লো",
  "st.apk": "APK বিল্ড (GitHub Actions)",
} as const;

export type TKey = keyof typeof bn;
type Dict = Record<TKey, string>;

const en: Dict = {
  "app.tagline": "Your apps, your control",
  "common.continue": "Continue",
  "common.back": "Back",
  "common.cancel": "Cancel",
  "common.confirm": "Confirm",
  "common.done": "Done",
  "common.close": "Close",
  "common.retry": "Try again",
  "common.required": "Required",
  "common.optional": "Optional",
  "common.all": "All",
  "common.loading": "Loading…",
  "common.error": "Something went wrong. Please try again.",
  "common.apps": "apps",
  "time.sec": "{n} sec",
  "time.min": "{n} min",

  "preview.badge": "Preview mode",
  "preview.title": "Demo preview — real locking is not active yet",
  "preview.body":
    "This list is sample data. Real apps can be listed and locked only after the native Android code is added and tested (Phase 5-6).",
  "preview.unavailable":
    "This does not work in preview mode. It will work only in the Android APK once native code is added.",

  "nav.home": "Home",
  "nav.apps": "Apps",
  "nav.security": "Security",
  "nav.settings": "Settings",

  "ob.step": "Step {n} of {total}",
  "ob.lang.title": "Choose your language",
  "ob.lang.subtitle": "You can change it anytime in Settings.",
  "ob.welcome.title": "Welcome to Lock App BD",
  "ob.welcome.subtitle":
    "Ad-free, no account, and your data stays only on your phone.",
  "ob.f1.title": "Completely ad-free",
  "ob.f1.desc": "No advertisements and no trackers.",
  "ob.f2.title": "Offline & private",
  "ob.f2.desc": "No account needed. Nothing is uploaded.",
  "ob.f3.title": "Strong security",
  "ob.f3.desc": "PIN, pattern and fingerprint.",
  "ob.f4.title": "Always in your control",
  "ob.f4.desc": "Disable permissions or uninstall the app anytime.",
  "ob.perm.title": "Why are some permissions needed?",
  "ob.perm.subtitle":
    "Locking other apps needs special Android permissions. Each one is enabled only with your consent.",
  "ob.perm.note":
    "No permission is requested right now. You will enable them yourself later from the “Permissions” page.",
  "ob.pin.title": "Set your PIN",
  "ob.finish": "Get started",

  "pin.current.title": "Enter current PIN",
  "pin.current.subtitle": "Confirm your old PIN to continue.",
  "pin.new.title": "Enter new PIN",
  "pin.new.subtitle": "Choose a length, then enter the digits.",
  "pin.length4": "4 digits",
  "pin.length6": "6 digits",
  "pin.confirm.title": "Confirm your PIN",
  "pin.confirm.subtitle": "Enter the same PIN again to confirm.",
  "pin.mismatch": "The PINs did not match. Start again.",
  "pin.weak":
    "This PIN is too simple (like 0000 or 1234). Choose a different one.",
  "pin.wrong": "Wrong PIN. Try again.",
  "pin.locked": "Too many wrong attempts. Try again in {time}.",
  "pin.saved": "PIN saved",
  "pin.cryptoError":
    "Secure encryption is not supported in this browser, so the PIN could not be saved.",
  "pin.forgot": "Forgot PIN?",
  "pin.storageNote":
    "Your PIN is never stored directly. Only a salted PBKDF2 hash is kept on this device.",

  "rec.title": "Your recovery code",
  "rec.subtitle":
    "If you forget your PIN, this code lets you set a new one. Write it on paper and keep it safe. It will not be shown again.",
  "rec.saved": "I have safely written the code down",
  "rec.enter.title": "Enter recovery code",
  "rec.enter.subtitle": "Type the code you received during setup to reset your PIN.",
  "rec.wrong": "Wrong recovery code.",
  "rec.verify": "Verify",
  "rec.regen": "Generate new recovery code",
  "rec.regen.desc": "The old code will stop working. PIN required first.",
  "rec.hint": "The code uses only capital English letters and digits.",
  "rec.later": "If you lose the code, create a new one later from the Security page.",

  "pat.draw": "Draw your pattern",
  "pat.confirm": "Draw the pattern again",
  "pat.hint": "Connect at least 4 dots.",
  "pat.tooShort": "Connect at least 4 dots.",
  "pat.mismatch": "Patterns did not match. Try again.",
  "pat.saved": "Pattern saved",
  "pat.wrong": "Wrong pattern.",
  "pat.setTitle": "Set pattern lock",

  "gate.title": "Confirm it's you",
  "gate.subtitle": "Enter your PIN to continue.",

  "dash.welcome": "Welcome",
  "dash.protection": "Protection status",
  "dash.status.preview": "Preview — locking inactive",
  "dash.status.preview.desc":
    "The native lock engine is not added yet, so no app is actually protected.",
  "dash.total": "Total apps",
  "dash.locked": "In lock list",
  "dash.method": "Lock method",
  "dash.search.placeholder": "Search apps…",
  "dash.search.empty": "No apps found",
  "dash.search.all": "See all apps",
  "dash.recent": "Recently selected",
  "dash.recent.empty": "You haven't selected any app yet. Start from the “Apps” tab.",
  "dash.quick": "Quick access",
  "dash.quick.pin": "PIN",
  "dash.quick.fingerprint": "Fingerprint",
  "dash.quick.settings": "Settings",
  "dash.perm.title": "Permission setup pending",
  "dash.perm.desc": "Special permissions are needed to enable app lock. See why.",
  "dash.demo": "Try the lock screen demo",

  "apps.title": "App Lock Manager",
  "apps.count": "{n} apps",
  "apps.search": "Search by name or package…",
  "apps.filter.all": "All",
  "apps.filter.locked": "In lock list",
  "apps.filter.unlocked": "Not locked",
  "apps.empty": "No matching apps",
  "apps.emptyLocked": "No apps in the lock list yet",
  "apps.hidden": "{n} critical apps are hidden for safety",
  "apps.hidden.why":
    "Lock App BD itself, Settings, phone/emergency calls, System UI, launchers and keyboards cannot be locked, so you never get stuck on your phone.",
  "apps.error": "Could not load the app list.",
  "apps.added": "{name} added to the list",
  "apps.removed": "{name} removed from the list",
  "apps.toggle": "Toggle protection for {name}",
  "apps.noPin": "Set a PIN before locking apps.",
  "cat.social": "Social",
  "cat.messaging": "Messaging",
  "cat.finance": "Finance",
  "cat.media": "Media",
  "cat.tools": "Tools",
  "cat.shopping": "Shopping",
  "cat.productivity": "Productivity",
  "cat.games": "Games",

  "sec.title": "Security",
  "sec.subtitle": "Lock method and unlock control",
  "sec.method.title": "Active lock method",
  "sec.method.pin": "PIN",
  "sec.method.pattern": "Pattern",
  "sec.pin.change": "Change PIN",
  "sec.pin.desc": "{n}-digit PIN is active",
  "sec.pattern.set": "Set pattern",
  "sec.pattern.change": "Change pattern",
  "sec.pattern.notSet": "Not set yet",
  "sec.pattern.active": "Pattern is set",
  "sec.bio.title": "Fingerprint",
  "sec.bio.desc": "Unlock with Android BiometricPrompt",
  "sec.bio.note":
    "Fingerprint cannot be tested in preview. Your preference is saved; device support will be verified in the Android APK (Phase 7).",
  "sec.bio.on": "Fingerprint preference enabled",
  "sec.bio.off": "Fingerprint preference disabled",
  "sec.lockout.title": "Wrong-attempt protection",
  "sec.lockout.desc":
    "After 5 wrong attempts you are locked out for 30 seconds, then the delay grows with each mistake (up to 15 minutes).",
  "sec.demo": "Lock screen demo",
  "sec.demo.desc": "Test with your real PIN/pattern",
  "sec.storage":
    "In preview, secrets are kept as hashes in browser storage. In the Android APK (Phase 7) they will move to Android Keystore-backed secure storage.",

  "lock.demo": "Demo lock screen",
  "lock.demo.note":
    "This is only a visual sample. The real lock screen will be a native Android Activity in Phase 6.",
  "lock.title": "{name} is locked",
  "lock.enter.pin": "Enter PIN to unlock",
  "lock.enter.pattern": "Draw pattern to unlock",
  "lock.unlocked": "Unlocked (demo)",
  "lock.biometric": "Use fingerprint",
  "lock.usePin": "Use PIN",
  "lock.usePattern": "Use pattern",
  "lock.emergency": "Emergency calls and the phone app are never locked.",

  "perm.title": "App protection permissions",
  "perm.subtitle":
    "Why each permission is needed, what data it touches and what it never does — explained transparently.",
  "perm.status.unknown": "Cannot be checked in preview",
  "perm.grant": "Enable",
  "perm.usage.title": "Usage access",
  "perm.usage.why":
    "To detect which app is currently in the foreground. Data stays on the device and is never collected or uploaded.",
  "perm.overlay.title": "Display over other apps",
  "perm.overlay.why":
    "To show the lock screen on top of a protected app the moment it opens.",
  "perm.acc.title": "Accessibility service",
  "perm.acc.why":
    "To detect protected-app launches faster and more reliably than Usage access. Only after your consent, and completely optional.",
  "perm.notif.title": "Notifications (Android 13+)",
  "perm.notif.why":
    "To show the ongoing notification that tells you the protection service is running.",
  "perm.bio.title": "Biometric / fingerprint",
  "perm.bio.why":
    "To unlock using the system BiometricPrompt. The app never sees your fingerprint.",
  "perm.mode.title": "Two ways to detect a locked app",
  "perm.mode.standard":
    "Standard (recommended): Usage access + overlay permission. Less sensitive.",
  "perm.mode.acc":
    "Accessibility mode (optional): faster, but needs strict disclosure and consent.",
  "perm.revoke":
    "You can turn these permissions off in Android Settings or uninstall the app at any time. Lock App BD never blocks that.",
  "perm.play.title": "Google Play policy (at release)",
  "perm.play.1":
    "Using the Accessibility API requires a Permissions Declaration form and demo video in Play Console. The app must not claim to be an accessibility tool.",
  "perm.play.2":
    "QUERY_ALL_PACKAGES is NOT used. Instead, <queries> (MAIN/LAUNCHER) will be used to see launchable apps.",
  "perm.play.3":
    "PACKAGE_USAGE_STATS and SYSTEM_ALERT_WINDOW are special permissions. Users enable them in Settings themselves, so the reason must be explained clearly.",
  "perm.play.note":
    "Policies can change. Check the latest Play policy before release (finalized in Phase 8).",

  "acc.title": "Accessibility disclosure",
  "acc.intro":
    "Lock App BD is not an accessibility tool. This service exists only for the app-lock feature you asked for.",
  "acc.accessed.title": "What information is used",
  "acc.accessed.body":
    "Only the package name of another app when it comes to the front (e.g. com.example.app) and window-change events.",
  "acc.why.title": "Why it is used",
  "acc.why.body":
    "To show the lock screen when an app from your lock list is opened.",
  "acc.never.title": "What is never done",
  "acc.never.body":
    "It never reads on-screen text, passwords, messages or anything you type. Nothing is uploaded or shared. It never clicks or types for you.",
  "acc.control.title": "Your control",
  "acc.control.body":
    "You can turn it off anytime in Android Settings > Accessibility.",
  "acc.consent":
    "I have read and understood the above and I consent voluntarily.",
  "acc.agree": "Consent & open settings",
  "acc.decline": "Not now",
  "acc.consented": "You have given consent",
  "acc.withdraw": "Withdraw consent",
  "acc.withdrawn": "Consent withdrawn",
  "acc.open": "Read accessibility disclosure",

  "set.title": "Settings",
  "set.appearance": "Appearance & language",
  "set.language": "Language",
  "set.theme": "Theme",
  "theme.dark": "Dark",
  "theme.light": "Light",
  "theme.system": "System",
  "set.security": "Security",
  "set.changePin": "Change PIN",
  "set.fingerprint": "Fingerprint",
  "set.protection": "Protection",
  "set.permissions": "App protection permissions",
  "set.permissions.desc": "Why each permission is needed",
  "set.info": "Information",
  "set.privacy": "Privacy policy",
  "set.about": "About Lock App BD",
  "set.version": "App version",
  "set.developer": "Developer",
  "set.made": "Made by Mohammad Rakib",
  "set.telegram": "Telegram channel",
  "set.whatsapp": "WhatsApp group",
  "set.link.error": "Could not open the link.",
  "set.link.note": "Links open in your device's browser or app.",
  "set.reset": "Erase all app data",
  "set.reset.desc": "Removes PIN, pattern and lock list. PIN required first.",
  "set.reset.title": "Erase all data?",
  "set.reset.body":
    "PIN, pattern, recovery code and lock list will be permanently removed from this device. This cannot be undone.",
  "set.reset.confirm": "Yes, erase everything",
  "set.reset.done": "All data erased",

  "privacy.title": "Privacy policy",
  "privacy.draft":
    "This is an initial draft. Legal review and a hosted URL are required before publishing on Play Store.",
  "privacy.s1.title": "No advertisements",
  "privacy.s1.body": "Lock App BD contains no ad SDKs and never will.",
  "privacy.s2.title": "No trackers or analytics",
  "privacy.s2.body":
    "Your usage, installed-app list, PIN or accessibility events are never collected or uploaded.",
  "privacy.s3.title": "All data stays on your phone",
  "privacy.s3.body":
    "Language, theme, lock list and settings are stored only on this device. No account or registration is needed.",
  "privacy.s4.title": "Internet use",
  "privacy.s4.body":
    "The app will not request internet permission for its own work. A browser/app opens only when you tap a Telegram or WhatsApp link.",
  "privacy.s5.title": "Permissions",
  "privacy.s5.body":
    "Every permission is explained in detail on the “Permissions” page. No permission is enabled without your consent.",
  "privacy.s6.title": "Your rights",
  "privacy.s6.body":
    "You can erase all data from Settings, turn off permissions, or uninstall the app.",
  "privacy.s7.title": "Contact",
  "privacy.s7.body": "Developer: Mohammad Rakib — Telegram channel: @appdevbyrakib",

  "about.title": "About Lock App BD",
  "about.desc":
    "A premium, completely ad-free Android app locker. Built with a web-first (React) UI and native Android plugins.",
  "about.package": "Package name",
  "about.tech": "Technology",
  "about.status.title": "Development status",
  "about.status.note":
    "No feature is called “working” without native code and testing. Below is an honest view of where each one stands.",
  "status.preview": "Works in web preview",
  "status.planned": "Not done yet · Phase {n}",
  "st.ui": "Premium bilingual UI",
  "st.i18n": "Language & theme persistence",
  "st.pin": "PIN/pattern hashing & lockout (web)",
  "st.capacitor": "Capacitor Android project",
  "st.apps": "Real installed-app list",
  "st.engine": "Native app-lock engine",
  "st.bio": "BiometricPrompt & Keystore",
  "st.perm": "Runtime permission flow",
  "st.apk": "APK build (GitHub Actions)",
};

export const dictionaries: Record<Lang, Dict> = { bn: bn as Dict, en };
