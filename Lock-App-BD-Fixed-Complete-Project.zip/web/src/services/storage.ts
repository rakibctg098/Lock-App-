import { STORAGE_KEY } from "@/config";
import type {
  Lang,
  LockMethod,
  PersistedState,
  PinLength,
  SecretRecord,
  ThemeMode,
} from "@/types";

/** Longest lockout the app will ever apply (15 min). Used to sanitize clock tampering. */
export const MAX_LOCKOUT_MS = 15 * 60 * 1000;

export function defaultState(): PersistedState {
  return {
    version: 1,
    onboarded: false,
    lang: "bn", // default language: Bengali
    theme: "dark",
    lockMethod: "pin",
    pinLength: 4,
    pin: null,
    pattern: null,
    recovery: null,
    biometricEnabled: false,
    lockedApps: [],
    recentApps: [],
    accessibilityConsent: false,
    failedAttempts: 0,
    lockoutUntil: 0,
  };
}

const isStr = (v: unknown): v is string => typeof v === "string";

function toSecret(v: unknown): SecretRecord | null {
  if (!v || typeof v !== "object") return null;
  const o = v as Record<string, unknown>;
  if (
    o.alg === "PBKDF2-SHA256" &&
    typeof o.iterations === "number" &&
    Number.isInteger(o.iterations) &&
    o.iterations >= 1000 &&
    o.iterations <= 5000000 &&
    isStr(o.salt) &&
    o.salt.length <= 128 &&
    isStr(o.hash) &&
    o.hash.length <= 256
  ) {
    return {
      alg: "PBKDF2-SHA256",
      iterations: o.iterations,
      salt: o.salt,
      hash: o.hash,
    };
  }
  return null;
}

function toStrArray(v: unknown, max: number): string[] {
  if (!Array.isArray(v)) return [];
  const out: string[] = [];
  for (const item of v) {
    if (isStr(item) && item.length > 0 && item.length < 256 && !out.includes(item)) {
      out.push(item);
      if (out.length >= max) break;
    }
  }
  return out;
}

/** Validates untrusted JSON from storage and merges it onto safe defaults. */
function sanitize(raw: unknown): PersistedState {
  const d = defaultState();
  if (!raw || typeof raw !== "object") return d;
  const o = raw as Record<string, unknown>;

  const lang: Lang = o.lang === "en" ? "en" : "bn";
  const theme: ThemeMode =
    o.theme === "light" || o.theme === "system" ? o.theme : "dark";
  const pinLength: PinLength = o.pinLength === 6 ? 6 : 4;
  const pin = toSecret(o.pin);
  const pattern = toSecret(o.pattern);
  const recovery = toSecret(o.recovery);
  let lockMethod: LockMethod = o.lockMethod === "pattern" ? "pattern" : "pin";
  if (lockMethod === "pattern" && !pattern) lockMethod = "pin";

  const now = Date.now();
  const rawLock = typeof o.lockoutUntil === "number" ? o.lockoutUntil : 0;
  const lockoutUntil =
    Number.isFinite(rawLock) && rawLock > now
      ? Math.min(rawLock, now + MAX_LOCKOUT_MS)
      : 0;
  const rawFailed = typeof o.failedAttempts === "number" ? o.failedAttempts : 0;
  const failedAttempts =
    Number.isFinite(rawFailed) && rawFailed > 0 ? Math.min(Math.floor(rawFailed), 100) : 0;

  return {
    version: 1,
    // Without a PIN the app cannot be considered set up.
    onboarded: o.onboarded === true && pin !== null,
    lang,
    theme,
    lockMethod,
    pinLength,
    pin,
    pattern,
    recovery,
    biometricEnabled: o.biometricEnabled === true,
    lockedApps: toStrArray(o.lockedApps, 1000),
    recentApps: toStrArray(o.recentApps, 6),
    accessibilityConsent: o.accessibilityConsent === true,
    failedAttempts,
    lockoutUntil,
  };
}

export function loadState(): PersistedState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState();
    return sanitize(JSON.parse(raw));
  } catch {
    return defaultState();
  }
}

export function saveState(state: PersistedState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* storage may be full or blocked; the app keeps working in memory */
  }
}

export function clearState(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* ignore */
  }
}
