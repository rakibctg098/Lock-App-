import type { SecretRecord } from "@/types";

/**
 * Web-preview secret handling (PBKDF2-SHA256 + random salt).
 * The plain PIN / pattern / recovery code is never stored.
 *
 * NOTE: In the Android build (Phase 7) the same design moves to native
 * code, with the hash additionally protected by an Android Keystore key.
 */

const ITERATIONS = 210000;
const SALT_BYTES = 16;
const HASH_BITS = 256;

export function isCryptoAvailable(): boolean {
  return (
    typeof crypto !== "undefined" &&
    typeof crypto.getRandomValues === "function" &&
    !!crypto.subtle
  );
}

function toB64(bytes: Uint8Array): string {
  let s = "";
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s);
}

function fromB64(b64: string): Uint8Array<ArrayBuffer> {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function derive(
  secret: string,
  salt: Uint8Array<ArrayBuffer>,
  iterations: number,
): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt, iterations },
    key,
    HASH_BITS,
  );
  return new Uint8Array(bits);
}

export async function createSecretRecord(secret: string): Promise<SecretRecord> {
  if (!isCryptoAvailable()) throw new Error("crypto-unavailable");
  const salt = new Uint8Array(SALT_BYTES);
  crypto.getRandomValues(salt);
  const hash = await derive(secret, salt, ITERATIONS);
  return {
    alg: "PBKDF2-SHA256",
    iterations: ITERATIONS,
    salt: toB64(salt),
    hash: toB64(hash),
  };
}

/** Constant-time comparison to avoid timing leaks. */
function safeEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

export async function verifySecret(
  secret: string,
  record: SecretRecord,
): Promise<boolean> {
  if (!isCryptoAvailable()) throw new Error("crypto-unavailable");
  const computed = await derive(secret, fromB64(record.salt), record.iterations);
  return safeEqual(computed, fromB64(record.hash));
}

// ---------- recovery code ----------
// 32 symbols (no 0/O/1/I) -> 256 % 32 === 0, so random bytes map without bias.
const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function generateRecoveryCode(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  let raw = "";
  for (let i = 0; i < bytes.length; i++) raw += ALPHABET[bytes[i] % ALPHABET.length];
  return raw.match(/.{4}/g)!.join("-");
}

export function normalizeRecoveryCode(input: string): string {
  return input.toUpperCase().replace(/[^A-Z0-9]/g, "");
}

// ---------- weak PIN check ----------
export function isWeakPin(pin: string): boolean {
  if (/^(\d)\1+$/.test(pin)) return true; // 0000, 111111
  let asc = true;
  let desc = true;
  for (let i = 1; i < pin.length; i++) {
    const diff = Number(pin[i]) - Number(pin[i - 1]);
    if (diff !== 1) asc = false;
    if (diff !== -1) desc = false;
  }
  return asc || desc; // 1234, 4321, 123456
}

// ---------- lockout policy ----------
/** Delay after N consecutive failures: <5: none, 5: 30s, 6: 1m, 7: 5m, 8+: 15m. */
export function lockoutDuration(failures: number): number {
  if (failures < 5) return 0;
  if (failures === 5) return 30 * 1000;
  if (failures === 6) return 60 * 1000;
  if (failures === 7) return 5 * 60 * 1000;
  return 15 * 60 * 1000;
}
