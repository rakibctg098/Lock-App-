import { ALLOWED_EXTERNAL_HOSTS } from "@/config";
import { MOCK_APPS } from "@/data/mockApps";
import { isExcludedPackage } from "@/data/exclusions";
import type { AppInfo, SecretRecord } from "@/types";

export interface InstalledAppsResult {
  apps: AppInfo[];
  /** Number of critical/unsuitable packages that were filtered out. */
  hiddenCount: number;
}

export interface PermissionStatuses {
  usage: boolean;
  overlay: boolean;
  notif: boolean;
  bio: boolean;
  acc: boolean;
}

export interface SecuritySyncPayload {
  pin: SecretRecord | null;
  pattern: SecretRecord | null;
  recovery: SecretRecord | null;
  biometricEnabled: boolean;
  lockMethod: "pin" | "pattern";
  pinLength: number;
  failedAttempts: number;
  lockoutUntil: number;
}

export interface NativeBridge {
  readonly kind: "web-preview" | "android";
  readonly engineAvailable: boolean;
  getInstalledApps(): Promise<InstalledAppsResult>;
  openExternal(url: string): Promise<boolean>;
  getPermissionStatuses(): Promise<PermissionStatuses>;
  requestPermission(id: string): Promise<void>;
  syncLockedApps(apps: string[]): Promise<void>;
  syncSecurity(payload: SecuritySyncPayload): Promise<void>;
  authenticateBiometric(): Promise<boolean>;
  setServiceEnabled(enabled: boolean): Promise<void>;
  isServiceRunning(): Promise<boolean>;
  testLock(packageName: string): Promise<void>;
}

declare global {
  interface Window {
    AndroidBridge?: {
      getInstalledApps(): string;
      getPermissionStatuses(): string;
      requestPermission(id: string): void;
      syncLockedApps(json: string): void;
      syncSecurity(json: string): void;
      authenticateBiometric(): boolean;
      openExternal(url: string): boolean;
      setServiceEnabled(enabled: boolean): void;
      isServiceRunning(): boolean;
      testLock(packageName: string): void;
    };
  }
}

function isAllowedUrl(url: string): boolean {
  try {
    const u = new URL(url);
    return (
      u.protocol === "https:" &&
      !u.username &&
      !u.password &&
      (u.port === "" || u.port === "443") &&
      ALLOWED_EXTERNAL_HOSTS.includes(u.hostname)
    );
  } catch {
    return false;
  }
}

const isAndroid = typeof window !== "undefined" && !!window.AndroidBridge;

const androidBridgeImpl: NativeBridge = {
  kind: "android",
  engineAvailable: true,

  async getInstalledApps(): Promise<InstalledAppsResult> {
    try {
      if (window.AndroidBridge) {
        const raw = window.AndroidBridge.getInstalledApps();
        const parsed = JSON.parse(raw);
        return parsed;
      }
    } catch (e) {
      console.error("AndroidBridge.getInstalledApps error:", e);
    }
    return { apps: [], hiddenCount: 0 };
  },

  async openExternal(url: string): Promise<boolean> {
    if (!isAllowedUrl(url)) return false;
    try {
      if (window.AndroidBridge) {
        return window.AndroidBridge.openExternal(url);
      }
    } catch {
      // fallback
    }
    return false;
  },

  async getPermissionStatuses(): Promise<PermissionStatuses> {
    try {
      if (window.AndroidBridge) {
        const raw = window.AndroidBridge.getPermissionStatuses();
        return JSON.parse(raw);
      }
    } catch (e) {
      console.error("AndroidBridge.getPermissionStatuses error:", e);
    }
    return { usage: false, overlay: false, notif: false, bio: false, acc: false };
  },

  async requestPermission(id: string): Promise<void> {
    try {
      if (window.AndroidBridge) {
        window.AndroidBridge.requestPermission(id);
      }
    } catch (e) {
      console.error("AndroidBridge.requestPermission error:", e);
    }
  },

  async syncLockedApps(apps: string[]): Promise<void> {
    try {
      if (window.AndroidBridge) {
        window.AndroidBridge.syncLockedApps(JSON.stringify(apps));
      }
    } catch (e) {
      console.error("AndroidBridge.syncLockedApps error:", e);
    }
  },

  async syncSecurity(payload: SecuritySyncPayload): Promise<void> {
    try {
      if (window.AndroidBridge) {
        window.AndroidBridge.syncSecurity(JSON.stringify(payload));
      }
    } catch (e) {
      console.error("AndroidBridge.syncSecurity error:", e);
    }
  },

  async authenticateBiometric(): Promise<boolean> {
    try {
      if (window.AndroidBridge) {
        return window.AndroidBridge.authenticateBiometric();
      }
    } catch (e) {
      console.error("AndroidBridge.authenticateBiometric error:", e);
    }
    return false;
  },

  async setServiceEnabled(enabled: boolean): Promise<void> {
    try {
      if (window.AndroidBridge) {
        window.AndroidBridge.setServiceEnabled(enabled);
      }
    } catch (e) {
      console.error("AndroidBridge.setServiceEnabled error:", e);
    }
  },

  async isServiceRunning(): Promise<boolean> {
    try {
      if (window.AndroidBridge) {
        return window.AndroidBridge.isServiceRunning();
      }
    } catch {
      return false;
    }
    return false;
  },

  async testLock(packageName: string): Promise<void> {
    try {
      if (window.AndroidBridge) {
        window.AndroidBridge.testLock(packageName);
      }
    } catch (e) {
      console.error("AndroidBridge.testLock error:", e);
    }
  },
};

const webPreviewBridge: NativeBridge = {
  kind: "web-preview",
  engineAvailable: false,

  async getInstalledApps() {
    await new Promise((r) => setTimeout(r, 250));
    const apps = MOCK_APPS.filter((a) => !isExcludedPackage(a.packageName));
    return {
      apps: [...apps].sort((a, b) => a.label.localeCompare(b.label)),
      hiddenCount: MOCK_APPS.length - apps.length,
    };
  },

  async openExternal(url: string) {
    if (!isAllowedUrl(url)) return false;
    try {
      const a = document.createElement("a");
      a.href = url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      document.body.appendChild(a);
      a.click();
      a.remove();
      return true;
    } catch {
      return false;
    }
  },

  async getPermissionStatuses() {
    return { usage: false, overlay: false, notif: false, bio: false, acc: false };
  },

  async requestPermission() {
    // No-op in web preview
  },

  async syncLockedApps() {
    // No-op in web preview
  },

  async syncSecurity() {
    // No-op in web preview
  },

  async authenticateBiometric() {
    return false;
  },

  async setServiceEnabled() {
    // No-op in web preview
  },

  async isServiceRunning() {
    return false;
  },

  async testLock() {
    // No-op in web preview
  },
};

export const bridge: NativeBridge = isAndroid ? androidBridgeImpl : webPreviewBridge;
