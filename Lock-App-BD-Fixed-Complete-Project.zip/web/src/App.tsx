import { AppProvider, useApp } from "@/state/AppContext";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { Toast } from "@/components/ui";
import { Onboarding } from "@/screens/Onboarding";
import { Main } from "@/screens/Main";

function Root() {
  const { state } = useApp();
  return (
    <div className="mx-auto flex h-dvh w-full max-w-md sm:py-4">
      <div className="relative flex min-h-0 w-full flex-col overflow-hidden bg-[image:var(--bg-grad)] text-ink sm:rounded-[2.2rem] sm:border sm:border-line sm:shadow-card">
        {state.onboarded ? <Main /> : <Onboarding />}
        <Toast />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <Root />
      </AppProvider>
    </ErrorBoundary>
  );
}
