export type Lang = "bn" | "en";
export type ThemeMode = "dark" | "light" | "system";
export type PinLength = 4 | 6;
export type LockMethod = "pin" | "pattern";

export type AppCategory =
  | "social"
  | "messaging"
  | "finance"
  | "media"
  | "tools"
  | "shopping"
  | "productivity"
  | "games";

/** One launchable application as reported by the (future) native layer. */
export interface AppInfo {
  packageName: string;
  label: string;
  category: AppCategory;
  /** Used to draw a colored placeholder icon in preview mode. */
  hue: number;
  /** Real icon (data URI) supplied by the native plugin in Phase 5. */
  iconDataUri?: string;
}

/** Salted PBKDF2 record. The plain secret is never stored. */
export interface SecretRecord {
  alg: "PBKDF2-SHA256";
  iterations: number;
  salt: string; // base64
  hash: string; // base64
}

export interface PersistedState {
  version: 1;
  onboarded: boolean;
  lang: Lang;
  theme: ThemeMode;
  lockMethod: LockMethod;
  pinLength: PinLength;
  pin: SecretRecord | null;
  pattern: SecretRecord | null;
  recovery: SecretRecord | null;
  biometricEnabled: boolean;
  lockedApps: string[];
  recentApps: string[];
  accessibilityConsent: boolean;
  failedAttempts: number;
  lockoutUntil: number;
}

export type Route =
  | "permissions"
  | "privacy"
  | "about"
  | "changePin"
  | "setPattern"
  | "lockDemo"
  | "reset"
  | "regenRecovery"
  | "recoverPin";

export type Tab = "home" | "apps" | "security" | "settings";
