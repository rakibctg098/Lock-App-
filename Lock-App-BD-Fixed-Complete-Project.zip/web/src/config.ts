// Central, non-secret app constants. No API keys or secrets belong here.
export const APP_NAME = "Lock App BD";
export const APP_PACKAGE = "com.mohammadrakib.lockappbd";
export const APP_VERSION = "1.0.0-preview";
export const DEVELOPER_NAME = "Mohammad Rakib";

export const TELEGRAM_URL = "https://t.me/appdevbyrakib";
export const WHATSAPP_URL =
  "https://chat.whatsapp.com/HkvJCqWFf6G4bcQRKspKta?s=cl&p=a&iam=2";

/** Only these hosts may ever be opened externally by the app. */
export const ALLOWED_EXTERNAL_HOSTS = ["t.me", "chat.whatsapp.com"];

export const STORAGE_KEY = "lockappbd.state.v1";
