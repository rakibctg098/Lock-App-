import { APP_PACKAGE } from "@/config";

/**
 * Packages that must NEVER be lockable. Locking them could trap the user
 * (no settings, no emergency calls, no launcher, no keyboard) or block the
 * user from revoking permissions / uninstalling Lock App BD.
 *
 * The same list will be mirrored in the native Android plugin (Phase 5/6),
 * so the rule is enforced natively too, not only in the UI.
 */
const EXACT = new Set<string>([
  APP_PACKAGE,
  "com.android.settings",
  "com.android.systemui",
  "com.android.phone",
  "com.android.server.telecom",
  "com.android.dialer",
  "com.google.android.dialer",
  "com.samsung.android.dialer",
  "com.android.emergency",
  "com.android.packageinstaller",
  "com.google.android.packageinstaller",
  "com.android.permissioncontroller",
  "com.google.android.permissioncontroller",
  "com.google.android.apps.nexuslauncher",
]);

const PREFIXES = [
  "com.android.launcher",
  "com.sec.android.app.launcher",
  "com.miui.home",
  "com.android.inputmethod",
  "com.google.android.inputmethod",
  "com.android.providers.",
  "com.android.systemui.",
  "com.android.settings.",
];

export function isExcludedPackage(packageName: string): boolean {
  if (EXACT.has(packageName)) return true;
  return PREFIXES.some((p) => packageName.startsWith(p));
}
