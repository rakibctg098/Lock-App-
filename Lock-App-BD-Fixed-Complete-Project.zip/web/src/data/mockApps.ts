import { APP_PACKAGE } from "@/config";
import type { AppInfo } from "@/types";

/**
 * DEMO DATA ONLY — used in the web preview.
 * The Android build (Phase 5) replaces this with the real list returned by
 * PackageManager. A few entries are deliberately critical packages so the
 * exclusion filter is exercised in preview too.
 */
export const MOCK_APPS: AppInfo[] = [
  { packageName: "com.facebook.katana", label: "Facebook", category: "social", hue: 218 },
  { packageName: "com.facebook.orca", label: "Messenger", category: "messaging", hue: 262 },
  { packageName: "com.whatsapp", label: "WhatsApp", category: "messaging", hue: 142 },
  { packageName: "org.telegram.messenger", label: "Telegram", category: "messaging", hue: 200 },
  { packageName: "com.instagram.android", label: "Instagram", category: "social", hue: 330 },
  { packageName: "com.snapchat.android", label: "Snapchat", category: "social", hue: 52 },
  { packageName: "com.zhiliaoapp.musically", label: "TikTok", category: "media", hue: 175 },
  { packageName: "com.google.android.youtube", label: "YouTube", category: "media", hue: 2 },
  { packageName: "com.google.android.gm", label: "Gmail", category: "productivity", hue: 8 },
  { packageName: "com.google.android.apps.photos", label: "Photos", category: "media", hue: 28 },
  { packageName: "com.google.android.apps.messaging", label: "Messages", category: "messaging", hue: 210 },
  { packageName: "com.google.android.contacts", label: "Contacts", category: "tools", hue: 190 },
  { packageName: "com.android.chrome", label: "Chrome", category: "tools", hue: 120 },
  { packageName: "com.android.vending", label: "Play Store", category: "tools", hue: 160 },
  { packageName: "com.bkash.customerapp", label: "bKash", category: "finance", hue: 335 },
  { packageName: "com.konasl.nagad", label: "Nagad", category: "finance", hue: 18 },
  { packageName: "com.dbbl.mbs.apps.main", label: "Rocket", category: "finance", hue: 285 },
  { packageName: "com.daraz.android", label: "Daraz", category: "shopping", hue: 24 },
  { packageName: "com.google.android.keep", label: "Keep Notes", category: "productivity", hue: 46 },
  { packageName: "com.google.android.apps.docs", label: "Drive", category: "productivity", hue: 150 },
  { packageName: "com.google.android.apps.nbu.files", label: "Files", category: "tools", hue: 225 },
  { packageName: "com.google.android.calendar", label: "Calendar", category: "productivity", hue: 214 },
  { packageName: "com.dts.freefireth", label: "Free Fire", category: "games", hue: 14 },
  { packageName: "com.ludo.king", label: "Ludo King", category: "games", hue: 100 },
  { packageName: "com.example.banglaDictionary", label: "বাংলা অভিধান", category: "tools", hue: 300 },
  // --- critical packages: always filtered out by isExcludedPackage ---
  { packageName: APP_PACKAGE, label: "Lock App BD", category: "tools", hue: 220 },
  { packageName: "com.android.settings", label: "Settings", category: "tools", hue: 210 },
  { packageName: "com.google.android.dialer", label: "Phone", category: "tools", hue: 150 },
  { packageName: "com.android.systemui", label: "System UI", category: "tools", hue: 200 },
];
