import { useCallback, useEffect, useRef, useState } from "react";
import { House, LayoutGrid, Settings as SettingsIcon, ShieldCheck } from "lucide-react";
import { cn } from "@/utils/cn";
import { useApp } from "@/state/AppContext";
import { PinGate } from "@/components/PinGate";
import { PinSetupFlow } from "@/components/PinSetupFlow";
import { RecoveryCodeView } from "@/components/RecoveryCodeView";
import { SubPage } from "@/components/ui";
import { Dashboard } from "@/screens/Dashboard";
import { Apps } from "@/screens/Apps";
import { Security } from "@/screens/Security";
import { Settings } from "@/screens/Settings";
import { Permissions } from "@/screens/Permissions";
import { Privacy } from "@/screens/Privacy";
import { About } from "@/screens/About";
import { SetPattern } from "@/screens/SetPattern";
import { LockDemo } from "@/screens/LockDemo";
import type { Route, Tab } from "@/types";

export function Main() {
  const { t, resetAll, showToast } = useApp();
  const [tab, setTab] = useState<Tab>("home");
  const [stack, setStack] = useState<Route[]>([]);

  // Sub pages share the browser history so the Android back button/gesture
  // closes the top page instead of leaving the app.
  const historyOk = useRef(true);
  const popExpected = useRef(false);

  const push = useCallback((route: Route) => {
    setStack((s) => [...s, route]);
    try {
      window.history.pushState({ lockapp: true }, "");
    } catch {
      historyOk.current = false;
    }
  }, []);

  const replaceTop = useCallback((route: Route) => {
    setStack((s) => [...s.slice(0, -1), route]);
  }, []);

  const pop = useCallback(() => {
    if (historyOk.current) {
      try {
        popExpected.current = true;
        window.history.back();
        // Safety net for environments where history.back() does nothing.
        window.setTimeout(() => {
          if (popExpected.current) {
            popExpected.current = false;
            historyOk.current = false;
            setStack((s) => s.slice(0, -1));
          }
        }, 300);
        return;
      } catch {
        historyOk.current = false;
        popExpected.current = false;
      }
    }
    setStack((s) => s.slice(0, -1));
  }, []);

  useEffect(() => {
    const onPop = () => {
      popExpected.current = false;
      setStack((s) => s.slice(0, -1));
    };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  const route = stack[stack.length - 1];

  if (route) {
    switch (route) {
      case "permissions":
        return <Permissions onBack={pop} />;
      case "privacy":
        return <Privacy onBack={pop} />;
      case "about":
        return <About onBack={pop} />;
      case "setPattern":
        return <SetPattern onBack={pop} />;
      case "lockDemo":
        return <LockDemo onClose={pop} onRecovered={() => replaceTop("recoverPin")} />;
      case "changePin":
        return (
          <SubPage title={t("set.changePin")} onBack={pop}>
            <PinSetupFlow requireCurrent doneLabel={t("common.done")} onDone={pop} />
          </SubPage>
        );
      case "recoverPin":
        return (
          <SubPage title={t("pin.forgot")} onBack={pop}>
            <PinSetupFlow requireCurrent={false} doneLabel={t("common.done")} onDone={pop} />
          </SubPage>
        );
      case "regenRecovery":
        return <RegenRecovery onBack={pop} />;
      case "reset":
        return (
          <SubPage title={t("set.reset.title")} onBack={pop}>
            <p className="mb-2 rounded-2xl border border-bad/40 bg-bad/10 p-4 text-sm leading-relaxed">
              {t("set.reset.body")}
            </p>
            <PinGate
              title={t("set.reset.confirm")}
              onSuccess={() => {
                resetAll();
                showToast(t("set.reset.done"));
                // Leave the confirmation screen after credentials are cleared.
                pop();
              }}
            />
          </SubPage>
        );
    }
  }

  const tabs: { id: Tab; icon: typeof House; label: string }[] = [
    { id: "home", icon: House, label: t("nav.home") },
    { id: "apps", icon: LayoutGrid, label: t("nav.apps") },
    { id: "security", icon: ShieldCheck, label: t("nav.security") },
    { id: "settings", icon: SettingsIcon, label: t("nav.settings") },
  ];

  return (
    <>
      <main
        key={tab}
        className="no-scrollbar min-h-0 flex-1 animate-fade overflow-y-auto px-5 pb-8 pt-[max(1.25rem,env(safe-area-inset-top))]"
      >
        {tab === "home" && <Dashboard go={setTab} push={push} />}
        {tab === "apps" && <Apps />}
        {tab === "security" && <Security push={push} />}
        {tab === "settings" && <Settings push={push} />}
      </main>

      <nav
        aria-label="Main"
        className="border-t border-line bg-surface/95 px-3 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-2 backdrop-blur"
      >
        <ul className="grid grid-cols-4 gap-1">
          {tabs.map((x) => {
            const active = tab === x.id;
            return (
              <li key={x.id}>
                <button
                  type="button"
                  onClick={() => setTab(x.id)}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "flex w-full flex-col items-center gap-1 rounded-2xl py-2 text-xs font-semibold transition",
                    active ? "text-brand" : "text-muted",
                  )}
                >
                  <span
                    className={cn(
                      "flex h-8 w-14 items-center justify-center rounded-full transition",
                      active && "bg-brand/15",
                    )}
                  >
                    <x.icon className="h-5 w-5" strokeWidth={active ? 2.5 : 2} />
                  </span>
                  <span className="max-w-full truncate">{x.label}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
    </>
  );
}

function RegenRecovery({ onBack }: { onBack: () => void }) {
  const { t, regenerateRecovery, showToast } = useApp();
  const [code, setCode] = useState("");

  const onVerified = async () => {
    try {
      setCode(await regenerateRecovery());
    } catch {
      showToast(t("pin.cryptoError"));
    }
  };

  return (
    <SubPage title={t("rec.regen")} onBack={onBack}>
      {code ? (
        <RecoveryCodeView code={code} onDone={onBack} doneLabel={t("common.done")} />
      ) : (
        <PinGate onSuccess={() => void onVerified()} />
      )}
    </SubPage>
  );
}
