import { useMemo, useState } from "react";
import {
  ChevronRight,
  Fingerprint,
  KeyRound,
  Lock,
  Search,
  Settings as SettingsIcon,
  ShieldAlert,
  Smartphone,
  Play,
  X,
} from "lucide-react";
import { Logo } from "@/components/Logo";
import { AppIcon } from "@/components/AppIcon";
import { AppRow } from "@/components/AppRow";
import { Card, PreviewNotice } from "@/components/ui";
import { useApp } from "@/state/AppContext";
import type { Route, Tab } from "@/types";

export function Dashboard({
  go,
  push,
}: {
  go: (tab: Tab) => void;
  push: (route: Route) => void;
}) {
  const { t, fmt, state, apps, appsStatus, lockedCount } = useApp();
  const [query, setQuery] = useState("");
  const q = query.trim().toLowerCase();

  const results = useMemo(
    () =>
      q
        ? apps.filter(
            (a) =>
              a.label.toLowerCase().includes(q) || a.packageName.toLowerCase().includes(q),
          )
        : [],
    [apps, q],
  );

  const recent = useMemo(
    () =>
      state.recentApps
        .map((p) => apps.find((a) => a.packageName === p))
        .filter((a): a is NonNullable<typeof a> => !!a),
    [apps, state.recentApps],
  );

  const stats = [
    { icon: Smartphone, label: t("dash.total"), value: appsStatus === "ready" ? fmt(apps.length) : "…" },
    { icon: Lock, label: t("dash.locked"), value: fmt(lockedCount) },
    {
      icon: state.lockMethod === "pin" ? KeyRound : Fingerprint,
      label: t("dash.method"),
      value: t(state.lockMethod === "pin" ? "sec.method.pin" : "sec.method.pattern"),
    },
  ];

  const [nativePerms, setNativePerms] = useState<{ usage: boolean; overlay: boolean } | null>(null);

  useEffect(() => {
    if (bridge.kind === "android") {
      void bridge.getPermissionStatuses().then((p) => {
        setNativePerms({ usage: p.usage, overlay: p.overlay });
      });
      const onFocus = () => {
        void bridge.getPermissionStatuses().then((p) => {
          setNativePerms({ usage: p.usage, overlay: p.overlay });
        });
      };
      window.addEventListener("focus", onFocus);
      return () => window.removeEventListener("focus", onFocus);
    }
  }, []);

  const isAndroidProtected = bridge.kind === "android" && nativePerms?.usage && nativePerms?.overlay;
  const isAndroidNeedsPerms = bridge.kind === "android" && (!nativePerms?.usage || !nativePerms?.overlay);

  return (
    <div className="space-y-5">
      {/* header */}
      <div className="flex items-center gap-3">
        <Logo size={46} />
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-xl font-bold leading-tight">Lock App BD</h1>
          <p className="truncate text-sm text-muted">{t("app.tagline")}</p>
        </div>
        {bridge.kind === "android" ? (
          <span
            className={
              isAndroidProtected
                ? "rounded-full border border-ok/40 bg-ok/10 px-3 py-1 text-xs font-bold text-ok"
                : "rounded-full border border-warn/40 bg-warn/10 px-3 py-1 text-xs font-bold text-warn"
            }
          >
            {isAndroidProtected
              ? state.lang === "bn"
                ? "সক্রিয়"
                : "Active"
              : state.lang === "bn"
                ? "অনুমতি বাকি"
                : "Setup"}
          </span>
        ) : (
          <span className="rounded-full border border-warn/40 bg-warn/10 px-3 py-1 text-xs font-bold text-warn">
            {t("preview.badge")}
          </span>
        )}
      </div>

      {/* protection status */}
      <section
        aria-label={t("dash.protection")}
        onClick={() => {
          if (isAndroidNeedsPerms) push("permissions");
        }}
        className={
          isAndroidProtected
            ? "relative cursor-pointer overflow-hidden rounded-3xl bg-gradient-to-br from-[#059669] via-[#10b981] to-[#047857] p-5 text-white shadow-glow transition active:scale-[0.99]"
            : isAndroidNeedsPerms
              ? "relative cursor-pointer overflow-hidden rounded-3xl bg-gradient-to-br from-[#b45309] via-[#d97706] to-[#f59e0b] p-5 text-white shadow-glow transition active:scale-[0.99]"
              : "relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#1d4ed8] via-[#3b5bdb] to-[#6366f1] p-5 text-white shadow-glow"
        }
      >
        <div className="pointer-events-none absolute -right-8 -top-8 h-40 w-40 animate-pulse-soft rounded-full bg-white/15 blur-2xl" />
        <p className="text-sm font-medium text-white/80">{t("dash.protection")}</p>
        <div className="mt-2 flex items-center gap-3">
          <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-white/20 backdrop-blur">
            {isAndroidProtected ? (
              <ShieldCheck className="h-8 w-8" />
            ) : (
              <ShieldAlert className="h-8 w-8" />
            )}
          </span>
          <div className="min-w-0">
            <p className="text-lg font-bold leading-snug">
              {isAndroidProtected
                ? state.lang === "bn"
                  ? "সুরক্ষা সক্রিয়"
                  : "Protection Active"
                : isAndroidNeedsPerms
                  ? state.lang === "bn"
                    ? "অনুমতি প্রয়োজন (ট্যাপ করুন)"
                    : "Permissions Needed (Tap)"
                  : t("dash.status.preview")}
            </p>
            <p className="text-sm leading-snug text-white/80">
              {isAndroidProtected
                ? state.lang === "bn"
                  ? "লক ইঞ্জিন চলছে এবং আপনার নির্বাচিত অ্যাপগুলো সুরক্ষিত।"
                  : "Native lock engine is active and protecting your apps."
                : isAndroidNeedsPerms
                  ? state.lang === "bn"
                    ? "অ্যাপ লক সক্রিয় করতে ইউসেজ ও ওভারলে অনুমতি দিন।"
                    : "Grant Usage & Overlay permissions to activate lock engine."
                  : t("dash.status.preview.desc")}
            </p>
          </div>
        </div>
      </section>

      {/* stats */}
      <div className="grid grid-cols-3 gap-3">
        {stats.map((s) => (
          <Card key={s.label} className="flex flex-col items-center p-3 text-center">
            <s.icon className="h-5 w-5 text-brand" />
            <p className="mt-1.5 max-w-full truncate text-xl font-bold">{s.value}</p>
            <p className="text-xs leading-tight text-muted">{s.label}</p>
          </Card>
        ))}
      </div>

      {/* search */}
      <div>
        <div className="relative">
          <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t("dash.search.placeholder")}
            aria-label={t("dash.search.placeholder")}
            className="h-12 w-full rounded-2xl border border-line bg-surface pl-12 pr-11 text-base text-ink placeholder:text-muted focus:border-brand focus:outline-none"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery("")}
              aria-label={t("common.close")}
              className="absolute right-2 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full text-muted"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {q && (
          <Card className="mt-3 divide-y divide-line overflow-hidden">
            {results.length === 0 ? (
              <p className="p-5 text-center text-sm text-muted">{t("dash.search.empty")}</p>
            ) : (
              results.slice(0, 5).map((a) => <AppRow key={a.packageName} app={a} />)
            )}
            {results.length > 0 && (
              <button
                type="button"
                onClick={() => go("apps")}
                className="flex w-full items-center justify-center gap-1 py-3 text-sm font-semibold text-brand"
              >
                {t("dash.search.all")} <ChevronRight className="h-4 w-4" />
              </button>
            )}
          </Card>
        )}
      </div>

      {/* permissions pending */}
      <button
        type="button"
        onClick={() => push("permissions")}
        className="flex w-full items-center gap-3 rounded-3xl border border-warn/40 bg-warn/10 p-4 text-left transition active:scale-[0.99]"
      >
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-warn/20 text-warn">
          <ShieldAlert className="h-5 w-5" />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block font-bold">{t("dash.perm.title")}</span>
          <span className="block text-sm leading-snug text-muted">{t("dash.perm.desc")}</span>
        </span>
        <ChevronRight className="h-5 w-5 shrink-0 text-muted" />
      </button>

      {/* recent */}
      <section>
        <h2 className="mb-3 px-1 text-base font-bold">{t("dash.recent")}</h2>
        {recent.length === 0 ? (
          <Card className="p-5 text-center text-sm text-muted">{t("dash.recent.empty")}</Card>
        ) : (
          <div className="no-scrollbar -mx-5 flex gap-4 overflow-x-auto px-5 pb-1">
            {recent.map((a) => (
              <button
                key={a.packageName}
                type="button"
                onClick={() => go("apps")}
                className="flex w-[4.5rem] shrink-0 flex-col items-center gap-1.5"
              >
                <AppIcon app={a} size={56} />
                <span className="w-full truncate text-center text-xs font-medium">{a.label}</span>
              </button>
            ))}
          </div>
        )}
      </section>

      {/* quick access */}
      <section>
        <h2 className="mb-3 px-1 text-base font-bold">{t("dash.quick")}</h2>
        <div className="grid grid-cols-3 gap-3">
          {[
            { icon: KeyRound, label: t("dash.quick.pin"), action: () => push("changePin") },
            { icon: Fingerprint, label: t("dash.quick.fingerprint"), action: () => go("security") },
            { icon: SettingsIcon, label: t("dash.quick.settings"), action: () => go("settings") },
          ].map((q2) => (
            <button
              key={q2.label}
              type="button"
              onClick={q2.action}
              className="flex flex-col items-center gap-2 rounded-3xl border border-line bg-surface p-4 shadow-card transition active:scale-95"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-brand to-brand2 text-white shadow-glow">
                <q2.icon className="h-6 w-6" />
              </span>
              <span className="max-w-full truncate text-sm font-semibold">{q2.label}</span>
            </button>
          ))}
        </div>
        <button
          type="button"
          onClick={() => push("lockDemo")}
          className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl border border-line bg-surface2 py-3 text-sm font-semibold text-brand"
        >
          <Play className="h-4 w-4" />
          {t("dash.demo")}
        </button>
      </section>

      <PreviewNotice />
    </div>
  );
}
