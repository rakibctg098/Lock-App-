import { Fingerprint, Grid3x3, KeyRound, LifeBuoy, Play, Timer } from "lucide-react";
import { Card, PreviewNotice, Row, RowGroup, SectionLabel, Segmented, Toggle } from "@/components/ui";
import { useApp } from "@/state/AppContext";
import type { LockMethod, Route } from "@/types";

export function Security({ push }: { push: (route: Route) => void }) {
  const { t, fmt, state, setLockMethod, setBiometric, showToast } = useApp();

  const onMethod = (m: LockMethod) => {
    if (m === "pattern" && !state.pattern) {
      push("setPattern");
      return;
    }
    setLockMethod(m);
  };

  const onBiometric = (on: boolean) => {
    setBiometric(on);
    showToast(t(on ? "sec.bio.on" : "sec.bio.off"));
  };

  return (
    <div className="space-y-2">
      <div className="mb-4">
        <h1 className="text-2xl font-bold">{t("sec.title")}</h1>
        <p className="text-sm text-muted">{t("sec.subtitle")}</p>
      </div>

      <SectionLabel>{t("sec.method.title")}</SectionLabel>
      <Segmented<LockMethod>
        ariaLabel={t("sec.method.title")}
        value={state.lockMethod}
        onChange={onMethod}
        options={[
          { value: "pin", label: t("sec.method.pin") },
          { value: "pattern", label: t("sec.method.pattern") },
        ]}
      />

      <SectionLabel>PIN & {t("sec.method.pattern")}</SectionLabel>
      <RowGroup>
        <Row
          icon={<KeyRound className="h-5 w-5" />}
          title={t("sec.pin.change")}
          subtitle={t("sec.pin.desc", { n: fmt(state.pinLength) })}
          onClick={() => push("changePin")}
        />
        <Row
          icon={<Grid3x3 className="h-5 w-5" />}
          title={t(state.pattern ? "sec.pattern.change" : "sec.pattern.set")}
          subtitle={t(state.pattern ? "sec.pattern.active" : "sec.pattern.notSet")}
          onClick={() => push("setPattern")}
        />
      </RowGroup>

      <SectionLabel>{t("sec.bio.title")}</SectionLabel>
      <Card>
        <Row
          icon={<Fingerprint className="h-5 w-5" />}
          title={t("sec.bio.title")}
          subtitle={t("sec.bio.desc")}
          right={
            <Toggle
              checked={state.biometricEnabled}
              onChange={onBiometric}
              label={t("sec.bio.title")}
            />
          }
        />
        <p className="border-t border-line px-4 py-3 text-xs leading-relaxed text-muted">
          {t("sec.bio.note")}
        </p>
      </Card>

      <SectionLabel>{t("rec.regen")}</SectionLabel>
      <RowGroup>
        <Row
          icon={<LifeBuoy className="h-5 w-5" />}
          title={t("rec.regen")}
          subtitle={t("rec.regen.desc")}
          onClick={() => push("regenRecovery")}
        />
        <Row
          icon={<Timer className="h-5 w-5" />}
          title={t("sec.lockout.title")}
          subtitle={t("sec.lockout.desc")}
        />
      </RowGroup>

      <SectionLabel>{t("sec.demo")}</SectionLabel>
      <RowGroup>
        <Row
          icon={<Play className="h-5 w-5" />}
          title={t("sec.demo")}
          subtitle={t("sec.demo.desc")}
          onClick={() => push("lockDemo")}
        />
      </RowGroup>

      <p className="px-1 pt-3 text-xs leading-relaxed text-muted">{t("sec.storage")}</p>
      <div className="pt-2">
        <PreviewNotice compact />
      </div>
    </div>
  );
}
