import { useEffect, useState } from "react";
import {
  Accessibility,
  Bell,
  CheckCircle2,
  CircleCheck,
  Eye,
  Fingerprint,
  Layers,
  ShieldCheck,
} from "lucide-react";
import { Button, Card, PreviewNotice, SectionLabel, Sheet, SubPage } from "@/components/ui";
import { useApp } from "@/state/AppContext";
import { bridge, type PermissionStatuses } from "@/services/nativeBridge";
import type { TKey } from "@/i18n/translations";

interface Perm {
  id: "usage" | "overlay" | "notif" | "bio" | "acc";
  icon: typeof Eye;
  title: TKey;
  why: TKey;
  required: boolean;
}

const PERMS: Perm[] = [
  { id: "usage", icon: Eye, title: "perm.usage.title", why: "perm.usage.why", required: true },
  { id: "overlay", icon: Layers, title: "perm.overlay.title", why: "perm.overlay.why", required: true },
  { id: "notif", icon: Bell, title: "perm.notif.title", why: "perm.notif.why", required: true },
  { id: "bio", icon: Fingerprint, title: "perm.bio.title", why: "perm.bio.why", required: false },
  { id: "acc", icon: Accessibility, title: "perm.acc.title", why: "perm.acc.why", required: false },
];

export function Permissions({ onBack }: { onBack: () => void }) {
  const { t, state, setAccessibilityConsent, showToast } = useApp();
  const [open, setOpen] = useState(false);
  const [checked, setChecked] = useState(false);
  const [statuses, setStatuses] = useState<PermissionStatuses>({
    usage: false,
    overlay: false,
    notif: false,
    bio: false,
    acc: false,
  });

  const checkPerms = async () => {
    const s = await bridge.getPermissionStatuses();
    setStatuses(s);
  };

  useEffect(() => {
    void checkPerms();
    const onFocus = () => {
      void checkPerms();
    };
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onFocus);
    return () => {
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("visibilitychange", onFocus);
    };
  }, []);

  const openDisclosure = () => {
    setChecked(false);
    setOpen(true);
  };

  const agree = async () => {
    if (!checked) return;
    setAccessibilityConsent(true);
    setOpen(false);
    if (bridge.engineAvailable) {
      await bridge.requestPermission("acc");
      setTimeout(() => void checkPerms(), 1000);
    } else {
      showToast(t("preview.unavailable"));
    }
  };

  const onGrant = async (id: string) => {
    if (id === "acc") return openDisclosure();
    if (bridge.engineAvailable) {
      await bridge.requestPermission(id);
      setTimeout(() => void checkPerms(), 1000);
    } else {
      showToast(t("preview.unavailable"));
    }
  };

  const allRequiredGranted = statuses.usage && statuses.overlay;

  return (
    <SubPage title={t("perm.title")} onBack={onBack}>
      <p className="mb-4 text-sm leading-relaxed text-muted">{t("perm.subtitle")}</p>

      {bridge.kind === "android" ? (
        allRequiredGranted ? (
          <div className="mb-4 flex items-center gap-3 rounded-2xl border border-ok/40 bg-ok/10 p-3.5">
            <CheckCircle2 className="h-5 w-5 shrink-0 text-ok" />
            <div className="min-w-0">
              <p className="text-sm font-semibold text-ok">
                {state.lang === "bn" ? "প্রয়োজনীয় অনুমতিগুলো সক্রিয় আছে" : "Required permissions are granted"}
              </p>
              <p className="text-xs text-muted">
                {state.lang === "bn" ? "অ্যাপ লকার সম্পূর্ণ সচল এবং সুরক্ষিত।" : "App locker engine is active and operational."}
              </p>
            </div>
          </div>
        ) : (
          <div className="mb-4 flex items-center gap-3 rounded-2xl border border-warn/40 bg-warn/10 p-3.5">
            <Eye className="h-5 w-5 shrink-0 text-warn" />
            <div className="min-w-0">
              <p className="text-sm font-semibold text-warn">
                {state.lang === "bn" ? "ইউসেজ ও ওভারলে অনুমতি আবশ্যক" : "Usage & Overlay permissions required"}
              </p>
              <p className="text-xs text-muted">
                {state.lang === "bn" ? "লক কার্যকর করতে নিচের বোতামে চাপ দিয়ে অনুমতি দিন।" : "Grant the permissions below to lock applications."}
              </p>
            </div>
          </div>
        )
      ) : (
        <PreviewNotice compact />
      )}

      <div className="mt-4 space-y-3">
        {PERMS.map((p) => {
          const isGranted = statuses[p.id];
          return (
            <Card key={p.id} className="p-4">
              <div className="flex items-start gap-3">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-brand/15 text-brand">
                  <p.icon className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-bold">{t(p.title)}</p>
                    <span
                      className={
                        p.required
                          ? "rounded-full bg-brand/15 px-2 py-0.5 text-[11px] font-bold text-brand"
                          : "rounded-full bg-surface2 px-2 py-0.5 text-[11px] font-bold text-muted"
                      }
                    >
                      {t(p.required ? "common.required" : "common.optional")}
                    </span>
                  </div>
                  <p className="mt-1 text-sm leading-snug text-muted">{t(p.why)}</p>
                  {p.id === "acc" && state.accessibilityConsent && (
                    <p className="mt-2 flex items-center gap-1.5 text-sm font-semibold text-ok">
                      <CircleCheck className="h-4 w-4" /> {t("acc.consented")}
                    </p>
                  )}
                </div>
              </div>
              <div className="mt-3 flex items-center justify-between gap-3 border-t border-line pt-3">
                <span className="text-xs">
                  {bridge.kind === "android" ? (
                    isGranted ? (
                      <span className="flex items-center gap-1 font-semibold text-ok">
                        <CircleCheck className="h-3.5 w-3.5" />
                        {state.lang === "bn" ? "অনুমোদিত" : "Granted"}
                      </span>
                    ) : (
                      <span className="font-semibold text-warn">
                        {state.lang === "bn" ? "অনুমতি প্রয়োজন" : "Not granted"}
                      </span>
                    )
                  ) : (
                    <span className="text-muted">{t("perm.status.unknown")}</span>
                  )}
                </span>
                <div className="flex gap-2">
                  {p.id === "acc" && state.accessibilityConsent && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setAccessibilityConsent(false);
                        showToast(t("acc.withdrawn"));
                      }}
                    >
                      {t("acc.withdraw")}
                    </Button>
                  )}
                  {isGranted ? (
                    <Button size="sm" variant="secondary" onClick={() => onGrant(p.id)}>
                      {state.lang === "bn" ? "পুনরায় দেখুন" : "View"}
                    </Button>
                  ) : (
                    <Button size="sm" onClick={() => onGrant(p.id)}>
                      {p.id === "acc" ? t("acc.open") : t("perm.grant")}
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      <SectionLabel>{t("perm.mode.title")}</SectionLabel>
      <Card className="space-y-2 p-4 text-sm leading-relaxed">
        <p>• {t("perm.mode.standard")}</p>
        <p>• {t("perm.mode.acc")}</p>
      </Card>

      <div className="mt-4 flex gap-3 rounded-2xl border border-ok/40 bg-ok/10 p-4">
        <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-ok" />
        <p className="text-sm leading-relaxed">{t("perm.revoke")}</p>
      </div>

      <SectionLabel>{t("perm.play.title")}</SectionLabel>
      <Card className="space-y-3 p-4 text-sm leading-relaxed text-muted">
        <p>1. {t("perm.play.1")}</p>
        <p>2. {t("perm.play.2")}</p>
        <p>3. {t("perm.play.3")}</p>
        <p className="text-xs">{t("perm.play.note")}</p>
      </Card>

      <Sheet open={open} onClose={() => setOpen(false)} title={t("acc.title")}>
        <p className="text-sm font-semibold leading-relaxed">{t("acc.intro")}</p>
        <div className="mt-4 space-y-3">
          {(
            [
              ["acc.accessed.title", "acc.accessed.body"],
              ["acc.why.title", "acc.why.body"],
              ["acc.never.title", "acc.never.body"],
              ["acc.control.title", "acc.control.body"],
            ] as [TKey, TKey][]
          ).map(([title, body]) => (
            <div key={title} className="rounded-2xl bg-surface2 p-3.5">
              <p className="font-bold">{t(title)}</p>
              <p className="mt-1 text-sm leading-relaxed text-muted">{t(body)}</p>
            </div>
          ))}
        </div>
        <label className="mt-4 flex cursor-pointer items-start gap-3 rounded-2xl border border-line p-3.5">
          <input
            type="checkbox"
            checked={checked}
            onChange={(e) => setChecked(e.target.checked)}
            className="mt-1 h-5 w-5 shrink-0 accent-[var(--brand)]"
          />
          <span className="text-sm font-semibold">{t("acc.consent")}</span>
        </label>
        <div className="mt-4 grid grid-cols-2 gap-3">
          <Button variant="secondary" onClick={() => setOpen(false)}>
            {t("acc.decline")}
          </Button>
          <Button disabled={!checked} onClick={() => void agree()}>
            {t("acc.agree")}
          </Button>
        </div>
      </Sheet>
    </SubPage>
  );
}
