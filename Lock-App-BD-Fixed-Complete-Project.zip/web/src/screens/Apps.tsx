import { useMemo, useState } from "react";
import { Info, RefreshCw, Search, X } from "lucide-react";
import { AppRow } from "@/components/AppRow";
import { Button, Card, PreviewNotice, Segmented } from "@/components/ui";
import { useApp } from "@/state/AppContext";
import { cn } from "@/utils/cn";
import type { AppCategory } from "@/types";

type StatusFilter = "all" | "locked" | "unlocked";
const CATEGORIES: AppCategory[] = [
  "social",
  "messaging",
  "finance",
  "media",
  "shopping",
  "productivity",
  "tools",
  "games",
];

export function Apps() {
  const { t, fmt, state, apps, appsStatus, hiddenCount, reloadApps } = useApp();
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<StatusFilter>("all");
  const [category, setCategory] = useState<AppCategory | "all">("all");
  const [showWhy, setShowWhy] = useState(false);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const locked = new Set(state.lockedApps);
    return apps.filter((a) => {
      if (category !== "all" && a.category !== category) return false;
      const isLocked = locked.has(a.packageName);
      if (status === "locked" && !isLocked) return false;
      if (status === "unlocked" && isLocked) return false;
      if (!q) return true;
      return a.label.toLowerCase().includes(q) || a.packageName.toLowerCase().includes(q);
    });
  }, [apps, query, status, category, state.lockedApps]);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">{t("apps.title")}</h1>
        {appsStatus === "ready" && (
          <p className="text-sm text-muted">{t("apps.count", { n: fmt(apps.length) })}</p>
        )}
      </div>

      <PreviewNotice compact />

      <div className="relative">
        <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted" />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t("apps.search")}
          aria-label={t("apps.search")}
          className="h-12 w-full rounded-2xl border border-line bg-surface pl-12 pr-11 text-base text-ink placeholder:text-muted focus:border-brand focus:outline-none"
        />
        {query && (
          <button
            type="button"
            onClick={() => setQuery("")}
            aria-label={t("common.close")}
            className="absolute right-2 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full text-muted"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      <Segmented<StatusFilter>
        ariaLabel={t("apps.title")}
        value={status}
        onChange={setStatus}
        options={[
          { value: "all", label: t("apps.filter.all") },
          { value: "locked", label: t("apps.filter.locked") },
          { value: "unlocked", label: t("apps.filter.unlocked") },
        ]}
      />

      <div className="no-scrollbar -mx-5 flex gap-2 overflow-x-auto px-5">
        {(["all", ...CATEGORIES] as const).map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setCategory(c)}
            aria-pressed={category === c}
            className={cn(
              "h-9 shrink-0 rounded-full border px-4 text-sm font-semibold transition",
              category === c
                ? "border-transparent bg-gradient-to-br from-brand to-brand2 text-white"
                : "border-line bg-surface text-muted",
            )}
          >
            {c === "all" ? t("common.all") : t(`cat.${c}`)}
          </button>
        ))}
      </div>

      {appsStatus === "loading" && (
        <Card className="divide-y divide-line overflow-hidden" aria-busy="true">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="flex items-center gap-3 px-4 py-3">
              <div className="h-[46px] w-[46px] animate-pulse rounded-2xl bg-surface2" />
              <div className="flex-1 space-y-2">
                <div className="h-3.5 w-1/2 animate-pulse rounded bg-surface2" />
                <div className="h-3 w-3/4 animate-pulse rounded bg-surface2" />
              </div>
              <div className="h-7 w-12 animate-pulse rounded-full bg-surface2" />
            </div>
          ))}
        </Card>
      )}

      {appsStatus === "error" && (
        <Card className="flex flex-col items-center gap-3 p-6 text-center">
          <p className="font-semibold text-bad">{t("apps.error")}</p>
          <Button variant="secondary" onClick={reloadApps}>
            <RefreshCw className="h-4 w-4" /> {t("common.retry")}
          </Button>
        </Card>
      )}

      {appsStatus === "ready" && (
        <>
          {filtered.length === 0 ? (
            <Card className="p-8 text-center text-sm text-muted">
              {status === "locked" && !query && category === "all"
                ? t("apps.emptyLocked")
                : t("apps.empty")}
            </Card>
          ) : (
            <Card className="divide-y divide-line overflow-hidden">
              {filtered.map((a) => (
                <AppRow key={a.packageName} app={a} />
              ))}
            </Card>
          )}

          {hiddenCount > 0 && (
            <div className="rounded-2xl border border-line bg-surface p-3.5">
              <button
                type="button"
                onClick={() => setShowWhy((v) => !v)}
                aria-expanded={showWhy}
                className="flex w-full items-center gap-2 text-left text-sm font-semibold"
              >
                <Info className="h-4 w-4 shrink-0 text-brand" />
                {t("apps.hidden", { n: fmt(hiddenCount) })}
              </button>
              {showWhy && (
                <p className="mt-2 text-sm leading-relaxed text-muted">{t("apps.hidden.why")}</p>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}
