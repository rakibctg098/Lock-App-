import { CircleCheck, CircleDashed } from "lucide-react";
import { Logo } from "@/components/Logo";
import { Card, SectionLabel, SubPage } from "@/components/ui";
import { useApp } from "@/state/AppContext";
import { APP_NAME, APP_PACKAGE, APP_VERSION, DEVELOPER_NAME } from "@/config";
import { bridge } from "@/services/nativeBridge";
import type { TKey } from "@/i18n/translations";

/** Feature status. */
const STATUS_PREVIEW: { label: TKey; phase: number | null }[] = [
  { label: "st.ui", phase: null },
  { label: "st.i18n", phase: null },
  { label: "st.pin", phase: null },
  { label: "st.capacitor", phase: 4 },
  { label: "st.apps", phase: 5 },
  { label: "st.engine", phase: 6 },
  { label: "st.bio", phase: 7 },
  { label: "st.perm", phase: 8 },
  { label: "st.apk", phase: 10 },
];

const STATUS_ANDROID: { label: TKey; phase: number | null }[] = [
  { label: "st.ui", phase: null },
  { label: "st.i18n", phase: null },
  { label: "st.pin", phase: null },
  { label: "st.capacitor", phase: null },
  { label: "st.apps", phase: null },
  { label: "st.engine", phase: null },
  { label: "st.bio", phase: null },
  { label: "st.perm", phase: null },
  { label: "st.apk", phase: null },
];

const TECH = ["React", "TypeScript", "Vite", "Tailwind CSS", "Android Native (Kotlin)", "Jetpack Compose"];

export function About({ onBack }: { onBack: () => void }) {
  const { t, fmt } = useApp();
  const statusList = bridge.kind === "android" ? STATUS_ANDROID : STATUS_PREVIEW;
  return (
    <SubPage title={t("about.title")} onBack={onBack}>
      <div className="flex flex-col items-center pt-2 text-center">
        <Logo size={84} />
        <h2 className="mt-4 text-2xl font-bold">{APP_NAME}</h2>
        <p className="text-sm text-muted">
          {t("set.version")}: {APP_VERSION}
        </p>
        <p className="mt-3 text-sm leading-relaxed text-muted">{t("about.desc")}</p>
      </div>

      <Card className="mt-5 divide-y divide-line">
        <div className="flex items-center justify-between gap-3 p-4">
          <span className="text-sm text-muted">{t("set.developer")}</span>
          <span className="font-semibold">{DEVELOPER_NAME}</span>
        </div>
        <div className="flex items-center justify-between gap-3 p-4">
          <span className="text-sm text-muted">{t("about.package")}</span>
          <span className="break-all text-right font-mono text-xs font-semibold">{APP_PACKAGE}</span>
        </div>
      </Card>

      <SectionLabel>{t("about.tech")}</SectionLabel>
      <div className="flex flex-wrap gap-2">
        {TECH.map((x) => (
          <span key={x} className="rounded-full border border-line bg-surface px-3 py-1.5 text-xs font-semibold">
            {x}
          </span>
        ))}
      </div>

      <SectionLabel>{t("about.status.title")}</SectionLabel>
      <p className="mb-3 px-1 text-sm leading-relaxed text-muted">{t("about.status.note")}</p>
      <Card className="divide-y divide-line">
        {statusList.map((s) => (
          <div key={s.label} className="flex items-center gap-3 p-3.5">
            {s.phase === null ? (
              <CircleCheck className="h-5 w-5 shrink-0 text-ok" />
            ) : (
              <CircleDashed className="h-5 w-5 shrink-0 text-warn" />
            )}
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold">{t(s.label)}</p>
              <p className={s.phase === null ? "text-xs text-ok" : "text-xs text-warn"}>
                {s.phase === null ? t("status.preview") : t("status.planned", { n: fmt(s.phase) })}
              </p>
            </div>
          </div>
        ))}
      </Card>
    </SubPage>
  );
}
