import { Ban, Eye, FileText, Globe, Hand, LifeBuoy, Smartphone } from "lucide-react";
import { Card, SubPage } from "@/components/ui";
import { useApp } from "@/state/AppContext";
import type { TKey } from "@/i18n/translations";

const SECTIONS: { icon: typeof Ban; title: TKey; body: TKey }[] = [
  { icon: Ban, title: "privacy.s1.title", body: "privacy.s1.body" },
  { icon: Eye, title: "privacy.s2.title", body: "privacy.s2.body" },
  { icon: Smartphone, title: "privacy.s3.title", body: "privacy.s3.body" },
  { icon: Globe, title: "privacy.s4.title", body: "privacy.s4.body" },
  { icon: FileText, title: "privacy.s5.title", body: "privacy.s5.body" },
  { icon: Hand, title: "privacy.s6.title", body: "privacy.s6.body" },
  { icon: LifeBuoy, title: "privacy.s7.title", body: "privacy.s7.body" },
];

export function Privacy({ onBack }: { onBack: () => void }) {
  const { t } = useApp();
  return (
    <SubPage title={t("privacy.title")} onBack={onBack}>
      <div className="space-y-3">
        {SECTIONS.map((s) => (
          <Card key={s.title} className="flex gap-3 p-4">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-brand/15 text-brand">
              <s.icon className="h-5 w-5" />
            </span>
            <div>
              <h2 className="font-bold">{t(s.title)}</h2>
              <p className="mt-1 text-sm leading-relaxed text-muted">{t(s.body)}</p>
            </div>
          </Card>
        ))}
      </div>
      <p className="mt-4 rounded-2xl bg-warn/10 p-3.5 text-xs leading-relaxed text-warn">
        {t("privacy.draft")}
      </p>
    </SubPage>
  );
}
