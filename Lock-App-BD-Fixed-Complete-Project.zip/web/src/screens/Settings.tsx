import {
  Accessibility,
  FileText,
  Fingerprint,
  Info,
  KeyRound,
  Languages,
  MessageCircle,
  Moon,
  Palette,
  Send,
  ShieldCheck,
  Smartphone,
  Sun,
  Trash2,
  UserRound,
} from "lucide-react";
import { Card, Row, RowGroup, SectionLabel, Segmented, Toggle } from "@/components/ui";
import { Logo } from "@/components/Logo";
import { useApp } from "@/state/AppContext";
import { bridge } from "@/services/nativeBridge";
import {
  APP_VERSION,
  DEVELOPER_NAME,
  TELEGRAM_URL,
  WHATSAPP_URL,
} from "@/config";
import type { Lang, Route, ThemeMode } from "@/types";

export function Settings({ push }: { push: (route: Route) => void }) {
  const { t, state, setLang, setTheme, setBiometric, showToast } = useApp();

  const openLink = async (url: string) => {
    const ok = await bridge.openExternal(url);
    if (!ok) showToast(t("set.link.error"));
  };

  return (
    <div className="space-y-2">
      <h1 className="mb-4 text-2xl font-bold">{t("set.title")}</h1>

      <SectionLabel>{t("set.appearance")}</SectionLabel>
      <Card className="space-y-4 p-4">
        <div>
          <p className="mb-2 flex items-center gap-2 text-sm font-semibold">
            <Languages className="h-4 w-4 text-brand" />
            {t("set.language")}
          </p>
          <Segmented<Lang>
            ariaLabel={t("set.language")}
            value={state.lang}
            onChange={setLang}
            options={[
              { value: "bn", label: "বাংলা" },
              { value: "en", label: "English" },
            ]}
          />
        </div>
        <div>
          <p className="mb-2 flex items-center gap-2 text-sm font-semibold">
            <Palette className="h-4 w-4 text-brand" />
            {t("set.theme")}
          </p>
          <Segmented<ThemeMode>
            ariaLabel={t("set.theme")}
            value={state.theme}
            onChange={setTheme}
            options={[
              { value: "dark", label: t("theme.dark") },
              { value: "light", label: t("theme.light") },
              { value: "system", label: t("theme.system") },
            ]}
          />
          <p className="mt-2 flex items-center gap-1.5 text-xs text-muted">
            {state.theme === "light" ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
            {t(`theme.${state.theme}`)}
          </p>
        </div>
      </Card>

      <SectionLabel>{t("set.security")}</SectionLabel>
      <RowGroup>
        <Row
          icon={<KeyRound className="h-5 w-5" />}
          title={t("set.changePin")}
          onClick={() => push("changePin")}
        />
        <Row
          icon={<Fingerprint className="h-5 w-5" />}
          title={t("set.fingerprint")}
          subtitle={t("sec.bio.desc")}
          right={
            <Toggle
              checked={state.biometricEnabled}
              onChange={(on) => {
                setBiometric(on);
                showToast(t(on ? "sec.bio.on" : "sec.bio.off"));
              }}
              label={t("set.fingerprint")}
            />
          }
        />
      </RowGroup>

      <SectionLabel>{t("set.protection")}</SectionLabel>
      <RowGroup>
        <Row
          icon={<ShieldCheck className="h-5 w-5" />}
          title={t("set.permissions")}
          subtitle={t("set.permissions.desc")}
          onClick={() => push("permissions")}
        />
        <Row
          icon={<Accessibility className="h-5 w-5" />}
          title={t("acc.title")}
          subtitle={state.accessibilityConsent ? t("acc.consented") : t("common.optional")}
          onClick={() => push("permissions")}
        />
      </RowGroup>

      <SectionLabel>{t("set.info")}</SectionLabel>
      <RowGroup>
        <Row
          icon={<FileText className="h-5 w-5" />}
          title={t("set.privacy")}
          onClick={() => push("privacy")}
        />
        <Row
          icon={<Info className="h-5 w-5" />}
          title={t("set.about")}
          onClick={() => push("about")}
        />
        <Row
          icon={<Smartphone className="h-5 w-5" />}
          title={t("set.version")}
          right={<span className="text-sm font-semibold text-muted">{APP_VERSION}</span>}
        />
      </RowGroup>

      <SectionLabel>{t("set.developer")}</SectionLabel>
      <Card className="overflow-hidden">
        <div className="flex items-center gap-3 p-4">
          <Logo size={48} />
          <div className="min-w-0">
            <p className="flex items-center gap-1.5 font-bold">
              <UserRound className="h-4 w-4 text-brand" />
              {DEVELOPER_NAME}
            </p>
            <p className="text-sm text-muted">{t("set.made")}</p>
          </div>
        </div>
        <div className="divide-y divide-line border-t border-line">
          <Row
            icon={<Send className="h-5 w-5" />}
            title={t("set.telegram")}
            subtitle="t.me/appdevbyrakib"
            onClick={() => void openLink(TELEGRAM_URL)}
          />
          <Row
            icon={<MessageCircle className="h-5 w-5" />}
            title={t("set.whatsapp")}
            subtitle="chat.whatsapp.com"
            tone="ok"
            onClick={() => void openLink(WHATSAPP_URL)}
          />
        </div>
        <p className="border-t border-line px-4 py-3 text-xs text-muted">{t("set.link.note")}</p>
      </Card>

      <SectionLabel>{t("set.reset")}</SectionLabel>
      <RowGroup>
        <Row
          icon={<Trash2 className="h-5 w-5" />}
          title={t("set.reset")}
          subtitle={t("set.reset.desc")}
          tone="bad"
          onClick={() => push("reset")}
        />
      </RowGroup>
    </div>
  );
}
