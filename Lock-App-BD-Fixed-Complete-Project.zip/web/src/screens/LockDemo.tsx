import { useState } from "react";
import { CircleCheck, Fingerprint, LifeBuoy, ShieldAlert, X } from "lucide-react";
import { AppIcon } from "@/components/AppIcon";
import { PatternLock } from "@/components/PatternLock";
import { PinPad } from "@/components/PinPad";
import { LockoutNotice } from "@/components/LockoutNotice";
import { Button } from "@/components/ui";
import { useApp, useLockoutRemaining } from "@/state/AppContext";
import { normalizeRecoveryCode } from "@/services/pinSecurity";

type Mode = "auth" | "recover" | "unlocked";

/**
 * VISUAL SIMULATION of the future native lock Activity.
 * It verifies against the user's real (hashed) PIN/pattern so the security
 * logic can be tested, but it does NOT protect any real app.
 */
export function LockDemo({
  onClose,
  onRecovered,
}: {
  onClose: () => void;
  onRecovered: () => void;
}) {
  const { t, state, apps, attempt, showToast } = useApp();
  const remaining = useLockoutRemaining();
  const [mode, setMode] = useState<Mode>("auth");
  const [forcePin, setForcePin] = useState(false);
  const [error, setError] = useState("");
  const [shake, setShake] = useState(0);
  const [busy, setBusy] = useState(false);
  const [code, setCode] = useState("");

  const lockedSet = new Set(state.lockedApps);
  const demoApp = apps.find((a) => lockedSet.has(a.packageName)) ?? apps[0];
  const method = state.lockMethod === "pattern" && state.pattern && !forcePin ? "pattern" : "pin";

  const fail = (msg: string) => {
    setError(msg);
    setShake((n) => n + 1);
  };

  const verify = async (kind: "pin" | "pattern", secret: string) => {
    if (busy) return;
    setBusy(true);
    const r = await attempt(kind, secret);
    setBusy(false);
    if (r.ok) {
      setError("");
      setMode("unlocked");
    } else {
      fail(
        r.error === "crypto"
          ? t("pin.cryptoError")
          : r.locked
            ? ""
            : t(kind === "pin" ? "pin.wrong" : "pat.wrong"),
      );
    }
  };

  const onPattern = (seq: number[]) => {
    if (seq.length < 4) return fail(t("pat.tooShort"));
    void verify("pattern", seq.join(""));
  };

  const onRecover = async () => {
    if (busy || normalizeRecoveryCode(code).length === 0) return;
    setBusy(true);
    const r = await attempt("recovery", code);
    setBusy(false);
    if (r.ok) {
      onRecovered();
    } else {
      fail(r.error === "crypto" ? t("pin.cryptoError") : r.locked ? "" : t("rec.wrong"));
    }
  };

  return (
    <div
      data-theme="dark"
      className="relative flex min-h-0 flex-1 flex-col bg-gradient-to-b from-[#050a1a] to-[#0c2354] text-[#eef3ff]"
    >
      {/* demo banner */}
      <div className="flex items-start gap-3 bg-warn/15 px-4 pb-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-amber-300" />
        <p className="flex-1 text-xs leading-snug text-amber-100">
          <b>{t("lock.demo")}.</b> {t("lock.demo.note")}
        </p>
        <button
          type="button"
          onClick={onClose}
          aria-label={t("common.close")}
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/10"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="no-scrollbar flex min-h-0 flex-1 flex-col items-center overflow-y-auto px-6 pb-8 pt-6 text-center">
        {demoApp && <AppIcon app={demoApp} size={72} />}

        {mode === "unlocked" && (
          <div className="mt-10 flex animate-rise flex-col items-center">
            <CircleCheck className="h-20 w-20 text-emerald-400" />
            <h2 className="mt-4 text-2xl font-bold">{t("lock.unlocked")}</h2>
            <Button size="lg" className="mt-8" onClick={onClose}>
              {t("common.done")}
            </Button>
          </div>
        )}

        {mode === "auth" && (
          <>
            <h2 className="mt-4 text-2xl font-bold">
              {t("lock.title", { name: demoApp?.label ?? "App" })}
            </h2>
            <p className="mt-1 text-sm text-slate-300">
              {t(method === "pin" ? "lock.enter.pin" : "lock.enter.pattern")}
            </p>
            <div className="mb-6 mt-3 min-h-6">
              <LockoutNotice remaining={remaining} error={error} />
            </div>

            {method === "pin" ? (
              <PinPad
                length={state.pinLength}
                onComplete={(p) => void verify("pin", p)}
                disabled={remaining > 0 || busy}
                error={!!error || remaining > 0}
                shakeKey={shake}
              />
            ) : (
              <PatternLock
                onComplete={onPattern}
                disabled={remaining > 0 || busy}
                error={!!error || remaining > 0}
                shakeKey={shake}
              />
            )}

            <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
              {state.biometricEnabled && (
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={async () => {
                    if (bridge.engineAvailable) {
                      const ok = await bridge.authenticateBiometric();
                      if (ok) {
                        setError("");
                        setMode("unlocked");
                      } else {
                        showToast(state.lang === "bn" ? "ফিঙ্গারপ্রিন্ট মেলেনি বা বাতিল হয়েছে" : "Biometric authentication failed");
                      }
                    } else {
                      showToast(t("preview.unavailable"));
                    }
                  }}
                >
                  <Fingerprint className="h-4 w-4" />
                  {t("lock.biometric")}
                </Button>
              )}
              {state.lockMethod === "pattern" && state.pattern && (
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => {
                    setForcePin((v) => !v);
                    setError("");
                  }}
                >
                  {t(method === "pin" ? "lock.usePattern" : "lock.usePin")}
                </Button>
              )}
              <Button
                variant="ghost"
                size="sm"
                className="text-sky-300"
                onClick={() => {
                  setMode("recover");
                  setError("");
                }}
              >
                <LifeBuoy className="h-4 w-4" />
                {t("pin.forgot")}
              </Button>
            </div>
            <p className="mt-6 max-w-xs text-xs text-slate-400">{t("lock.emergency")}</p>
          </>
        )}

        {mode === "recover" && (
          <div className="mt-6 w-full max-w-sm animate-rise">
            <h2 className="text-2xl font-bold">{t("rec.enter.title")}</h2>
            <p className="mt-1 text-sm text-slate-300">{t("rec.enter.subtitle")}</p>
            <input
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="XXXX-XXXX-XXXX-XXXX"
              autoCapitalize="characters"
              autoComplete="off"
              autoCorrect="off"
              spellCheck={false}
              maxLength={24}
              aria-label={t("rec.enter.title")}
              className="mt-5 h-14 w-full rounded-2xl border border-white/20 bg-white/10 px-4 text-center font-mono text-lg tracking-widest text-white placeholder:text-slate-500 focus:border-sky-400 focus:outline-none"
            />
            <div className="mt-3 min-h-6">
              <LockoutNotice remaining={remaining} error={error} />
            </div>
            <p className="text-xs text-slate-400">{t("rec.hint")}</p>
            <Button
              full
              size="lg"
              className="mt-5"
              disabled={busy || remaining > 0 || code.trim().length === 0}
              onClick={() => void onRecover()}
            >
              {t("rec.verify")}
            </Button>
            <Button
              full
              variant="ghost"
              className="mt-2 text-sky-300"
              onClick={() => {
                setMode("auth");
                setError("");
              }}
            >
              {t("common.back")}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
