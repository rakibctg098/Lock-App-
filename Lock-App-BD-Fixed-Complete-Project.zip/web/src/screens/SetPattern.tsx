import { useState } from "react";
import { Grid3x3 } from "lucide-react";
import { PatternLock } from "@/components/PatternLock";
import { PinGate } from "@/components/PinGate";
import { SubPage } from "@/components/ui";
import { useApp } from "@/state/AppContext";

type Step = "gate" | "draw" | "confirm";

/** Pattern setup: verify PIN first, then draw twice. Minimum 4 dots. */
export function SetPattern({ onBack }: { onBack: () => void }) {
  const { t, savePattern, setLockMethod, showToast } = useApp();
  const [step, setStep] = useState<Step>("gate");
  const [first, setFirst] = useState("");
  const [error, setError] = useState("");
  const [shake, setShake] = useState(0);
  const [busy, setBusy] = useState(false);

  const fail = (msg: string) => {
    setError(msg);
    setShake((n) => n + 1);
  };

  const onDraw = (seq: number[]) => {
    if (seq.length < 4) return fail(t("pat.tooShort"));
    setError("");
    setFirst(seq.join(""));
    setStep("confirm");
  };

  const onConfirm = async (seq: number[]) => {
    if (busy) return;
    if (seq.join("") !== first) {
      setFirst("");
      setStep("draw");
      return fail(t("pat.mismatch"));
    }
    setBusy(true);
    try {
      await savePattern(seq.join(""));
      setLockMethod("pattern");
      showToast(t("pat.saved"));
      onBack();
    } catch {
      setStep("draw");
      fail(t("pin.cryptoError"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <SubPage title={t("pat.setTitle")} onBack={onBack}>
      {step === "gate" ? (
        <PinGate onSuccess={() => setStep("draw")} />
      ) : (
        <div className="flex flex-col items-center pt-4 text-center">
          <span className="flex h-16 w-16 items-center justify-center rounded-3xl bg-brand/15 text-brand">
            <Grid3x3 className="h-8 w-8" />
          </span>
          <h2 className="mt-4 text-2xl font-bold">
            {step === "draw" ? t("pat.draw") : t("pat.confirm")}
          </h2>
          <p className={error ? "mt-1 text-sm font-semibold text-bad" : "mt-1 text-sm text-muted"} role={error ? "alert" : undefined}>
            {error || t("pat.hint")}
          </p>
          <div className="mt-8 w-full">
            <PatternLock
              onComplete={step === "draw" ? onDraw : onConfirm}
              disabled={busy}
              error={!!error}
              shakeKey={shake}
            />
          </div>
        </div>
      )}
    </SubPage>
  );
}
