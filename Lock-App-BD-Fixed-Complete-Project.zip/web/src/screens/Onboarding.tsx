import { useState } from "react";
import {
  ArrowLeft,
  Ban,
  Bell,
  Check,
  Fingerprint,
  Hand,
  Layers,
  Accessibility,
  ShieldCheck,
  WifiOff,
  Eye,
} from "lucide-react";
import { Logo } from "@/components/Logo";
import { Button, Card } from "@/components/ui";
import { PinSetupFlow } from "@/components/PinSetupFlow";
import { useApp } from "@/state/AppContext";
import { cn } from "@/utils/cn";
import type { Lang } from "@/types";
import type { TKey } from "@/i18n/translations";

const TOTAL = 4;

const LANGS: { code: Lang; native: string; sub: string }[] = [
  { code: "bn", native: "বাংলা", sub: "Bengali" },
  { code: "en", native: "English", sub: "ইংরেজি" },
];

export function Onboarding() {
  const { t, lang, setLang, completeOnboarding, fmt } = useApp();
  const [step, setStep] = useState(0);

  const features: { icon: typeof Ban; title: TKey; desc: TKey }[] = [
    { icon: Ban, title: "ob.f1.title", desc: "ob.f1.desc" },
    { icon: WifiOff, title: "ob.f2.title", desc: "ob.f2.desc" },
    { icon: ShieldCheck, title: "ob.f3.title", desc: "ob.f3.desc" },
    { icon: Hand, title: "ob.f4.title", desc: "ob.f4.desc" },
  ];

  const perms: { icon: typeof Ban; title: TKey; why: TKey }[] = [
    { icon: Eye, title: "perm.usage.title", why: "perm.usage.why" },
    { icon: Layers, title: "perm.overlay.title", why: "perm.overlay.why" },
    { icon: Accessibility, title: "perm.acc.title", why: "perm.acc.why" },
    { icon: Bell, title: "perm.notif.title", why: "perm.notif.why" },
    { icon: Fingerprint, title: "perm.bio.title", why: "perm.bio.why" },
  ];

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      {/* header: back + progress */}
      <div className="flex items-center gap-3 px-5 pb-2 pt-[max(1.25rem,env(safe-area-inset-top))]">
        <button
          type="button"
          onClick={() => setStep((s) => Math.max(0, s - 1))}
          aria-label={t("common.back")}
          disabled={step === 0 || step === 3}
          className={cn(
            "flex h-10 w-10 items-center justify-center rounded-2xl border border-line bg-surface transition active:scale-95",
            (step === 0 || step === 3) && "invisible",
          )}
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div className="flex flex-1 gap-1.5" aria-hidden="true">
          {Array.from({ length: TOTAL }).map((_, i) => (
            <span
              key={i}
              className={cn(
                "h-1.5 flex-1 rounded-full transition-colors",
                i <= step ? "bg-gradient-to-r from-brand to-brand2" : "bg-line",
              )}
            />
          ))}
        </div>
        <span className="text-xs font-semibold text-muted">
          {t("ob.step", { n: fmt(step + 1), total: fmt(TOTAL) })}
        </span>
      </div>

      <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto px-5 pb-6 pt-4">
        {step === 0 && (
          <div className="animate-rise">
            <div className="flex flex-col items-center pt-4 text-center">
              <Logo size={88} />
              <h1 className="mt-5 text-3xl font-bold">Lock App BD</h1>
              <p className="mt-1 text-muted">{t("app.tagline")}</p>
            </div>
            <h2 className="mt-10 text-xl font-bold">{t("ob.lang.title")}</h2>
            <p className="mt-1 text-sm text-muted">{t("ob.lang.subtitle")}</p>
            <div className="mt-4 space-y-3" role="radiogroup" aria-label={t("ob.lang.title")}>
              {LANGS.map((l) => {
                const active = lang === l.code;
                return (
                  <button
                    key={l.code}
                    type="button"
                    role="radio"
                    aria-checked={active}
                    onClick={() => setLang(l.code)}
                    className={cn(
                      "flex w-full items-center gap-4 rounded-3xl border-2 p-4 text-left transition active:scale-[0.99]",
                      active
                        ? "border-brand bg-brand/10 shadow-glow"
                        : "border-line bg-surface",
                    )}
                  >
                    <span className="flex-1">
                      <span className="block text-xl font-bold">{l.native}</span>
                      <span className="block text-sm text-muted">{l.sub}</span>
                    </span>
                    <span
                      className={cn(
                        "flex h-7 w-7 items-center justify-center rounded-full border-2",
                        active ? "border-brand bg-brand text-white" : "border-line",
                      )}
                    >
                      {active && <Check className="h-4 w-4" strokeWidth={3} />}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {step === 1 && (
          <div className="animate-rise">
            <h1 className="text-3xl font-bold">{t("ob.welcome.title")}</h1>
            <p className="mt-2 text-muted">{t("ob.welcome.subtitle")}</p>
            <div className="mt-6 space-y-3">
              {features.map((f) => (
                <Card key={f.title} className="flex items-center gap-4 p-4">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-brand to-brand2 text-white shadow-glow">
                    <f.icon className="h-6 w-6" />
                  </span>
                  <span>
                    <span className="block font-bold">{t(f.title)}</span>
                    <span className="block text-sm text-muted">{t(f.desc)}</span>
                  </span>
                </Card>
              ))}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="animate-rise">
            <h1 className="text-2xl font-bold">{t("ob.perm.title")}</h1>
            <p className="mt-2 text-sm leading-relaxed text-muted">{t("ob.perm.subtitle")}</p>
            <div className="mt-5 space-y-3">
              {perms.map((p) => (
                <Card key={p.title} className="flex gap-3 p-4">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-brand/15 text-brand">
                    <p.icon className="h-5 w-5" />
                  </span>
                  <span>
                    <span className="block font-bold">{t(p.title)}</span>
                    <span className="block text-sm leading-snug text-muted">{t(p.why)}</span>
                  </span>
                </Card>
              ))}
            </div>
            <p className="mt-4 rounded-2xl bg-surface2 p-3 text-sm text-muted">
              {t("ob.perm.note")}
            </p>
          </div>
        )}

        {step === 3 && (
          <div className="animate-rise">
            <h1 className="sr-only">{t("ob.pin.title")}</h1>
            <PinSetupFlow
              requireCurrent={false}
              doneLabel={t("ob.finish")}
              onDone={completeOnboarding}
            />
          </div>
        )}
      </div>

      {step < 3 && (
        <div className="px-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-2">
          <Button full size="lg" onClick={() => setStep((s) => s + 1)}>
            {t("common.continue")}
          </Button>
        </div>
      )}
    </div>
  );
}
