import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { dictionaries, type TKey } from "@/i18n/translations";
import { bridge } from "@/services/nativeBridge";
import {
  clearState,
  defaultState,
  loadState,
  saveState,
} from "@/services/storage";
import {
  createSecretRecord,
  generateRecoveryCode,
  lockoutDuration,
  normalizeRecoveryCode,
  verifySecret,
} from "@/services/pinSecurity";
import type {
  AppInfo,
  Lang,
  LockMethod,
  PersistedState,
  PinLength,
  ThemeMode,
} from "@/types";

type Vars = Record<string, string | number>;
export type AttemptKind = "pin" | "pattern" | "recovery";

export interface AttemptResult {
  ok: boolean;
  locked: boolean;
  remainingMs: number;
  error?: "crypto";
}

type AppsStatus = "loading" | "ready" | "error";

interface AppCtx {
  state: PersistedState;
  lang: Lang;
  resolvedTheme: "dark" | "light";
  t: (key: TKey, vars?: Vars) => string;
  fmt: (n: number) => string;

  apps: AppInfo[];
  hiddenCount: number;
  appsStatus: AppsStatus;
  lockedCount: number;
  reloadApps: () => void;

  setLang: (l: Lang) => void;
  setTheme: (t: ThemeMode) => void;
  setBiometric: (on: boolean) => void;
  setLockMethod: (m: LockMethod) => void;
  setAccessibilityConsent: (on: boolean) => void;
  toggleLocked: (app: AppInfo) => void;
  completeOnboarding: () => void;

  savePin: (pin: string, length: PinLength) => Promise<string>;
  savePattern: (sequence: string) => Promise<void>;
  regenerateRecovery: () => Promise<string>;
  attempt: (kind: AttemptKind, secret: string) => Promise<AttemptResult>;
  resetAll: () => void;

  toast: string | null;
  showToast: (message: string) => void;
}

const Ctx = createContext<AppCtx | null>(null);

function interpolate(template: string, vars?: Vars): string {
  if (!vars) return template;
  return template.replace(/\{(\w+)\}/g, (m, k: string) =>
    k in vars ? String(vars[k]) : m,
  );
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PersistedState>(() => loadState());
  const stateRef = useRef(state);
  const [systemDark, setSystemDark] = useState(() =>
    typeof window !== "undefined" && typeof window.matchMedia === "function"
      ? window.matchMedia("(prefers-color-scheme: dark)").matches
      : true,
  );
  const [apps, setApps] = useState<AppInfo[]>([]);
  const [hiddenCount, setHiddenCount] = useState(0);
  const [appsStatus, setAppsStatus] = useState<AppsStatus>("loading");
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<number | undefined>(undefined);

  /** Single write path: keeps the ref and React state in sync immediately. */
  const update = useCallback((patch: Partial<PersistedState>) => {
    stateRef.current = { ...stateRef.current, ...patch };
    setState(stateRef.current);
  }, []);

  // Persist locally on every change and sync to native engine.
  useEffect(() => {
    saveState(state);
    void bridge.syncLockedApps(state.lockedApps);
    void bridge.syncSecurity({
      pin: state.pin,
      pattern: state.pattern,
      recovery: state.recovery,
      biometricEnabled: state.biometricEnabled,
      lockMethod: state.lockMethod,
      pinLength: state.pinLength,
      failedAttempts: state.failedAttempts,
      lockoutUntil: state.lockoutUntil,
    });
  }, [state]);

  // Follow the system theme when "system" is selected.
  useEffect(() => {
    if (typeof window.matchMedia !== "function") return;
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = (e: MediaQueryListEvent) => setSystemDark(e.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  const resolvedTheme: "dark" | "light" =
    state.theme === "system" ? (systemDark ? "dark" : "light") : state.theme;

  useEffect(() => {
    const root = document.documentElement;
    root.dataset.theme = resolvedTheme;
    root.lang = state.lang;
    const meta = document.querySelector('meta[name="theme-color"]');
    meta?.setAttribute("content", resolvedTheme === "dark" ? "#060b1c" : "#eef3ff");
  }, [resolvedTheme, state.lang]);

  // ---- installed apps (demo data in preview, native later) ----
  const loadApps = useCallback(async () => {
    setAppsStatus("loading");
    try {
      const result = await bridge.getInstalledApps();
      setApps(result.apps);
      setHiddenCount(result.hiddenCount);
      setAppsStatus("ready");
    } catch {
      setAppsStatus("error");
    }
  }, []);

  useEffect(() => {
    void loadApps();
  }, [loadApps]);

  const reloadApps = useCallback(() => {
    void loadApps();
  }, [loadApps]);

  // ---- i18n ----
  const t = useCallback(
    (key: TKey, vars?: Vars) => interpolate(dictionaries[state.lang][key] ?? key, vars),
    [state.lang],
  );

  const numberFormatter = useMemo(() => {
    try {
      return new Intl.NumberFormat(state.lang === "bn" ? "bn-BD" : "en-US");
    } catch {
      return null;
    }
  }, [state.lang]);
  const fmt = useCallback(
    (n: number) => (numberFormatter ? numberFormatter.format(n) : String(n)),
    [numberFormatter],
  );

  // ---- toast ----
  const showToast = useCallback((message: string) => {
    setToast(message);
    window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 2600);
  }, []);
  useEffect(() => () => window.clearTimeout(toastTimer.current), []);

  // ---- simple setters ----
  const setLang = useCallback((lang: Lang) => update({ lang }), [update]);
  const setTheme = useCallback((theme: ThemeMode) => update({ theme }), [update]);
  const setBiometric = useCallback(
    (biometricEnabled: boolean) => update({ biometricEnabled }),
    [update],
  );
  const setLockMethod = useCallback(
    (lockMethod: LockMethod) => {
      if (lockMethod === "pattern" && !stateRef.current.pattern) return;
      update({ lockMethod });
    },
    [update],
  );
  const setAccessibilityConsent = useCallback(
    (accessibilityConsent: boolean) => update({ accessibilityConsent }),
    [update],
  );
  const completeOnboarding = useCallback(() => {
    if (stateRef.current.pin) update({ onboarded: true });
  }, [update]);

  const toggleLocked = useCallback(
    (app: AppInfo) => {
      const s = stateRef.current;
      const isLocked = s.lockedApps.includes(app.packageName);
      if (isLocked) {
        update({ lockedApps: s.lockedApps.filter((p) => p !== app.packageName) });
        showToast(t("apps.removed", { name: app.label }));
      } else {
        update({
          lockedApps: [...s.lockedApps, app.packageName],
          recentApps: [
            app.packageName,
            ...s.recentApps.filter((p) => p !== app.packageName),
          ].slice(0, 6),
        });
        showToast(t("apps.added", { name: app.label }));
      }
    },
    [update, t, showToast],
  );

  // ---- secrets ----
  const savePin = useCallback(
    async (pin: string, length: PinLength) => {
      const pinRecord = await createSecretRecord(pin);
      const code = generateRecoveryCode();
      const recoveryRecord = await createSecretRecord(normalizeRecoveryCode(code));
      update({
        pin: pinRecord,
        pinLength: length,
        recovery: recoveryRecord,
        failedAttempts: 0,
        lockoutUntil: 0,
      });
      return code;
    },
    [update],
  );

  const savePattern = useCallback(
    async (sequence: string) => {
      const record = await createSecretRecord(sequence);
      update({ pattern: record });
    },
    [update],
  );

  const regenerateRecovery = useCallback(async () => {
    const code = generateRecoveryCode();
    const record = await createSecretRecord(normalizeRecoveryCode(code));
    update({ recovery: record });
    return code;
  }, [update]);

  const attempt = useCallback(
    async (kind: AttemptKind, secret: string): Promise<AttemptResult> => {
      const s = stateRef.current;
      const now = Date.now();
      if (s.lockoutUntil > now) {
        return { ok: false, locked: true, remainingMs: s.lockoutUntil - now };
      }
      const record =
        kind === "pin" ? s.pin : kind === "pattern" ? s.pattern : s.recovery;
      if (!record) return { ok: false, locked: false, remainingMs: 0 };

      let ok = false;
      try {
        ok = await verifySecret(
          kind === "recovery" ? normalizeRecoveryCode(secret) : secret,
          record,
        );
      } catch {
        return { ok: false, locked: false, remainingMs: 0, error: "crypto" };
      }

      if (ok) {
        update({ failedAttempts: 0, lockoutUntil: 0 });
        return { ok: true, locked: false, remainingMs: 0 };
      }
      const failed = stateRef.current.failedAttempts + 1;
      const duration = lockoutDuration(failed);
      update({
        failedAttempts: failed,
        lockoutUntil: duration > 0 ? Date.now() + duration : 0,
      });
      return { ok: false, locked: duration > 0, remainingMs: duration };
    },
    [update],
  );

  const resetAll = useCallback(() => {
    clearState();
    const fresh = defaultState();
    // Keep the user's language and theme choice for a friendly restart.
    update({ ...fresh, lang: stateRef.current.lang, theme: stateRef.current.theme });
  }, [update]);

  const lockedCount = useMemo(() => {
    const set = new Set(state.lockedApps);
    return apps.filter((a) => set.has(a.packageName)).length;
  }, [apps, state.lockedApps]);

  const value: AppCtx = {
    state,
    lang: state.lang,
    resolvedTheme,
    t,
    fmt,
    apps,
    hiddenCount,
    appsStatus,
    lockedCount,
    reloadApps,
    setLang,
    setTheme,
    setBiometric,
    setLockMethod,
    setAccessibilityConsent,
    toggleLocked,
    completeOnboarding,
    savePin,
    savePattern,
    regenerateRecovery,
    attempt,
    resetAll,
    toast,
    showToast,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): AppCtx {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}

/** Remaining lockout time in ms; re-renders every 500 ms while locked out. */
export function useLockoutRemaining(): number {
  const { state } = useApp();
  const [, setTick] = useState(0);
  useEffect(() => {
    if (state.lockoutUntil <= Date.now()) return;
    const id = window.setInterval(() => {
      setTick((n) => n + 1);
      if (Date.now() >= state.lockoutUntil) window.clearInterval(id);
    }, 500);
    return () => window.clearInterval(id);
  }, [state.lockoutUntil]);
  return Math.max(0, state.lockoutUntil - Date.now());
}

export function formatDuration(
  ms: number,
  t: (key: TKey, vars?: Vars) => string,
  fmt: (n: number) => string,
): string {
  const sec = Math.max(1, Math.ceil(ms / 1000));
  if (sec <= 60) return t("time.sec", { n: fmt(sec) });
  return t("time.min", { n: fmt(Math.ceil(sec / 60)) });
}
