package com.example.manager

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Provides hardware-backed AES-256-GCM encryption/decryption using the Android KeyStore.
 * Ensures stored PIN/pattern hashes, salts, and recovery tokens are encrypted at rest.
 */
object KeystoreHelper {
    private const val KEY_PROVIDER = "AndroidKeyStore"
    private const val KEY_ALIAS = "LockAppBDMasterKey"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_TAG_LENGTH = 128
    private const val PREFIX = "ENC_V1:"

    @Synchronized
    private fun getOrCreateSecretKey(): SecretKey? {
        return try {
            val keyStore = KeyStore.getInstance(KEY_PROVIDER)
            keyStore.load(null)
            if (keyStore.containsAlias(KEY_ALIAS)) {
                val entry = keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
                if (entry != null) return entry.secretKey
            }
            val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEY_PROVIDER)
            val spec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
            keyGenerator.init(spec)
            keyGenerator.generateKey()
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Encrypts a sensitive string using hardware-backed AES-256-GCM.
     * Returns a formatted ciphertext string: "ENC_V1:Base64(IV):Base64(Ciphertext)"
     */
    fun encrypt(plaintext: String): String {
        return try {
            val key = getOrCreateSecretKey() ?: return "RAW:$plaintext"
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val iv = cipher.iv
            val encryptedBytes = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
            val ivB64 = SafeBase64.encode(iv)
            val encB64 = SafeBase64.encode(encryptedBytes)
            "$PREFIX$ivB64:$encB64"
        } catch (_: Throwable) {
            "RAW:$plaintext"
        }
    }

    /**
     * Decrypts ciphertext previously produced by [encrypt], with automatic fallback
     * for legacy or mock-environment values.
     */
    fun decrypt(cipherText: String?): String? {
        if (cipherText.isNullOrEmpty()) return null
        if (cipherText.startsWith("RAW:")) {
            return cipherText.substring(4)
        }
        if (!cipherText.startsWith(PREFIX)) {
            // Legacy plaintext / unencrypted hash
            return cipherText
        }
        return try {
            val payload = cipherText.substring(PREFIX.length)
            val colonIdx = payload.indexOf(':')
            if (colonIdx == -1) return null
            val iv = SafeBase64.decode(payload.substring(0, colonIdx))
            val enc = SafeBase64.decode(payload.substring(colonIdx + 1))
            val key = getOrCreateSecretKey() ?: return null
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
            cipher.init(Cipher.DECRYPT_MODE, key, spec)
            val decrypted = cipher.doFinal(enc)
            String(decrypted, Charsets.UTF_8)
        } catch (_: Throwable) {
            null
        }
    }
}
