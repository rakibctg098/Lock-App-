package com.example.manager

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.Locale

class AppsManager(private val context: Context) {

    private val pm: PackageManager = context.packageManager

    companion object {
        // Critical system packages that must NEVER be locked or presented in the lock list
        val EXCLUDED_PACKAGES = setOf(
            "com.example",
            "com.mohammadrakib.lockappbd",
            "android",
            "com.android.systemui",
            "com.android.settings",
            "com.google.android.settings",
            "com.android.dialer",
            "com.google.android.dialer",
            "com.samsung.android.dialer",
            "com.android.phone",
            "com.android.server.telecom",
            "com.android.emergency",
            "com.google.android.apps.safetyhub",
            "com.google.android.packageinstaller",
            "com.android.packageinstaller",
            "com.google.android.permissioncontroller",
            "com.android.permissioncontroller"
        )
    }

    data class AppItem(
        val packageName: String,
        val label: String,
        val category: String,
        val hue: Int,
        val iconDataUri: String?
    )

    fun isExcluded(packageName: String): Boolean {
        if (packageName.isBlank()) return true
        if (packageName == context.packageName) return true
        if (EXCLUDED_PACKAGES.contains(packageName)) return true
        if (packageName.startsWith("com.android.systemui")) return true
        if (packageName.contains("settings") || packageName.contains("dialer") || packageName.contains("emergency")) {
            return true
        }
        return false
    }

    fun getAppLabel(packageName: String): String {
        return try {
            val appInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(packageName, 0)
            }
            pm.getApplicationLabel(appInfo).toString()
        } catch (_: Exception) {
            packageName
        }
    }

    fun getAppIcon(packageName: String): Drawable? {
        return try {
            pm.getApplicationIcon(packageName)
        } catch (_: Exception) {
            null
        }
    }

    private fun drawableToBase64Uri(drawable: Drawable): String? {
        return try {
            val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth.coerceIn(48, 128) else 96
            val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight.coerceIn(48, 128) else 96
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)

            val scaled = if (bmp.width > 96 || bmp.height > 96) {
                Bitmap.createScaledBitmap(bmp, 96, 96, true)
            } else {
                bmp
            }
            val stream = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.PNG, 90, stream)
            val bytes = stream.toByteArray()
            "data:image/png;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (_: Exception) {
            null
        }
    }

    private fun detectCategory(label: String, packageName: String, appCategory: Int): String {
        val lowerPkg = packageName.lowercase(Locale.ROOT)
        val lowerLabel = label.lowercase(Locale.ROOT)

        if (lowerPkg.contains("whatsapp") || lowerPkg.contains("telegram") || lowerPkg.contains("messenger") ||
            lowerPkg.contains("discord") || lowerPkg.contains("viber") || lowerPkg.contains("imo") ||
            lowerLabel.contains("message") || lowerLabel.contains("chat")
        ) {
            return "messaging"
        }

        if (lowerPkg.contains("facebook") || lowerPkg.contains("instagram") || lowerPkg.contains("twitter") ||
            lowerPkg.contains("tiktok") || lowerPkg.contains("snapchat") || lowerPkg.contains("linkedin") ||
            lowerPkg.contains("reddit")
        ) {
            return "social"
        }

        if (lowerPkg.contains("bkash") || lowerPkg.contains("nagad") || lowerPkg.contains("rocket") ||
            lowerPkg.contains("bank") || lowerPkg.contains("pay") || lowerPkg.contains("wallet") ||
            lowerPkg.contains("finance") || lowerPkg.contains("binance")
        ) {
            return "finance"
        }

        if (lowerPkg.contains("youtube") || lowerPkg.contains("spotify") || lowerPkg.contains("netflix") ||
            lowerPkg.contains("music") || lowerPkg.contains("video") || lowerPkg.contains("camera") ||
            lowerPkg.contains("gallery") || lowerPkg.contains("photo")
        ) {
            return "media"
        }

        if (lowerPkg.contains("daraz") || lowerPkg.contains("amazon") || lowerPkg.contains("shop") ||
            lowerPkg.contains("ecommerce") || lowerPkg.contains("alibaba")
        ) {
            return "shopping"
        }

        if (lowerPkg.contains("game") || (lowerPkg.contains("play") && appCategory == ApplicationInfo.CATEGORY_GAME)) {
            return "games"
        }

        if (lowerPkg.contains("docs") || lowerPkg.contains("excel") || lowerPkg.contains("office") ||
            lowerPkg.contains("notes") || lowerPkg.contains("calendar") || lowerPkg.contains("drive") ||
            lowerPkg.contains("mail") || lowerPkg.contains("gmail")
        ) {
            return "productivity"
        }

        return "tools"
    }

    fun getInstalledLaunchableAppsJson(): String {
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos: List<ResolveInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }

        val appsList = ArrayList<AppItem>()
        var hiddenCount = 0
        val seenPackages = HashSet<String>()

        for (resolveInfo in resolveInfos) {
            val packageName = resolveInfo.activityInfo.packageName
            if (seenPackages.contains(packageName)) continue
            seenPackages.add(packageName)

            if (isExcluded(packageName)) {
                hiddenCount++
                continue
            }

            val label = resolveInfo.loadLabel(pm).toString()
            val drawable = try {
                resolveInfo.loadIcon(pm)
            } catch (_: Exception) {
                null
            }
            val iconUri = drawable?.let { drawableToBase64Uri(it) }
            val hue = (Math.floorMod(packageName.hashCode(), 360) + 360) % 360
            val category = detectCategory(
                label,
                packageName,
                resolveInfo.activityInfo.applicationInfo?.category ?: ApplicationInfo.CATEGORY_UNDEFINED
            )

            appsList.add(
                AppItem(
                    packageName = packageName,
                    label = label,
                    category = category,
                    hue = hue,
                    iconDataUri = iconUri
                )
            )
        }

        appsList.sortBy { it.label.lowercase(Locale.ROOT) }

        val rootJson = JSONObject()
        val appsArray = JSONArray()
        for (app in appsList) {
            val item = JSONObject().apply {
                put("packageName", app.packageName)
                put("label", app.label)
                put("category", app.category)
                put("hue", app.hue)
                if (app.iconDataUri != null) {
                    put("iconDataUri", app.iconDataUri)
                }
            }
            appsArray.put(item)
        }
        rootJson.put("apps", appsArray)
        rootJson.put("hiddenCount", hiddenCount)
        return rootJson.toString()
    }
}
