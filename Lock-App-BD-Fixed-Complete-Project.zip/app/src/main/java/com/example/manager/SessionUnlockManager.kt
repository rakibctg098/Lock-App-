package com.example.manager

import android.os.SystemClock
import java.util.concurrent.ConcurrentHashMap

/**
 * Tracks applications temporarily unlocked during the active user session.
 * Ensures the user is not prompted repeatedly while actively using an app.
 * Resets immediately on screen off.
 */
object SessionUnlockManager {

    // Package name -> timestamp when unlocked
    private val unlockedApps = ConcurrentHashMap<String, Long>()

    // Inactivity timeout: 15 minutes max per session unlock
    const val SESSION_TIMEOUT_MS = 15 * 60 * 1000L

    var timeProvider: () -> Long = {
        try {
            SystemClock.elapsedRealtime()
        } catch (_: Throwable) {
            System.currentTimeMillis()
        }
    }

    fun unlockApp(packageName: String) {
        if (packageName.isNotBlank()) {
            unlockedApps[packageName] = timeProvider()
        }
    }

    fun isAppUnlocked(packageName: String): Boolean {
        val unlockTime = unlockedApps[packageName] ?: return false
        val now = timeProvider()
        if (now - unlockTime > SESSION_TIMEOUT_MS) {
            unlockedApps.remove(packageName)
            return false
        }
        return true
    }

    fun lockApp(packageName: String) {
        unlockedApps.remove(packageName)
    }

    fun clearAll() {
        unlockedApps.clear()
    }
}
