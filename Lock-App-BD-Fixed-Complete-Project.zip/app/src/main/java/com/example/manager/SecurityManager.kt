package com.example.manager

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class SecurityManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("lockapp_secure_prefs", Context.MODE_PRIVATE)

    var timeProvider: () -> Long = {
        try {
            SystemClock.elapsedRealtime()
        } catch (_: Throwable) {
            System.currentTimeMillis()
        }
    }

    companion object {
        private const val KEY_LOCKED_APPS = "locked_apps"
        private const val KEY_PIN_HASH = "pin_hash"
        private const val KEY_PIN_SALT = "pin_salt"
        private const val KEY_PIN_ITER = "pin_iter"
        private const val KEY_PIN_LENGTH = "pin_length"

        private const val KEY_PATTERN_HASH = "pattern_hash"
        private const val KEY_PATTERN_SALT = "pattern_salt"
        private const val KEY_PATTERN_ITER = "pattern_iter"

        private const val KEY_RECOVERY_HASH = "recovery_hash"
        private const val KEY_RECOVERY_SALT = "recovery_salt"
        private const val KEY_RECOVERY_ITER = "recovery_iter"

        private const val KEY_LOCK_METHOD = "lock_method"
        private const val KEY_BIO_ENABLED = "biometric_enabled"

        private const val KEY_FAILED_ATTEMPTS = "failed_attempts"
        private const val KEY_LOCKOUT_UNTIL = "lockout_until"

        @Volatile
        private var instance: SecurityManager? = null

        fun getInstance(context: Context): SecurityManager =
            instance ?: synchronized(this) {
                instance ?: SecurityManager(context.applicationContext).also { instance = it }
            }
    }

    // --- Locked Apps ---

    fun getLockedApps(): Set<String> {
        val rawSet = prefs.getStringSet(KEY_LOCKED_APPS, emptySet()) ?: emptySet()
        return HashSet(rawSet)
    }

    fun setLockedApps(packages: Set<String>) {
        val safeSet = packages.filter { it.isNotBlank() && !AppsManager.EXCLUDED_PACKAGES.contains(it) }.toSet()
        prefs.edit().putStringSet(KEY_LOCKED_APPS, HashSet(safeSet)).apply()
    }

    fun isAppLocked(packageName: String): Boolean {
        if (packageName.isBlank() || AppsManager.EXCLUDED_PACKAGES.contains(packageName)) return false
        return getLockedApps().contains(packageName)
    }

    fun toggleAppLocked(packageName: String): Boolean {
        if (packageName.isBlank() || AppsManager.EXCLUDED_PACKAGES.contains(packageName)) return false
        val current = getLockedApps().toMutableSet()
        val newState: Boolean
        if (current.contains(packageName)) {
            current.remove(packageName)
            newState = false
        } else {
            current.add(packageName)
            newState = true
        }
        setLockedApps(current)
        return newState
    }

    // --- Config & Settings ---

    fun getLockMethod(): String = prefs.getString(KEY_LOCK_METHOD, "pin") ?: "pin"

    fun setLockMethod(method: String) {
        val valid = if (method == "pattern") "pattern" else "pin"
        prefs.edit().putString(KEY_LOCK_METHOD, valid).apply()
    }

    fun isBiometricEnabled(): Boolean = prefs.getBoolean(KEY_BIO_ENABLED, false)

    fun setBiometricEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BIO_ENABLED, enabled).apply()
    }

    fun getPinLength(): Int = prefs.getInt(KEY_PIN_LENGTH, 4)

    fun hasPin(): Boolean = prefs.contains(KEY_PIN_HASH)

    fun hasPattern(): Boolean = prefs.contains(KEY_PATTERN_HASH)

    // --- Sync from React/WebView ---

    fun syncLockedAppsFromJson(jsonString: String) {
        try {
            val array = JSONArray(jsonString)
            val set = HashSet<String>()
            for (i in 0 until array.length()) {
                val pkg = array.optString(i, "")
                if (pkg.isNotBlank() && !AppsManager.EXCLUDED_PACKAGES.contains(pkg)) {
                    set.add(pkg)
                }
            }
            setLockedApps(set)
        } catch (_: Exception) {}
    }

    fun syncSecurityFromJson(jsonString: String) {
        try {
            val obj = JSONObject(jsonString)
            val editor = prefs.edit()

            if (obj.has("pin") && !obj.isNull("pin")) {
                val pinObj = obj.getJSONObject("pin")
                val hash = pinObj.getString("hash")
                val salt = pinObj.getString("salt")
                val iter = pinObj.optInt("iterations", 210000)
                editor.putString(KEY_PIN_HASH, KeystoreHelper.encrypt(hash))
                editor.putString(KEY_PIN_SALT, KeystoreHelper.encrypt(salt))
                editor.putInt(KEY_PIN_ITER, iter)
            }

            if (obj.has("pattern") && !obj.isNull("pattern")) {
                val patObj = obj.getJSONObject("pattern")
                val hash = patObj.getString("hash")
                val salt = patObj.getString("salt")
                val iter = patObj.optInt("iterations", 210000)
                editor.putString(KEY_PATTERN_HASH, KeystoreHelper.encrypt(hash))
                editor.putString(KEY_PATTERN_SALT, KeystoreHelper.encrypt(salt))
                editor.putInt(KEY_PATTERN_ITER, iter)
            }

            if (obj.has("recovery") && !obj.isNull("recovery")) {
                val recObj = obj.getJSONObject("recovery")
                val hash = recObj.getString("hash")
                val salt = recObj.getString("salt")
                val iter = recObj.optInt("iterations", 210000)
                editor.putString(KEY_RECOVERY_HASH, KeystoreHelper.encrypt(hash))
                editor.putString(KEY_RECOVERY_SALT, KeystoreHelper.encrypt(salt))
                editor.putInt(KEY_RECOVERY_ITER, iter)
            }

            if (obj.has("lockMethod")) {
                val method = obj.getString("lockMethod")
                editor.putString(KEY_LOCK_METHOD, if (method == "pattern") "pattern" else "pin")
            }

            if (obj.has("biometricEnabled")) {
                editor.putBoolean(KEY_BIO_ENABLED, obj.getBoolean("biometricEnabled"))
            }

            if (obj.has("pinLength")) {
                val len = obj.getInt("pinLength")
                editor.putInt(KEY_PIN_LENGTH, if (len == 6) 6 else 4)
            }

            editor.apply()
        } catch (_: Exception) {}
    }

    // --- PBKDF2 Verification ---

    private fun deriveKey(secret: String, saltBase64: String, iterations: Int): ByteArray {
        val salt = SafeBase64.decode(saltBase64)
        val spec = PBEKeySpec(secret.toCharArray(), salt, iterations, 256)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return factory.generateSecret(spec).encoded
    }

    fun verifyPin(pin: String): Boolean {
        if (pin.isBlank() || !pin.all { it.isDigit() }) return false
        if (isLockedOut()) return false

        val storedHashEnc = prefs.getString(KEY_PIN_HASH, null) ?: return false
        val storedSaltEnc = prefs.getString(KEY_PIN_SALT, null) ?: return false
        val storedHashB64 = KeystoreHelper.decrypt(storedHashEnc) ?: return false
        val storedSaltB64 = KeystoreHelper.decrypt(storedSaltEnc) ?: return false
        val iterations = prefs.getInt(KEY_PIN_ITER, 210000)

        return try {
            val targetHash = SafeBase64.decode(storedHashB64)
            val computedHash = deriveKey(pin, storedSaltB64, iterations)
            val valid = MessageDigest.isEqual(computedHash, targetHash)
            if (valid) {
                resetLockout()
            } else {
                recordFailure()
            }
            valid
        } catch (_: Exception) {
            recordFailure()
            false
        }
    }

    fun verifyPattern(pattern: String): Boolean {
        if (pattern.length < 4 || !pattern.all { it in '0'..'8' }) return false
        if (isLockedOut()) return false

        val storedHashEnc = prefs.getString(KEY_PATTERN_HASH, null) ?: return false
        val storedSaltEnc = prefs.getString(KEY_PATTERN_SALT, null) ?: return false
        val storedHashB64 = KeystoreHelper.decrypt(storedHashEnc) ?: return false
        val storedSaltB64 = KeystoreHelper.decrypt(storedSaltEnc) ?: return false
        val iterations = prefs.getInt(KEY_PATTERN_ITER, 210000)

        return try {
            val targetHash = SafeBase64.decode(storedHashB64)
            val computedHash = deriveKey(pattern, storedSaltB64, iterations)
            val valid = MessageDigest.isEqual(computedHash, targetHash)
            if (valid) {
                resetLockout()
            } else {
                recordFailure()
            }
            valid
        } catch (_: Exception) {
            recordFailure()
            false
        }
    }

    fun verifyRecoveryCode(rawCode: String): Boolean {
        val normalized = rawCode.uppercase().replace(Regex("[^A-Z0-9]"), "")
        if (normalized.length < 8) return false
        if (isLockedOut()) return false

        val storedHashEnc = prefs.getString(KEY_RECOVERY_HASH, null) ?: return false
        val storedSaltEnc = prefs.getString(KEY_RECOVERY_SALT, null) ?: return false
        val storedHashB64 = KeystoreHelper.decrypt(storedHashEnc) ?: return false
        val storedSaltB64 = KeystoreHelper.decrypt(storedSaltEnc) ?: return false
        val iterations = prefs.getInt(KEY_RECOVERY_ITER, 210000)

        return try {
            val targetHash = SafeBase64.decode(storedHashB64)
            val computedHash = deriveKey(normalized, storedSaltB64, iterations)
            val valid = MessageDigest.isEqual(computedHash, targetHash)
            if (valid) {
                resetLockout()
            } else {
                recordFailure()
            }
            valid
        } catch (_: Exception) {
            recordFailure()
            false
        }
    }

    // --- Lockout Logic (Monotonic Clock) ---

    fun isLockedOut(): Boolean {
        val lockoutUntil = prefs.getLong(KEY_LOCKOUT_UNTIL, 0L)
        return timeProvider() < lockoutUntil
    }

    fun getRemainingLockoutMs(): Long {
        val lockoutUntil = prefs.getLong(KEY_LOCKOUT_UNTIL, 0L)
        val remaining = lockoutUntil - timeProvider()
        return if (remaining > 0) remaining else 0L
    }

    private fun recordFailure() {
        val currentFails = prefs.getInt(KEY_FAILED_ATTEMPTS, 0) + 1
        val durationMs = when {
            currentFails < 5 -> 0L
            currentFails == 5 -> 30_000L
            currentFails == 6 -> 60_000L
            currentFails == 7 -> 300_000L
            else -> 900_000L
        }
        val lockoutUntil = if (durationMs > 0) timeProvider() + durationMs else 0L
        prefs.edit()
            .putInt(KEY_FAILED_ATTEMPTS, currentFails)
            .putLong(KEY_LOCKOUT_UNTIL, lockoutUntil)
            .apply()
    }

    fun resetLockout() {
        prefs.edit()
            .putInt(KEY_FAILED_ATTEMPTS, 0)
            .putLong(KEY_LOCKOUT_UNTIL, 0L)
            .apply()
    }
}
