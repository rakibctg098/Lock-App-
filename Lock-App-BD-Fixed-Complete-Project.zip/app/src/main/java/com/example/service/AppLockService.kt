package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.LockActivity
import com.example.MainActivity
import com.example.R
import com.example.manager.SecurityManager
import com.example.manager.SessionUnlockManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AppLockService : Service() {

    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.Default + serviceJob)

    private lateinit var securityManager: SecurityManager
    private lateinit var usageStatsManager: UsageStatsManager

    private var lastForegroundPackage: String? = null
    private var isCurrentlyLocking = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                // When screen turns off, re-lock all previously unlocked apps immediately
                SessionUnlockManager.clearAll()
            }
        }
    }

    companion object {
        const val CHANNEL_ID = "app_lock_protection_channel"
        const val NOTIFICATION_ID = 1001

        @Volatile
        var isRunning = false
            private set

        fun startService(context: Context) {
            val intent = Intent(context, AppLockService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, AppLockService::class.java)
            context.stopService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        securityManager = SecurityManager.getInstance(this)
        usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

        createNotificationChannel()
        startForegroundWithNotification()

        val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
        ContextCompat.registerReceiver(
            this,
            screenReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        isRunning = true
        startMonitoringLoop()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.app_lock_notification_channel),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.app_lock_notification_text)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun startForegroundWithNotification() {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_lock_notification_title))
            .setContentText(getString(R.string.app_lock_notification_text))
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startMonitoringLoop() {
        serviceScope.launch {
            while (isActive) {
                try {
                    if (!LockActivity.isLockScreenVisible) {
                        val currentForeground = getForegroundPackage()
                        if (currentForeground != null && currentForeground != packageName) {
                            handleForegroundChange(currentForeground)
                        }
                    }
                } catch (_: Exception) {}
                delay(300)
            }
        }
    }

    private fun isSystemOverlayOrKeyboard(pkg: String): Boolean {
        return pkg == "com.android.systemui" ||
                pkg.contains("keyboard") ||
                pkg.contains("inputmethod") ||
                pkg.contains("ime")
    }

    private fun handleForegroundChange(currentForeground: String) {
        val previous = lastForegroundPackage
        if (previous != null && previous != currentForeground && previous != packageName) {
            // Re-arm protection when user navigates away from protected app
            if (!isSystemOverlayOrKeyboard(currentForeground) && currentForeground != packageName) {
                SessionUnlockManager.lockApp(previous)
            }
        }
        lastForegroundPackage = currentForeground
        checkAndLockPackage(currentForeground)
    }

    private fun getForegroundPackage(): String? {
        val now = System.currentTimeMillis()
        try {
            val events = usageStatsManager.queryEvents(now - 2500, now)
            val event = UsageEvents.Event()
            var latestPackage: String? = null

            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                    latestPackage = event.packageName
                }
            }

            if (latestPackage == null) {
                val stats = usageStatsManager.queryUsageStats(
                    UsageStatsManager.INTERVAL_DAILY,
                    now - 10000,
                    now
                )
                latestPackage = stats?.maxByOrNull { it.lastTimeUsed }?.packageName
            }

            return latestPackage
        } catch (_: Exception) {
            return null
        }
    }

    private fun checkAndLockPackage(targetPackage: String) {
        if (targetPackage == packageName) return
        if (targetPackage == "com.android.systemui" || targetPackage == "com.android.settings") return
        if (LockActivity.isLockScreenVisible) return

        val isLocked = securityManager.isAppLocked(targetPackage)
        if (!isLocked) return

        val isSessionUnlocked = SessionUnlockManager.isAppUnlocked(targetPackage)
        if (isSessionUnlocked) return

        if (!isCurrentlyLocking) {
            isCurrentlyLocking = true

            val lockIntent = Intent(this, LockActivity::class.java).apply {
                putExtra(LockActivity.EXTRA_TARGET_PACKAGE, targetPackage)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            }
            try {
                startActivity(lockIntent)
            } catch (_: Exception) {}

            serviceScope.launch {
                delay(1000)
                isCurrentlyLocking = false
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isRunning = false
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Exception) {}
        serviceJob.cancel()
        super.onDestroy()
    }
}
