package com.example.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.example.LockActivity
import com.example.manager.SecurityManager
import com.example.manager.SessionUnlockManager

class AppLockAccessibilityService : AccessibilityService() {

    private lateinit var securityManager: SecurityManager
    private var lastPackage: String? = null

    override fun onCreate() {
        super.onCreate()
        securityManager = SecurityManager.getInstance(this)
    }

    private fun isSystemOverlayOrKeyboard(pkg: String): Boolean {
        return pkg == "com.android.systemui" ||
                pkg == "com.android.settings" ||
                pkg.contains("keyboard") ||
                pkg.contains("inputmethod") ||
                pkg.contains("ime")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkgName = event.packageName?.toString() ?: return

        if (pkgName == packageName) return

        val previous = lastPackage
        if (previous != null && previous != pkgName && previous != packageName) {
            if (!isSystemOverlayOrKeyboard(pkgName)) {
                SessionUnlockManager.lockApp(previous)
            }
        }
        lastPackage = pkgName

        if (LockActivity.isLockScreenVisible) return
        if (isSystemOverlayOrKeyboard(pkgName)) return

        val isLocked = securityManager.isAppLocked(pkgName)
        if (!isLocked) return

        if (SessionUnlockManager.isAppUnlocked(pkgName)) return

        val intent = Intent(this, LockActivity::class.java).apply {
            putExtra(LockActivity.EXTRA_TARGET_PACKAGE, pkgName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {}
    }

    override fun onInterrupt() {
        // Required method by AccessibilityService
    }
}
