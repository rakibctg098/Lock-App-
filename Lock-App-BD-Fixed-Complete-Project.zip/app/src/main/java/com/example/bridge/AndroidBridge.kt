package com.example.bridge

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.webkit.JavascriptInterface
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.LockActivity
import com.example.manager.AppsManager
import com.example.manager.PermissionHelper
import com.example.manager.SecurityManager
import com.example.service.AppLockService
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class AndroidBridge(
    private val activity: Activity,
    private val securityManager: SecurityManager,
    private val appsManager: AppsManager,
    private val permissionHelper: PermissionHelper
) {

    @JavascriptInterface
    fun getInstalledApps(): String {
        return appsManager.getInstalledLaunchableAppsJson()
    }

    @JavascriptInterface
    fun getPermissionStatuses(): String {
        return permissionHelper.getPermissionStatusesJson()
    }

    @JavascriptInterface
    fun requestPermission(id: String) {
        activity.runOnUiThread {
            when (id) {
                "usage" -> permissionHelper.openUsageStatsSettings(activity)
                "overlay" -> permissionHelper.openOverlaySettings(activity)
                "notif" -> permissionHelper.openNotificationSettings(activity)
                "acc" -> permissionHelper.openAccessibilitySettings(activity)
                "bio" -> {
                    // Test or check biometric
                    if (activity is FragmentActivity) {
                        authenticateBiometric()
                    }
                }
            }
        }
    }

    @JavascriptInterface
    fun syncLockedApps(json: String) {
        securityManager.syncLockedAppsFromJson(json)
        // If locked apps exist and usage permission is granted, ensure service is running
        if (securityManager.getLockedApps().isNotEmpty() && permissionHelper.hasUsageStatsPermission()) {
            AppLockService.startService(activity)
        }
    }

    @JavascriptInterface
    fun syncSecurity(json: String) {
        securityManager.syncSecurityFromJson(json)
    }

    @JavascriptInterface
    fun authenticateBiometric(): Boolean {
        if (activity !is FragmentActivity) return false
        if (!permissionHelper.hasBiometricCapability()) return false

        val latch = CountDownLatch(1)
        val success = AtomicBoolean(false)

        activity.runOnUiThread {
            try {
                val executor = ContextCompat.getMainExecutor(activity)
                val prompt = BiometricPrompt(
                    activity,
                    executor,
                    object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                            super.onAuthenticationSucceeded(result)
                            success.set(true)
                            latch.countDown()
                        }

                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                            super.onAuthenticationError(errorCode, errString)
                            success.set(false)
                            latch.countDown()
                        }

                        override fun onAuthenticationFailed() {
                            super.onAuthenticationFailed()
                            // Still waiting or failed
                        }
                    }
                )

                val promptInfo = BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Lock App BD")
                    .setSubtitle("Verify identity with fingerprint")
                    .setNegativeButtonText("Cancel")
                    .setAllowedAuthenticators(
                        BiometricManager.Authenticators.BIOMETRIC_STRONG or
                                BiometricManager.Authenticators.BIOMETRIC_WEAK
                    )
                    .build()

                prompt.authenticate(promptInfo)
            } catch (_: Exception) {
                latch.countDown()
            }
        }

        try {
            latch.await(30, TimeUnit.SECONDS)
        } catch (_: Exception) {}

        return success.get()
    }

    @JavascriptInterface
    fun openExternal(url: String): Boolean {
        return try {
            val uri = Uri.parse(url)
            val host = uri.host?.lowercase() ?: return false
            if (host == "t.me" || host == "chat.whatsapp.com") {
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                activity.startActivity(intent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun setServiceEnabled(enabled: Boolean) {
        if (enabled) {
            AppLockService.startService(activity)
        } else {
            AppLockService.stopService(activity)
        }
    }

    @JavascriptInterface
    fun isServiceRunning(): Boolean {
        return AppLockService.isRunning
    }

    @JavascriptInterface
    fun testLock(packageName: String) {
        val intent = Intent(activity, LockActivity::class.java).apply {
            putExtra(LockActivity.EXTRA_TARGET_PACKAGE, packageName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        activity.startActivity(intent)
    }
}
