package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.bridge.AndroidBridge
import com.example.manager.AppsManager
import com.example.manager.PermissionHelper
import com.example.manager.SecurityManager
import com.example.service.AppLockService

class MainActivity : FragmentActivity() {

    private lateinit var webView: WebView
    private lateinit var securityManager: SecurityManager
    private lateinit var appsManager: AppsManager
    private lateinit var permissionHelper: PermissionHelper

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Notification permission callback
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        securityManager = SecurityManager.getInstance(this)
        appsManager = AppsManager(this)
        permissionHelper = PermissionHelper(this)

        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#060b1c"))

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                cacheMode = WebSettings.LOAD_DEFAULT
                useWideViewPort = true
                loadWithOverviewMode = true
                displayZoomControls = false
                builtInZoomControls = false
            }

            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val url = request?.url?.toString() ?: return false
                    // The JavaScript bridge is exposed to this WebView. Never allow
                    // navigation to remote or otherwise untrusted origins.
                    return !url.startsWith("file:///android_asset/")
                }
            }

            // Expose the native bridge
            addJavascriptInterface(
                AndroidBridge(this@MainActivity, securityManager, appsManager, permissionHelper),
                "AndroidBridge"
            )

            loadUrl("file:///android_asset/index.html")
        }

        setContentView(webView)

        // Handle Back button navigation
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript("window.history.back();", null)
            }
        })

        // Request POST_NOTIFICATIONS permission on Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        // Auto-start lock service if usage stats permission is already present and locked apps exist
        if (permissionHelper.hasUsageStatsPermission() && securityManager.getLockedApps().isNotEmpty()) {
            AppLockService.startService(this)
        }
    }

    override fun onResume() {
        super.onResume()
        webView.evaluateJavascript(
            """
            if (typeof window !== 'undefined') {
                window.dispatchEvent(new Event('focus'));
            }
            """.trimIndent(),
            null
        )
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
