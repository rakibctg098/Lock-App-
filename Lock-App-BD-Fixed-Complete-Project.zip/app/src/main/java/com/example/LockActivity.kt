package com.example

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pattern
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.fragment.app.FragmentActivity
import com.example.manager.AppsManager
import com.example.manager.SecurityManager
import com.example.manager.SessionUnlockManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class LockActivity : FragmentActivity() {

    companion object {
        const val EXTRA_TARGET_PACKAGE = "extra_target_package"

        @Volatile
        var isLockScreenVisible = false
            private set
    }

    private lateinit var securityManager: SecurityManager
    private lateinit var appsManager: AppsManager
    private var targetPackage: String = ""

    override fun onResume() {
        super.onResume()
        isLockScreenVisible = true
    }

    override fun onPause() {
        isLockScreenVisible = false
        super.onPause()
    }

    override fun onDestroy() {
        isLockScreenVisible = false
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        isLockScreenVisible = true
        enableEdgeToEdge()

        securityManager = SecurityManager.getInstance(this)
        appsManager = AppsManager(this)

        targetPackage = intent.getStringExtra(EXTRA_TARGET_PACKAGE) ?: ""

        // If back is pressed, go directly to HOME so target app is not accessed
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                goToHomeScreen()
            }
        })

        val appLabel = if (targetPackage.isNotBlank()) appsManager.getAppLabel(targetPackage) else "Protected App"
        val appIconDrawable = if (targetPackage.isNotBlank()) appsManager.getAppIcon(targetPackage) else null

        setContent {
            LockScreenContent(
                appLabel = appLabel,
                appIconDrawable = appIconDrawable,
                securityManager = securityManager,
                onUnlockSuccess = {
                    if (targetPackage.isNotBlank()) {
                        SessionUnlockManager.unlockApp(targetPackage)
                    }
                    vibrateSuccess()
                    finish()
                },
                onCancel = {
                    goToHomeScreen()
                },
                onRequestBiometric = {
                    showBiometricPrompt {
                        if (targetPackage.isNotBlank()) {
                            SessionUnlockManager.unlockApp(targetPackage)
                        }
                        vibrateSuccess()
                        finish()
                    }
                }
            )
        }

        // Auto trigger biometric if enabled and available
        if (securityManager.isBiometricEnabled() && !securityManager.isLockedOut()) {
            showBiometricPrompt {
                if (targetPackage.isNotBlank()) {
                    SessionUnlockManager.unlockApp(targetPackage)
                }
                vibrateSuccess()
                finish()
            }
        }
    }

    private fun goToHomeScreen() {
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(homeIntent)
        finish()
    }

    private fun vibrateError() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(180, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.vibrate(180)
            }
        } catch (_: Exception) {}
    }

    private fun vibrateSuccess() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.vibrate(50)
            }
        } catch (_: Exception) {}
    }

    private fun showBiometricPrompt(onSuccess: () -> Unit) {
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                onSuccess()
            }
        })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Lock App BD")
            .setSubtitle("Fingerprint Authentication")
            .setNegativeButtonText("Use PIN / Pattern")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.BIOMETRIC_WEAK
            )
            .build()

        try {
            prompt.authenticate(promptInfo)
        } catch (_: Exception) {}
    }
}

@Composable
fun LockScreenContent(
    appLabel: String,
    appIconDrawable: Drawable?,
    securityManager: SecurityManager,
    onUnlockSuccess: () -> Unit,
    onCancel: () -> Unit,
    onRequestBiometric: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var activeMethod by remember { mutableStateOf(securityManager.getLockMethod()) }
    var enteredPin by remember { mutableStateOf("") }
    val pinLength = securityManager.getPinLength()

    var showRecoveryDialog by remember { mutableStateOf(false) }
    var recoveryInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    var lockoutRemainingMs by remember { mutableLongStateOf(securityManager.getRemainingLockoutMs()) }
    val shakeOffset = remember { Animatable(0f) }

    // Live countdown timer for lockout
    LaunchedEffect(lockoutRemainingMs) {
        if (lockoutRemainingMs > 0) {
            while (lockoutRemainingMs > 0) {
                delay(500)
                lockoutRemainingMs = securityManager.getRemainingLockoutMs()
            }
            errorMessage = ""
        }
    }

    fun triggerShake() {
        coroutineScope.launch {
            shakeOffset.snapTo(0f)
            shakeOffset.animateTo(24f, tween(50))
            shakeOffset.animateTo(-24f, tween(50))
            shakeOffset.animateTo(16f, tween(50))
            shakeOffset.animateTo(-16f, tween(50))
            shakeOffset.animateTo(0f, tween(50))
        }
    }

    fun verifyPinNow(pin: String) {
        if (lockoutRemainingMs > 0) return
        val valid = securityManager.verifyPin(pin)
        if (valid) {
            onUnlockSuccess()
        } else {
            enteredPin = ""
            val rem = securityManager.getRemainingLockoutMs()
            lockoutRemainingMs = rem
            if (rem > 0) {
                errorMessage = "Too many failed attempts. Wait ${rem / 1000}s"
            } else {
                errorMessage = "Incorrect PIN"
            }
            triggerShake()
        }
    }

    fun verifyPatternNow(patternStr: String) {
        if (lockoutRemainingMs > 0) return
        val valid = securityManager.verifyPattern(patternStr)
        if (valid) {
            onUnlockSuccess()
        } else {
            val rem = securityManager.getRemainingLockoutMs()
            lockoutRemainingMs = rem
            if (rem > 0) {
                errorMessage = "Too many failed attempts. Wait ${rem / 1000}s"
            } else {
                errorMessage = "Incorrect Pattern"
            }
            triggerShake()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF040A1E),
                        Color(0xFF0A1838),
                        Color(0xFF030712)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .padding(top = 48.dp, bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Cancel / Home Button top right
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Lock",
                        tint = Color(0xFF60A5FA),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Lock App BD",
                        color = Color(0xFF93C5FD),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                IconButton(
                    onClick = onCancel,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0x33FFFFFF))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cancel",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // App Icon & Label
            if (appIconDrawable != null) {
                val bitmap = remember(appIconDrawable) {
                    appIconDrawable.toBitmap(96, 96).asImageBitmap()
                }
                Image(
                    bitmap = bitmap,
                    contentDescription = appLabel,
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(18.dp))
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF2563EB), Color(0xFF4F46E5))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = appLabel,
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = if (activeMethod == "pattern") "Draw pattern to unlock" else "Enter PIN to unlock",
                color = Color(0xFF94A3B8),
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Lockout or Error Banner
            if (lockoutRemainingMs > 0) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x26EF4444))
                        .border(1.dp, Color(0x66EF4444), RoundedCornerShape(16.dp))
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Device locked. Wait ${lockoutRemainingMs / 1000} seconds",
                        color = Color(0xFFFCA5A5),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            } else if (errorMessage.isNotBlank()) {
                Text(
                    text = errorMessage,
                    color = Color(0xFFF87171),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Authentication Input (PIN Pad or Pattern Grid)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .offset { IntOffset(shakeOffset.value.roundToInt(), 0) },
                contentAlignment = Alignment.Center
            ) {
                if (activeMethod == "pattern") {
                    PatternGridView(
                        onPatternComplete = { patternSeq ->
                            verifyPatternNow(patternSeq)
                        }
                    )
                } else {
                    PinPadView(
                        length = pinLength,
                        currentInput = enteredPin,
                        onDigitClick = { digit ->
                            if (enteredPin.length < pinLength && lockoutRemainingMs <= 0) {
                                val next = enteredPin + digit
                                enteredPin = next
                                if (next.length == pinLength) {
                                    verifyPinNow(next)
                                }
                            }
                        },
                        onBackspace = {
                            if (enteredPin.isNotEmpty()) {
                                enteredPin = enteredPin.dropLast(1)
                            }
                        }
                    )
                }
            }

            // Bottom Actions (Biometric, Switch Method, Forgot PIN)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (securityManager.isBiometricEnabled()) {
                    IconButton(
                        onClick = onRequestBiometric,
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(Color(0x2238BDF8))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fingerprint,
                            contentDescription = "Fingerprint",
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                if (securityManager.hasPattern() && activeMethod == "pin") {
                    TextButton(onClick = {
                        activeMethod = "pattern"
                        errorMessage = ""
                    }) {
                        Icon(Icons.Default.Pattern, contentDescription = null, tint = Color(0xFF93C5FD))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Use Pattern", color = Color(0xFF93C5FD), fontSize = 13.sp)
                    }
                } else if (activeMethod == "pattern") {
                    TextButton(onClick = {
                        activeMethod = "pin"
                        errorMessage = ""
                    }) {
                        Icon(Icons.Default.Key, contentDescription = null, tint = Color(0xFF93C5FD))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Use PIN", color = Color(0xFF93C5FD), fontSize = 13.sp)
                    }
                }

                TextButton(onClick = { showRecoveryDialog = true }) {
                    Text("Forgot PIN?", color = Color(0xFF94A3B8), fontSize = 13.sp)
                }
            }
        }

        // Recovery Code Dialog
        if (showRecoveryDialog) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xCC000000)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color(0xFF0F172A))
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(24.dp))
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Reset with Recovery Code",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Enter the 16-character recovery code generated during setup.",
                            color = Color(0xFF94A3B8),
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = recoveryInput,
                            onValueChange = { recoveryInput = it.uppercase() },
                            placeholder = { Text("XXXX-XXXX-XXXX-XXXX", color = Color(0xFF64748B)) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF38BDF8),
                                unfocusedBorderColor = Color(0xFF475569)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = { showRecoveryDialog = false },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text("Cancel", color = Color.White)
                            }

                            Button(
                                onClick = {
                                    val valid = securityManager.verifyRecoveryCode(recoveryInput)
                                    if (valid) {
                                        showRecoveryDialog = false
                                        onUnlockSuccess()
                                    } else {
                                        errorMessage = "Invalid recovery code"
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text("Verify", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PinPadView(
    length: Int,
    currentInput: String,
    onDigitClick: (String) -> Unit,
    onBackspace: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // PIN Dots
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(bottom = 28.dp)
        ) {
            repeat(length) { index ->
                val isFilled = index < currentInput.length
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(
                            if (isFilled) Color(0xFF38BDF8) else Color(0x3394A3B8)
                        )
                        .border(
                            1.dp,
                            if (isFilled) Color(0xFF38BDF8) else Color(0x6694A3B8),
                            CircleShape
                        )
                )
            }
        }

        // Numeric Keypad
        val keys = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("", "0", "DEL")
        )

        for (row in keys) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                for (key in row) {
                    if (key.isEmpty()) {
                        Spacer(modifier = Modifier.size(68.dp))
                    } else if (key == "DEL") {
                        IconButton(
                            onClick = onBackspace,
                            modifier = Modifier
                                .size(68.dp)
                                .clip(CircleShape)
                                .background(Color(0x1AFFFFFF))
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Backspace,
                                contentDescription = "Delete",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .size(68.dp)
                                .clip(CircleShape)
                                .background(Color(0x1AFFFFFF))
                                .border(1.dp, Color(0x22FFFFFF), CircleShape)
                                .clickable { onDigitClick(key) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = key,
                                color = Color.White,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PatternGridView(
    onPatternComplete: (String) -> Unit
) {
    val selectedPoints = remember { mutableStateListOf<Int>() }

    BoxWithConstraints(
        modifier = Modifier
            .size(280.dp)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        selectedPoints.clear()
                        val pt = hitTestPoint(offset, size.width.toFloat())
                        if (pt != null) selectedPoints.add(pt)
                    },
                    onDrag = { change, _ ->
                        val pt = hitTestPoint(change.position, size.width.toFloat())
                        if (pt != null && !selectedPoints.contains(pt)) {
                            selectedPoints.add(pt)
                        }
                    },
                    onDragEnd = {
                        if (selectedPoints.size >= 4) {
                            onPatternComplete(selectedPoints.joinToString(""))
                        }
                        selectedPoints.clear()
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceEvenly,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            for (row in 0..2) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (col in 0..2) {
                        val index = row * 3 + col
                        val isSelected = selectedPoints.contains(index)
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) Color(0x3338BDF8) else Color(0x1AFFFFFF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) Color(0xFF38BDF8) else Color(0xFF64748B))
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun hitTestPoint(offset: Offset, canvasSize: Float): Int? {
    val step = canvasSize / 3f
    val col = (offset.x / step).toInt().coerceIn(0, 2)
    val row = (offset.y / step).toInt().coerceIn(0, 2)
    val centerX = col * step + step / 2f
    val centerY = row * step + step / 2f
    val distSq = (offset.x - centerX) * (offset.x - centerX) + (offset.y - centerY) * (offset.y - centerY)
    val radius = step * 0.4f
    return if (distSq <= radius * radius) {
        row * 3 + col
    } else {
        null
    }
}
