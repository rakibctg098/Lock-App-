package com.example

import com.example.manager.AppsManager
import com.example.manager.KeystoreHelper
import com.example.manager.SafeBase64
import com.example.manager.SessionUnlockManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.security.MessageDigest
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class ExampleUnitTest {

    @Before
    fun setUp() {
        SessionUnlockManager.clearAll()
        SessionUnlockManager.timeProvider = { System.currentTimeMillis() }
    }

    @Test
    fun `test SafeBase64 encode and decode roundtrip`() {
        val original = "LockAppBD_Secret_Payload_2026!@#"
        val encoded = SafeBase64.encode(original.toByteArray(Charsets.UTF_8))
        val decodedBytes = SafeBase64.decode(encoded)
        val decoded = String(decodedBytes, Charsets.UTF_8)
        assertEquals(original, decoded)
    }

    @Test
    fun `test KeystoreHelper fallback encryption and decryption`() {
        val sensitiveData = "pbkdf2_sha256_hash_value_xyz"
        val encrypted = KeystoreHelper.encrypt(sensitiveData)
        assertNotNull(encrypted)
        val decrypted = KeystoreHelper.decrypt(encrypted)
        assertEquals(sensitiveData, decrypted)
    }

    @Test
    fun `test SessionUnlockManager session unlock and timeout`() {
        var currentTime = 1000000L
        SessionUnlockManager.timeProvider = { currentTime }

        val pkg = "com.whatsapp"
        assertFalse(SessionUnlockManager.isAppUnlocked(pkg))

        SessionUnlockManager.unlockApp(pkg)
        assertTrue(SessionUnlockManager.isAppUnlocked(pkg))

        // Advance time by 5 minutes (within 15 minute limit)
        currentTime += 5 * 60 * 1000L
        assertTrue(SessionUnlockManager.isAppUnlocked(pkg))

        // Advance time past 15 minutes
        currentTime += 11 * 60 * 1000L
        assertFalse(SessionUnlockManager.isAppUnlocked(pkg))
    }

    @Test
    fun `test SessionUnlockManager explicit lock and clearAll`() {
        val pkg = "org.telegram.messenger"
        SessionUnlockManager.unlockApp(pkg)
        assertTrue(SessionUnlockManager.isAppUnlocked(pkg))

        SessionUnlockManager.lockApp(pkg)
        assertFalse(SessionUnlockManager.isAppUnlocked(pkg))

        SessionUnlockManager.unlockApp(pkg)
        assertTrue(SessionUnlockManager.isAppUnlocked(pkg))

        SessionUnlockManager.clearAll()
        assertFalse(SessionUnlockManager.isAppUnlocked(pkg))
    }

    @Test
    fun `test PBKDF2 key derivation and constant time verification`() {
        val pin = "5824"
        val salt = SafeBase64.decode("dGVzdHNhbHQxMjM0NTY=")
        val iterations = 5000

        val spec1 = PBEKeySpec(pin.toCharArray(), salt, iterations, 256)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val hash1 = factory.generateSecret(spec1).encoded

        val spec2 = PBEKeySpec(pin.toCharArray(), salt, iterations, 256)
        val hash2 = factory.generateSecret(spec2).encoded

        assertTrue(MessageDigest.isEqual(hash1, hash2))

        val wrongSpec = PBEKeySpec("0000".toCharArray(), salt, iterations, 256)
        val wrongHash = factory.generateSecret(wrongSpec).encoded
        assertFalse(MessageDigest.isEqual(hash1, wrongHash))
    }

    @Test
    fun `test critical package exclusions list`() {
        assertTrue(AppsManager.EXCLUDED_PACKAGES.contains("android"))
        assertTrue(AppsManager.EXCLUDED_PACKAGES.contains("com.android.systemui"))
        assertTrue(AppsManager.EXCLUDED_PACKAGES.contains("com.android.settings"))
        assertTrue(AppsManager.EXCLUDED_PACKAGES.contains("com.google.android.settings"))
        assertTrue(AppsManager.EXCLUDED_PACKAGES.contains("com.android.dialer"))
        assertTrue(AppsManager.EXCLUDED_PACKAGES.contains("com.android.emergency"))
        assertTrue(AppsManager.EXCLUDED_PACKAGES.contains("com.android.packageinstaller"))
    }
}
